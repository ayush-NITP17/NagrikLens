> Historical audit record for V8 (v0.8.0). This file is retained for traceability and is not the current V9 result. See `TEST_REPORT_v0.9.0.md` and `../audit_probes/LATEST_RESULTS_v0.9.0.txt` for V9 verification.

# Claude v0.7.0 audit — regression replay in v0.8.0

The four diagnostic scripts in `audit_probes/` reproduce the specific cases supplied by the team from Claude’s audit of v0.7.0. They use invented **synthetic fixtures** stored only in temporary SQLite databases. Do not treat these fixtures as policy data or benchmark them as real scheme accuracy.

## Results

| Diagnostic | v0.7.0 failure | v0.8.0 result |
|---|---|---|
| Hindi tokenisation | Devanagari words were truncated or lost | Preserves complete tokens including combining marks |
| Category/state aliases | Scheduled Caste and Bihar variants incorrectly failed | English and Hindi aliases normalise in tested cases |
| Hindi numbers | Common Hindi amount/age forms unknown | `ढाई लाख`, `बीस`, Devanagari digits and Indian grouping parse in tested cases |
| Polarity reversal | A reversed “MORE than” threshold passed | Rejected by comparator check |
| Numeric paraphrase | Valid lakh/Devanagari formats rejected | Accepted when the cited quotation includes the relevant topic and source threshold |
| Irrelevant retrieval | Tax and general-knowledge queries returned irrelevant passages as strong | Those exact queries return no evidence |
| Natural Hindi retrieval | 4/6 top-1 | 6/6 top-1 on the same tiny synthetic fixture set |
| Vocabulary-gap retrieval | English paraphrase and Hindi pension query missed | Relevant synthetic docs retrieved in the replay |
| Document versions | A→B→A history retained only two versions | A→B→A retains versions 1, 2 and 3 |
| OR/AND structure | Flattened conditions could be evaluated | Missing multi-part expression becomes UNKNOWN; structured expression is preserved |
| Exception effects | “except” could be guessed as a waiver | Waiver/exclusion effect requires explicit source wording; ambiguous remains UNKNOWN |

## Important qualifications

- Probe 1’s raw rule-engine exception subtest constructs only a plain income condition; it does not pass any `exception_if` structure. The evaluator therefore cannot apply the exception. In the actual extraction path, a source quotation containing an unrepresented exception is downgraded to `UNKNOWN`.
- Probe 1’s faithful paraphrase check uses a quote fragment that does not contain the substantive topic (family/parental income). Rejecting it for insufficient topical anchors is intentionally conservative. A separate regression test verifies a faithful Hindi/lakh paraphrase when the complete source clause is quoted.
- Probe 3's scale corpus is random synthetic text and uses only a handful of repeated timings. Its medians and outliers are diagnostic observations, not a production load benchmark.
- No real government host fetch, real LLM call, OCR, or full browser test is proven by these scripts.

## Run

From the extracted `nagriklens/` project root:

```powershell
python audit_probes/probe1_hindi_tokens_rules_validator.py
python audit_probes/probe2_retrieval_abstention_versions.py
python audit_probes/probe3_bm25_normalisation_and_latency.py
python audit_probes/probe4_hindi_to_hindi_retrieval.py
```

Each script sets `NAGRIKLENS_DB_FILE` to a temporary SQLite path.
