# 24-hour build and evaluation roadmap

This roadmap is a development sequence, not evidence that the work has been performed. Follow the event's rules and obtain organiser clarification before reusing any pre-event artifact.

| Window | Deliverable | Acceptance test | Rubric |
|---|---|---|---|
| 0–2h | Organiser ruling, scope freeze, official source shortlist | Written confirmation of permitted pre-work; official documents selected | Compliance, relevance |
| 2–5h | Live official ingestion on target network | Two official PDFs/HTML pages fetched, timestamped, page/URL provenance visible | Engineering, demo |
| 5–8h | RAG retrieval benchmark | 30 labelled questions; correct provision in top-5; record misses | Engineering, AI |
| 8–11h | Evidence-grounded explanation | Every factual answer claim cites exact source; numbers tested; failure fallback works | AI |
| 11–14h | Structured policy extraction | Rights, conditions, exceptions, dates and documents extracted; coverage visible | AI, relevance |
| 14–16h | Rule evaluator | Missing profile fields become UNKNOWN; no all-clear on partial analysis | AI, robustness |
| 16–18h | Section-level version comparison | Same URL fetched twice; changed section flagged; no auto-claim of amendment | Engineering, AI |
| 18–20h | Hindi and voice | Human review on at least 20 English/Hindi paired questions; browser voice tested on demo device | Impact, demo |
| 20–22h | Security and failure testing | SSRF, large PDF, timeout, stale source, malformed profile and prompt injection checks | Robustness |
| 22–24h | Deploy, pitch, rehearsal | Three end-to-end flows succeed on clean demo deployment; source links opened live | Demo |

**Cut first if time is short:** voice, advanced styling, cross-jurisdiction coverage. **Do not cut:** source provenance, exact evidence display, failure abstention, live demo rehearsal or compliance review.
