# NagrikLens V10 Architecture

## Components

1. **Existing single-page frontend** — `app/static/index.html`. It previews PDF metadata, collects page selection, submits approved website URLs, loads the source registry and document library, manages active-source context, submits questions, renders citations, and displays extraction and eligibility results.
2. **FastAPI API layer** — `app/main.py`. It provides health/status, PDF inspection/upload, URL ingestion, documents/reports/versions, sessions, query, source registry administration, structured extraction and eligibility routes.
3. **Ingestion layer** — `app/ingestion.py`. It validates PDF input, extracts page-aware text, performs configured OCR fallback, fetches allowlisted HTTPS sources with redirect checks, parses static HTML, handles explicitly requested bounded linked PDFs, and returns completeness/provenance metadata.
4. **SQLite store** — `app/store.py`. It stores source/document metadata, extracted evidence, document versions, source registry and query-session source selections.
5. **Retrieval/policy layer** — `app/retrieval.py` and `app/policy.py`. It uses the V9 BM25/inverted-index pipeline, query expansion, selected-document scoping, evidence thresholds and abstention.
6. **LLM and grounding layer** — `app/llm.py`. It sends selected evidence to the configured Gemini OpenAI-compatible endpoint when available, validates structured responses, and applies grounding/privacy safeguards. Retrieval can still return source extracts/fallback when LLM generation is unavailable.
7. **Eligibility layer** — `app/rules.py`. It deterministically evaluates extracted conditions against user-provided profile values using MET / NOT_MET / UNKNOWN and logical condition trees. The source condition extraction may be incomplete and results are not official decisions.

## Typical PDF flow

1. Browser sends file to `POST /api/documents/inspect-pdf`.
2. API validates file signature/size and returns page count, default first-10 scope, and configured page/size limits without storing the PDF.
3. Browser lets user select max page, individual pages, or all pages.
4. Browser sends the file and chosen scope to `POST /api/documents/upload`.
5. Ingestion extracts/OCRs selected pages, preserves original page numbers, creates evidence chunks and stores completeness/provenance information.
6. User selects the active document; `POST /api/query` passes its `document_id` and session to ensure source scope.
7. BM25 retrieval searches the selected document's indexed chunks; relevant evidence is passed to Gemini when configured.
8. Answer and citations return to the browser. The browser renders all source-derived text as text, not HTML.

## Website flow

1. User submits an HTTPS URL.
2. Ingestion validates exact host approval, DNS/public-IP safety, ports and redirects.
3. Static HTML is parsed, or a direct PDF is passed through PDF page ingestion.
4. Linked PDFs are only fetched when requested and within the configured same-host cap.
5. Extracted content, source URL, provenance and version information are stored and exposed through the document and processing-report APIs.

## Trust boundaries

- Host approval means only that the server may fetch a specific hostname; it does not authenticate an individual document or legal status.
- User-uploaded files are labelled as user uploads.
- Evidence retrieval and claim validation reduce but do not eliminate hallucinations or semantic errors.
- Gemini is an external processor when configured; personal profile values are not sent in the grounded answer-synthesis request per the existing V9 privacy guard.
- The shared API access key is a demo gate, not account authentication or tenant-level ownership.
