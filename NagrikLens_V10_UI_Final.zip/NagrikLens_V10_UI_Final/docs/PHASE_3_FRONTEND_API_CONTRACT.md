# NagrikLens V10 — Phase 3 Frontend/API Contract

The frontend is implemented in the existing `app/static/index.html` and uses the backend routes below. All API calls are same-origin. The optional shared demo key is entered in the UI and sent as `X-Nagriklens-API-Key`; the Gemini key is never sent to the browser.

## Frontend action mapping

| UI action | API route | Frontend behaviour |
|---|---|---|
| Initial app status | `GET /api/health`, `GET /api/llm-status` | Shows server version and whether the server has an LLM key configured; does not claim that a live provider request succeeded. |
| Create query context | `GET /api/sessions/new` | Retains opaque selected-document scope for follow-up questions. |
| Load document library | `GET /api/documents` | Builds the active-document selector and per-document actions. |
| Preview selected PDF | `POST /api/documents/inspect-pdf` | Reads total pages and size/page limits without storing a document. |
| Upload selected PDF pages | `POST /api/documents/upload` | Sends `page_mode`, `max_page_number` or sorted/deduplicated `selected_pages`. |
| Ingest approved website/direct PDF | `POST /api/documents/ingest-url` | Sends URL, optional linked-PDF request and PDF page-selection parameters. |
| Refresh registry | `GET /api/sources/registry` | Renders effective backend host registry and ingested-source provenance dynamically. |
| Approve/reject exact hostname | `POST /api/admin/sources/approve`, `POST /api/admin/sources/reject` | Sends `X-Nagriklens-Admin-Key`; approval is not document authentication. |
| Select active-source report | `GET /api/documents/{id}/processing-report` | Shows selected/extracted/OCR/unreadable/failed/not-processed pages and chunk/index status. |
| Ask question | `POST /api/query` | Sends active `document_id`, session, optional profile and independent `answer_language`. |
| Explain full document | `POST /api/documents/{id}/analyse` | Renders structured extracted policy items and extraction coverage. |
| Eligibility form | `POST /api/documents/{id}/eligibility` | Sends guided profile fields; renders condition counts, missing data and source citations. |
| Version history | `GET /api/documents/{id}/versions` | Displays stored version snapshots/change summaries and limitation notice. |
| Refresh source | `POST /api/documents/ingest-url` | Re-fetches the current HTTPS source and then requests version history. |
| Delete document | `DELETE /api/documents/{id}` | Deletes the document and asks the backend to remove linked stored records. |

## PDF inspection request/response

`POST /api/documents/inspect-pdf` uses `multipart/form-data` with field `file`.

Response fields:

```json
{
  "filename": "guideline.pdf",
  "file_size_bytes": 734003,
  "max_upload_bytes": 26214400,
  "total_pages": 100,
  "default_max_page": 10,
  "max_process_pages": 500,
  "stored": false,
  "note": "This is a metadata preview only. No document or evidence has been stored yet."
}
```

The UI initializes the maximum page number from `default_max_page`, validates against `total_pages`, displays the configured upload limit, and prevents user selections that exceed `max_process_pages`.

## Query response rendering

The frontend reads `answer`, `answer_language`, `retrieval_strength`, `llm_used`, `citations`, `grounding_warnings`, `prompt_injection_evidence_ids`, `redacted_identifier_types`, `workflow`, and `potential_conflicts`. Each citation is rendered using text nodes and may include `evidence_id`, `document_id`, `title`, `page_title`, `section`, original `page`, `source_url`, exact `quote`, `provenance`, `authority_status`, and `freshness`.

The frontend does not create evidence, page numbers, or source URLs. Missing citation fields are shown as unavailable rather than inferred.

## Eligibility response rendering

The frontend expects `conditions_found`, `conditions_met`, `conditions_not_met`, `conditions_unknown`, `overall_status`, `conditions`, `missing_user_information`, `citations`, `analysis_coverage`, `processing_report`, and `extraction_note`. The UI always labels the output as a non-official, source-derived assessment.

## Security and status rules

- Host registry values come only from `/api/sources/registry`; the frontend contains no independent host allowlist.
- A source is shown as COMPLETE only when `overall_completeness === true`, `processing_status === "COMPLETE"`, and `indexing_status !== "FAILED"`.
- Partial source coverage is displayed as PARTIAL / REVIEW, including not-processed pages and warnings.
- Source names, quotations, summaries and errors are assigned with `textContent`; source text is not inserted with `innerHTML`.
- `LLM_API_KEY` and `NAGRIKLENS_ADMIN_KEY` are never embedded in frontend code.
