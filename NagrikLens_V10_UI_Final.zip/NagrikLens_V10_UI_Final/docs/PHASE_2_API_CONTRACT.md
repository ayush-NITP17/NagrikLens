# NagrikLens V10 Phase 2 — API Contract for Phase 3

Base URL for local development: `http://127.0.0.1:8000`

Machine-readable schema: [`openapi_phase2.json`](openapi_phase2.json)

All JSON endpoints use UTF-8. The service does not return secret configuration values. When `NAGRIKLENS_API_KEY` is set, send `X-Nagriklens-API-Key` on `/api/*` calls except `/api/health`. Source-admin POSTs additionally require `X-Nagriklens-Admin-Key` when `NAGRIKLENS_ADMIN_KEY` is configured.

## 1. Endpoint index

| Method | Route | Purpose |
|---|---|---|
| GET | `/` | Existing HTML application shell |
| GET | `/api/health` | Service/version/configuration status |
| GET | `/api/documents` | List ingested documents and their processing metadata |
| POST | `/api/documents/inspect-pdf` | Preview a PDF page count and configured limits without storing it (multipart) |
| POST | `/api/documents/upload` | Upload a PDF with page-selection parameters (multipart) |
| POST | `/api/documents/ingest-url` | Ingest an approved HTTPS HTML or direct-PDF URL |
| GET | `/api/documents/{document_id}` | Document metadata and evidence chunks |
| GET | `/api/documents/{document_id}/processing-report` | Extraction completeness and page report |
| GET | `/api/documents/{document_id}/versions` | Version history for a source |
| POST | `/api/documents/{document_id}/analyse` | LLM-based structured policy extraction |
| POST | `/api/documents/{document_id}/eligibility` | Evaluate extracted conditions against a profile |
| DELETE | `/api/documents/{document_id}` | Delete document, evidence, analyses, version history and session references |
| GET | `/api/sessions/new` | Create an opaque source-selection session ID |
| POST | `/api/query` | Query only explicitly selected/session-selected document(s) |
| GET | `/api/sources/registry` | Effective source allowlist, approvals and ingested-source records |
| POST | `/api/admin/sources/approve` | Approve an exact hostname (admin key required) |
| POST | `/api/admin/sources/reject` | Reject an exact hostname (admin key required) |
| GET | `/api/metrics` | Counts of ingested documents/evidence |
| GET | `/api/changes` | Recent document-version change records |
| GET | `/api/llm-status` | Non-secret Gemini/provider configuration status |

## 2. PDF metadata inspection (Phase 3 UI support)

`POST /api/documents/inspect-pdf` — `multipart/form-data` with one `file` PDF field. This endpoint validates the PDF signature, opens the PDF to read its page count, and returns selection/size limits without storing the PDF or creating a document record.

Example response:

```json
{
  "filename": "guideline.pdf",
  "file_size_bytes": 734003,
  "max_upload_bytes": 26214400,
  "total_pages": 100,
  "default_max_page": 10,
  "max_process_pages": 500,
  "stored": false,
  "note": "This is a metadata preview only. No document or evidence has been stored yet."
}
```

The UI uses `total_pages` to validate page selections, `default_max_page` for the initial value, `max_upload_bytes` for the actual configured upload-size label, and `max_process_pages` to prevent selections larger than the server's one-request processing limit.

## 3. PDF upload

`POST /api/documents/upload` — `multipart/form-data`

| Field | Type | Required | Meaning |
|---|---|---:|---|
| `file` | PDF file | yes | PDF bytes; file name must end in `.pdf` and signature must be `%PDF-` |
| `jurisdiction` | string | no | Defaults to `India` |
| `page_mode` | `max_page` / `specific` / `all` | no | Defaults to `max_page` |
| `max_page_number` | integer | conditional | Inclusive final page for `max_page`; defaults to first 10 or PDF page count, whichever is lower |
| `selected_pages` | comma-separated integers | conditional | Required for `specific`, e.g. `2,8,10,7` |

Example (PowerShell):

```powershell
curl.exe -X POST http://127.0.0.1:8000/api/documents/upload `
  -F "file=@C:\docs\guideline.pdf" `
  -F "page_mode=specific" `
  -F "selected_pages=2,8,10,7"
```

Successful response includes `document_id`, `title`, `content_type`, `provenance`, `authority_status`, `page_count`, `selected_pages`, `evidence_count`, `processing_report` and `extraction_note`.

`processing_report` fields:

```json
{
  "total_pages": 100,
  "selected_pages": [2, 7, 8, 10],
  "extracted_pages": [2, 7, 8, 10],
  "ocr_pages": [],
  "unreadable_pages": [],
  "failed_pages": [],
  "text_length": 1450,
  "chunk_count": 4,
  "processing_duration_ms": 123.4,
  "processing_status": "PARTIAL",
  "selected_scope_complete": true,
  "indexing_status": "INDEXED",
  "overall_completeness": false,
  "not_processed_pages": [1, 3, 4, 5, 6, 9, 11, 12],
  "ocr_available": true
}
```

This is an illustrative shape, not a fixed result. `overall_completeness` is true only when all document pages were processed successfully. `selected_scope_complete` can be true while `overall_completeness` is false if a subset was deliberately selected.

## 4. Website URL ingestion

`POST /api/documents/ingest-url` — JSON body (`IngestURLRequest`):

```json
{
  "url": "https://approved.example.gov.in/guideline",
  "title": null,
  "jurisdiction": "India",
  "include_linked_pdfs": false,
  "max_linked_pdfs": 3,
  "page_mode": "max_page",
  "max_page_number": 10,
  "selected_pages": []
}
```

Fields:

- `url` (string, required): HTTPS URL, up to 2,048 characters.
- `title` (string or null): optional display title.
- `jurisdiction` (string): defaults to `India`.
- `include_linked_pdfs` (boolean): false by default. Linked PDFs are not fetched unless explicitly requested.
- `max_linked_pdfs` (integer 0–5): additionally capped by server `MAX_LINKED_PDFS`.
- `page_mode`, `max_page_number`, `selected_pages`: used when the source is a direct PDF URL or explicitly fetched same-host linked PDFs.

HTML response includes document metadata, `processing_report`, `linked_pdfs` (empty unless the option was requested) and a note that page extraction is limited to static HTML main-content parsing. A direct PDF URL response has `ingestion_kind: "DIRECT_PDF_URL"` and PDF page-selection/report fields.

Unknown hosts return HTTP 422 with the exact rejected hostname and administrator-approval requirement. They are recorded as `PENDING`; they are not fetched or automatically approved.

## 5. Document and processing-report reads

- `GET /api/documents` returns `{ "documents": [...], "note": "..." }`.
- `GET /api/documents/{document_id}` returns `{ "document": {...}, "evidence": [...] }`. The raw full-text column is not returned in the document metadata response.
- `GET /api/documents/{document_id}/processing-report` returns `document_id`, `title`, `source_url`, `provenance`, `processing_report`, `selected_pages` and `extraction_note`.
- `GET /api/documents/{document_id}/versions` returns `{ "document_id": "...", "versions": [...] }`.
- `DELETE /api/documents/{document_id}` returns `{ "deleted": true, "document_id": "..." }` or HTTP 404.

## 6. Selected-document query and language

`POST /api/query` — JSON (`QueryRequest`):

```json
{
  "question": "What are the eligibility conditions and income limit?",
  "language": "auto",
  "answer_language": "hi",
  "profile": {},
  "use_llm": true,
  "require_live_sources": false,
  "document_id": "doc-123",
  "document_ids": [],
  "session_id": "optional-opaque-session-id"
}
```

Fields:

- `question`: string, 3–3,000 characters.
- `language`: legacy-compatible `auto`, `en` or `hi`; default `auto`.
- `answer_language`: `same_as_question`, `en` or `hi`; default `same_as_question`. An explicit `en` or `hi` overrides question-language detection.
- `profile`: optional JSON object for local rule evaluation; profile values are not included in grounded answer synthesis requests.
- `use_llm`: boolean, default true. False returns retrieved source extracts/fallback text.
- `require_live_sources`: boolean, default false.
- `document_id`: optional single selected document.
- `document_ids`: explicit list of up to 10 selected documents, for example to compare two documents. Multiple sources are never included unless explicitly selected.
- `session_id`: optional session created by `GET /api/sessions/new`; when no document IDs are supplied, the saved selection is reused. Sessions store selected document IDs, not transcripts.

The response is `QueryResponse`, including:

- `answer`, `language`, `answer_language`, `intent`.
- `selected_document_ids`.
- `evidence`: retrieved passages with evidence/document identifiers and original page numbers.
- `citations`: each citation has `evidence_id`, `document_id`, `title`, `page_title`, `section`, `page`, `source_url`, exact `quote`, `provenance`, `authority_status` and `freshness`.
- `retrieval_strength`: `strong`, `moderate`, `weak` or `insufficient`.
- `status_note`, `workflow`, `tool_calls`, `llm_used` and `source_mode`.
- `grounding_warnings`, `prompt_injection_evidence_ids`, `redacted_identifier_types`.
- `authority_statuses`, `freshness_statuses`, `potential_conflicts` and `versions`.

No relevant evidence yields an abstention response with `retrieval_strength: "insufficient"` and no citations. The answer must not be interpreted as legal advice.

## 7. Query session

`GET /api/sessions/new` returns:

```json
{
  "session_id": "UUID-string",
  "note": "A session retains selected document IDs only; it is not user authentication or conversational transcript storage."
}
```

The client should retain the `session_id` and send it on follow-up `/api/query` requests. Supplying a new `document_id` switches the active source selection for that session. Supplying `document_ids` explicitly enables multi-document querying/comparison.

## 8. Source registry

`GET /api/sources/registry` returns:

```json
{
  "sources": [
    {
      "hostname": "approved.example.gov.in",
      "authority": "Publisher name or Publisher not configured",
      "approval_status": "APPROVED",
      "host_fetch_status": "ALLOWED",
      "verification_status": "GOVERNMENT_HOST_ALLOWLISTED_DOCUMENT_NOT_AUTHENTICATED",
      "document_ingested": false
    }
  ],
  "ingested_documents": [
    {
      "document_id": "upload-...",
      "title": "citizen-copy.pdf",
      "source_url": "upload://...",
      "hostname": null,
      "provenance": "USER_UPLOAD",
      "authority_status": "USER_UPLOADED_PUBLISHER_UNVERIFIED",
      "document_ingested": true,
      "host_fetch_status": "NOT_APPLICABLE_USER_UPLOAD"
    }
  ],
  "note": "Host approval does not authenticate individual documents or legal authority."
}
```

Possible `approval_status` values: `APPROVED`, `PENDING`, `REJECTED` for registry hosts. Configured hosts are shown as `APPROVED` unless an administrator has explicitly rejected them. User-uploaded files are listed in `ingested_documents` and do not create fake hostname entries.

## 9. Administrator source approval/rejection

Both routes require the `X-Nagriklens-Admin-Key` header matching `NAGRIKLENS_ADMIN_KEY`.

`POST /api/admin/sources/approve`:

```json
{
  "hostname": "new.example.gov.in",
  "authority": "Example Department",
  "verification_status": "ADMIN_APPROVED_HOST_DOCUMENT_NOT_AUTHENTICATED"
}
```

Response includes the source, `approval_status: "APPROVED"`, `verification_status` and `document_authentication: "NOT_PERFORMED"`. The exact hostname only is approved; DNS/public-IP checks still run on every fetch.

`POST /api/admin/sources/reject`:

```json
{
  "hostname": "new.example.gov.in",
  "reason": "Rejected after administrator review"
}
```

Response includes the source and `approval_status: "REJECTED"`. Approval/rejection is not a claim that an individual document is legally authentic.

## 10. Eligibility analysis

`POST /api/documents/{document_id}/analyse` — JSON:

```json
{ "language": "en" }
```

Runs structured extraction for the selected document's indexed evidence and saves the result by document hash/language. This requires an available configured LLM provider.

`POST /api/documents/{document_id}/eligibility` — JSON (`EligibilityRequest`):

```json
{
  "profile": { "annual_family_income": 200000, "state": "Bihar" },
  "answer_language": "en"
}
```

Response includes the deterministic `overall_status`, per-condition `conditions`, and the Phase 2 summary contract:

- `conditions_found`
- `conditions_met`
- `conditions_not_met`
- `conditions_unknown`
- `missing_user_information` (each item identifies the condition and question to ask)
- `citations` (document ID, title, original page, section, source URL, exact quote, provenance/authority status)
- `analysis_coverage`
- `processing_report`
- `document`
- `extraction_note`

Possible condition statuses remain `MET`, `NOT_MET`, `UNKNOWN`. `UNKNOWN` is not `NOT_MET`. The API does not issue official eligibility decisions. Incomplete PDF processing or incomplete structured extraction is explicitly reflected in coverage and notes.

## 10. Other read endpoints

- `GET /api/health`: version, document counts, live/user-uploaded counts, LLM-configured boolean and whether the shared API key gate is enabled. It never returns keys.
- `GET /api/metrics`: current document and evidence counts with provenance counts.
- `GET /api/changes`: stored version-change records with a warning that text differences are not legal amendment determinations.
- `GET /api/llm-status`: configured boolean, model name, base URL configured boolean and a note that live provider access is not verified by configuration alone.

## 11. Error conventions

- `400`: malformed/invalid request in applicable routes.
- `401`: missing/invalid shared API key or admin key.
- `404`: document does not exist.
- `413`: upload/request/source body exceeds configured limit.
- `415`: unsupported upload type.
- `422`: invalid page selection, unsupported/unsafe/unapproved URL, or validation error.
- `429`: per-process rate limit exceeded.
- `502`: source/model processing failure where the route maps provider errors to gateway failure.
- `503`: LLM not configured or unavailable for structured extraction.

Error bodies use FastAPI's standard `{ "detail": "..." }` shape. Do not display provider secrets or raw secret-bearing headers in the frontend.
