# Source Guide and Provenance Rules

NagrikLens has no built-in scheme data or government document snapshots. The user/team must add the specific current document needed for an analysis.

## Source priority

Prefer:

1. Official Gazette or issuing department's signed notification/order.
2. Official ministry/department scheme guideline or statutory text.
3. Official department FAQ/operational instructions, clearly distinguished from the legal instrument.
4. Official open-data portal/API for a dataset, if the specific dataset resource has an API and the API is available.
5. Secondary research/news for context only, never as a substitute for a controlling legal instrument.

## Suggested official portals to investigate (manual source selection required)

- Bihar Gazette: https://egazette.bihar.gov.in/
- Bihar Government Digital Repository: https://digi-repo.bihar.gov.in/
- Bihar Legislative Assembly: https://vidhansabha.bihar.gov.in/
- Bihar Labour Resources Department: https://betastate.bihar.gov.in/labour/
- Press Information Bureau: https://pib.gov.in/
- India Code (current portal): https://indiacode.gov.in/ (the old `indiacode.nic.in` address redirects; use the final host URL because the app does not follow redirects).
- Ministry of Education: https://www.education.gov.in/ (for example, PM-Vidyalaxmi scheme guidelines)
- National Scholarship Portal: https://scholarships.gov.in/
- Ministry of Social Justice & Empowerment: https://socialjustice.gov.in/
- Ministry of Tribal Affairs: https://tribal.gov.in/
- Department of Empowerment of Persons with Disabilities: https://depwd.gov.in/
- PM-KISAN: https://pmkisan.gov.in/
- PM Fasal Bima Yojana: https://pmfby.gov.in/
- Agriculture Infrastructure Fund: https://agriinfra.dac.gov.in/
- Data.gov.in: https://www.data.gov.in/

### Specific official documents to use as live ingestion tests

These are candidate source URLs found on official government domains. They are not preloaded into the application; add them through the UI when testing. Always open the page and confirm that the linked document is still current before relying on it.

- National Scholarship Portal listings for AY 2026–27: https://scholarships.gov.in/All-Scholarships
- SC Post-Matric Scholarship scheme page: https://socialjustice.gov.in/schemes/25
- ST Post-Matric Scholarship guidelines PDF: https://tribal.gov.in/downloads/guidelines/post-matric/Post-matric-guidelines-15032023.pdf
- PwD Post-Matric Scholarship: https://depwd.gov.in/en/scholarship-post-matric/
- PM-Vidyalaxmi guidelines PDF: https://www.education.gov.in/sites/upload_files/mhrd/files/document-reports/PM_Vidyalaxmi_Scheme_Guidelines.pdf
- PM-KISAN operational guidelines PDF: https://pmkisan.gov.in/Documents/RevisedPM-KISANOperationalGuidelines%28English%29.pdf
- Agriculture Infrastructure Fund scheme guidelines PDF: https://agriinfra.dac.gov.in/Content/DocAttachment/FINALSchemeGuidelinesAIF.pdf
- PMFBY official portal: https://pmfby.gov.in/ (open the current operational-guidelines link from the portal; do not assume an old direct PDF is current)
- India Code legislation repository: https://indiacode.gov.in/ (current host; the old `indiacode.nic.in` address redirects)

The source URL must still be checked for currentness, authority and relevance. The application only fetches exact allowlisted HTTPS hostnames. Some websites may block automated requests, require a login, use JavaScript rendering, or provide no direct PDF. In that case, fetch/inspect the document manually and upload the genuine PDF, which remains labelled publisher-unverified.

## Data.gov.in caution

The presence of a dataset on Data.gov.in does not guarantee that every resource has an accessible API. Check the particular resource page and its API documentation/registration requirements. Do not build an integration that quietly substitutes a hardcoded local file when an API is unavailable.

## myScheme caution

Do not scrape myScheme without written authorisation. Use official links and permitted public access routes; comply with the portal's terms of use.

## Provenance labels

`LIVE` means successful HTTP retrieval and parsing in this current server process; `CACHED` means stored from an earlier session; `USER_UPLOADED` means the app cannot authenticate publisher identity. `OFFICIAL_DOMAIN_NOT_DOCUMENT_AUTHENTICATED` is a hostname-based hint only, not proof that the individual document is authentic or legally in force.
