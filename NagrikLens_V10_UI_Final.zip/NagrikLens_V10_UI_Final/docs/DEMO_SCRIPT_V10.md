# NagrikLens V10 Demonstration Script

## Before the demonstration

1. Start the application using the README commands.
2. Confirm the browser shows the expected server version and the configured/not-configured LLM status.
3. Use a non-sensitive, text-searchable official PDF whose source and publication status you have independently checked.
4. If using direct URL ingestion, confirm the exact hostname is present in the backend source registry.
5. Do not use an API key or real citizen documents in screenshots or recordings.

## PDF workflow

1. Upload a multi-page PDF.
2. Confirm the page count and actual configured upload limit appear.
3. Demonstrate the default first-10 selection, then enter a custom maximum.
4. Demonstrate a non-consecutive set such as `2, 8, 10, 7`; confirm that the original page numbers remain in citations.
5. Demonstrate the entire-PDF choice only if the server's `MAX_PROCESS_PAGES` limit permits it.
6. Show extracted, OCR, unreadable, failed, not-processed and chunk-count information in the completeness report.

## Website workflow

1. Show the backend-driven “Currently Allowed Government Sources” registry.
2. Submit an approved static HTTPS page or direct PDF URL.
3. If testing an unknown host, show the rejected hostname and administrator-approval message. Do not approve an unknown host merely to make the demo work.
4. If the PDF URL is selected, demonstrate max/specific/all page options.

## Question answering

1. Select the active document.
2. Click an example question to populate the question field.
3. Choose an answer language independently of the question language.
4. Ask a question that requires evidence from more than one page.
5. Open the citation panel and compare the quoted evidence with the original document.
6. Ask an unsupported question and demonstrate abstention.

## Additional capabilities

1. Open the document analysis panel and check the extraction coverage warning.
2. Populate a small, non-sensitive eligibility profile and show MET / NOT_MET / UNKNOWN counts, missing information and citations.
3. Open version history if the selected URL has stored multiple snapshots.

## Claims to avoid

Do not claim live government access unless the exact URL was fetched successfully during the demo. Do not claim Gemini generation unless a live LLM request succeeded. Do not call the eligibility result official, the source authentic merely because its host is allowlisted, or the validator formal legal entailment.
