# NagrikLens V10 — Final Test Report

## Final result

**194 passed · 0 failed · 0 skipped** in the final full-suite run.

## Test modules

| Module | Count | Result |
|---|---:|---|
| `tests/test_critical_audit_regressions.py` | 45 | Passed |
| `tests/test_phase2_website_registry_language.py` | 63 | Passed |
| `tests/test_phase3_frontend.py` | 15 | Passed |
| `tests/test_v07.py` | 53 | Passed |
| `tests/test_v09_hardening.py` | 18 | Passed |
| **Total** | **194** | **194 passed** |

## Phase 3 test coverage

- Node.js syntax validation for the inline JavaScript.
- Real Chromium rendering and interaction against mocked API responses: PDF upload preview/page controls, registry list, document switching, example-question click, answer-language request payload, answer/citation rendering, eligibility form, adjustable maximum page, direct-PDF URL page selection, process-page cap, administrator action header, version history, XSS-safe citation rendering and unapproved-host error display.
- FastAPI TestClient inspection endpoint: 100-page metadata preview, no database write, configured upload/page limits returned, invalid PDF rejected.
- LLM status endpoint: loaded model is returned and API key value is never returned.

## Other checks

| Check | Result |
|---|---|
| `python -m compileall -q app scripts tests` | Passed |
| Extracted inline JS checked with `node --check` | Passed |
| Generated OpenAPI schema | Passed; 18 API endpoints plus homepage (19 total paths) |
| API key secret not returned by `/api/llm-status` | Passed in test |
| Source-derived citation text not interpreted as HTML | Passed in Chromium test |

## Scope of the tests

- Existing 179 Phase 2 inherited tests passed, covering V9 regression, PDF, retrieval, grounding, Gemini request handling with mocks, website ingestion with mocked HTTP, source registry, SSRF/redirect checks, source isolation, language selection and eligibility.
- The 15 additional Phase 3 tests cover frontend and PDF metadata-preview integration.
- Browser tests use Chromium but stub API responses; separate FastAPI tests exercise the inspected PDF route. This is not a deployed browser-to-server test with a live provider.
- Website tests use local fixtures/mocked network responses. They do not prove that government websites are reachable today.

## Not run / requires external environment

| Test | Status | Reason |
|---|---|---|
| Real Gemini generation | Not run | Requires the user's valid API key, model access, quota and external network. |
| Live government website ingestion | Not run | The release checks use mocked/local HTTP fixtures; no live host verification is claimed. |
| Windows VS Code manual installation | Not run | Build/test environment is Linux; README contains exact Windows steps. |
| Production load / penetration test | Not run | Requires a deployment environment and dedicated security testing. |
| Formal accessibility review | Not run | No independent audit was performed. |

## Limitations

See `KNOWN_LIMITATIONS_V10.md` and `PHASE_3_REPORT.md`. Test success is not proof of legal correctness or production security.
