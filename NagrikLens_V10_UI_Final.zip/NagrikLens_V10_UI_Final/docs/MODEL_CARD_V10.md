# Model card — NagrikLens V10

## System type

NagrikLens is not a newly trained foundation model. It is an evidence-grounded document intelligence application combining PDF/HTML ingestion, lexical retrieval (BM25 with an inverted index), selected-source scoping, heuristic claim validation, deterministic eligibility-rule evaluation and an optional external Gemini model through Google's OpenAI-compatible Chat Completions API.

## Intended use

- Help a user search a PDF or an explicitly approved HTTPS source they have ingested.
- Retrieve passages from the selected document and selected/or indexed pages.
- Explain supported passages in plain English or Hindi, with answer language selected independently from question language.
- Display the original source, page number, exact quotation and provenance for returned citations.
- Extract candidate eligibility conditions and compare them locally against optional user-entered profile values while representing missing/ambiguous conditions as UNKNOWN.
- Display source completeness and stored text-version differences for human review.

## Out-of-scope use

- Legal advice, official eligibility decisions or guaranteed benefit amounts.
- Filing, approving or submitting a government application.
- Certifying that a document is authentic or legally in force.
- Determining legal supersession or the controlling version across unrelated URLs.
- Processing sensitive citizen identity records on a shared or unreviewed deployment.

## Model and components

- Retrieval: preserved V9 Unicode tokenisation, cached BM25/inverted postings, absolute score and coverage gates, bilingual phrase/query expansion, and selected-document source scoping.
- Generation: optional Gemini model through the OpenAI-compatible endpoint. Default model ID: `gemini-3.8-flash`; actual availability depends on the user's Google project/key/quota.
- Grounding: evidence quotation validation plus numeric, ordinal, comparator, polarity, modality, frequency, authority and semantic-anchor heuristics. This is not formal entailment.
- Eligibility: deterministic `MET` / `NOT_MET` / `UNKNOWN` evaluation over extracted conditions and AND/OR/NOT expressions. Extraction completeness remains a dependency.
- Storage: SQLite document/evidence/version/source-registry/session-selection records. New installs start without a bundled government dataset.
- Ingestion: PDF page selection, extraction and optional Tesseract OCR; exact-host HTTPS website fetch with bounded redirects, public DNS checks, static HTML parsing and optional bounded linked PDFs.

## Provenance and trust

User-uploaded PDFs carry user-upload provenance and are not authenticated as official. Fetched documents carry source URL and host/source status. An approved hostname permits fetching only; it does not authenticate the individual document or determine legal effect. Evidence citations refer to stored source passages and original PDF page numbers where available.

## Evaluation

The V10 release suite ran **194 automated tests successfully** in the local build environment. It includes inherited V9/Phase 1-derived/Phase 2 tests and 15 Phase 3 frontend/API tests. Phase 3 browser tests use Chromium with mocked API responses; local FastAPI tests separately exercise endpoints. Synthetic retrieval fixtures and deterministic audit probes are regression tools, not independent real-world benchmarks.

No real Gemini provider call or live government-source ingestion was performed in the release environment. The test suite does not establish accuracy on real government policies or legal correctness.

## Limitations and risks

- BM25 and finite lexical expansion can miss unseen words or phrasing; precision/recall trade-offs require evaluation on a genuinely labelled corpus.
- The claim validator is heuristic and may accept unsupported semantic changes or reject faithful paraphrases.
- LLM extraction may omit eligibility conditions or exceptions; the rules engine only evaluates the extracted structure.
- OCR depends on external Tesseract and language packs; low-quality scans may remain unreadable.
- Static HTML extraction may not capture JavaScript-rendered pages.
- Follow-up session state preserves selected document IDs, not full chat transcripts or advanced reference resolution.
- The shared API key is not user identity or tenant isolation.
- External provider data handling depends on the configured Gemini project and its terms. Retrieved document passages are sent to the provider when LLM generation is enabled; profile values are omitted from grounded answer synthesis by the existing privacy guard.
- Text changes do not determine legal amendments, commencement, supersession or current effect.

## Human oversight

Users should inspect cited original passages and the complete source, including amendments, commencement notices, exceptions and application instructions. Eligibility output is a candidate rule comparison, not official approval. Human legal/administrative confirmation is required before consequential decisions.
