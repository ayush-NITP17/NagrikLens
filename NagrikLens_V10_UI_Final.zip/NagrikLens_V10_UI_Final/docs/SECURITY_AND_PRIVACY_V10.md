# NagrikLens V10 Security and Privacy Notes

## Controls preserved or surfaced by the Phase 3 UI

- API key and administrator key remain server-side; the browser only collects an optional shared demo key and a separate admin key for the admin action.
- `.env`, SQLite databases, virtual environments, caches and local build artifacts are excluded by `.gitignore` / `.dockerignore` and are removed from the release package.
- Server-side URL ingestion requires exact approved HTTPS hosts, validates redirect targets, and checks DNS resolution for public addresses.
- Request and upload limits, streamed-body limits and per-process rate limits remain enabled.
- SQL uses parameterised statements.
- Source content, citations, error messages and registry values are rendered with DOM text APIs. Phase 3 includes a browser test for a hostile citation quote.
- PDF uploads are validated by extension/signature and parser; the metadata-inspection endpoint does not store documents.
- User profiles are collected in the guided form and are not included in the existing grounded LLM answer synthesis payload.
- The UI warns against entering Aadhaar numbers, bank details, OTPs and identity-document numbers.
- The source registry explicitly distinguishes host approval from document authentication.

## Important limitations

- `NAGRIKLENS_API_KEY` is one shared demo key, not per-user authentication, role-based ownership or tenant isolation.
- An admin key is a shared administrator secret. Protect it and do not expose it publicly.
- Rate limiting is in-process and per client/path; it is not sufficient for multiple workers or public production.
- DNS checks cannot entirely eliminate DNS rebinding or time-of-check/time-of-use risk. Production deployment should enforce network egress rules outside the application.
- Uploaded PDFs may be malicious or malformed; the parser is a dependency and must be kept patched.
- Documents may contain prompt-injection instructions. The application treats source passages as untrusted evidence, but prompt-injection protections are not a formal guarantee.
- External Gemini processing occurs when configured. Provider data handling, retention and free/paid-tier terms must be reviewed before uploading sensitive citizen records.
- The application is a hackathon prototype, not production-secure, an official government channel, or a legal/eligibility authority.
