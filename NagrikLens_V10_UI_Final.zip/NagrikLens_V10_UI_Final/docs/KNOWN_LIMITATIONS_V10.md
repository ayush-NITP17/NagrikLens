# NagrikLens V10 Known Limitations

1. **Phase 1 report unavailable:** The supplied Phase 2 archive did not contain `PHASE_1_REPORT.md`; its `WIP_STATUS.md` identified unfinished Phase 1 work. See `PHASE_1_REPORT_STATUS.md`.
2. **No live Gemini verification in release tests:** The external provider was not called. A valid local key, network access, project/model access and quota are required to prove live generation.
3. **No live government website verification in release tests:** Website ingestion is covered by mocked HTTP/local fixtures. Current accessibility and content of external government hosts were not verified.
4. **Static HTML parsing:** JavaScript-rendered websites may produce incomplete or empty content. When possible, ingest the official PDF version.
5. **OCR dependency:** Scanned PDF OCR depends on Tesseract being installed with the configured language packs. Processing is bounded by page and time limits.
6. **No unrestricted crawler:** Linked PDFs are optional, bounded and restricted to the same host. No whole-domain crawler is provided.
7. **Prototype identity/security:** The shared API key is not user authentication and does not provide per-user ownership or multi-tenant data isolation. Admin approval uses a shared admin key.
8. **Legal and grounding limitations:** The validator is heuristic, not formal semantic entailment. A cited quotation is not a legal certification or guarantee that every generated paraphrase is correct.
9. **Eligibility extraction:** The deterministic engine evaluates extracted conditions, but it cannot guarantee that LLM-based extraction found every applicable eligibility rule or exception. “All extracted conditions met” is not an official eligibility decision.
10. **Version interpretation:** Text diffs are review aids. They do not establish that one version legally supersedes another.
11. **Browser test scope:** Phase 3 tests use real Chromium for UI behaviour but stub the API responses. FastAPI API tests exercise server endpoints separately. This is not a full deployed-browser/live-Gemini end-to-end test.
12. **Human verification:** For any consequential decision, verify the source document, current date, authority and applicable rules with the issuing department.
