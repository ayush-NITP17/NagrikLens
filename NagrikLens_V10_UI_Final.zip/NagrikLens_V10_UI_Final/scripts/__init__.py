"""NagrikLens evaluation and maintenance scripts."""
