from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from app.policy import expand_bilingual_query
from app.retrieval import retrieve
from app.store import init_db


def score_case(gold_ids: set[str], ranked_ids: list[str], should_abstain: bool, predicted_abstain: bool, top_k: int) -> dict[str, Any]:
    if should_abstain:
        return {
            "hit_at_1": None, "hit_at_3": None, "hit_at_5": None,
            "reciprocal_rank": None, "abstention_correct": predicted_abstain,
        }
    positions = [i + 1 for i, evidence_id in enumerate(ranked_ids[:top_k]) if evidence_id in gold_ids]
    first = min(positions) if positions else None
    return {
        "hit_at_1": bool(first and first <= 1),
        "hit_at_3": bool(first and first <= 3),
        "hit_at_5": bool(first and first <= 5),
        "reciprocal_rank": 1 / first if first else 0.0,
        "abstention_correct": None,
    }


def evaluate_file(input_path: Path, top_k: int = 5) -> dict[str, Any]:
    init_db()
    rows: list[dict[str, Any]] = []
    with input_path.open("r", encoding="utf-8") as handle:
        for line_no, line in enumerate(handle, start=1):
            if not line.strip():
                continue
            try:
                item = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"Invalid JSON on line {line_no}: {exc.msg}") from exc
            if not isinstance(item, dict) or not isinstance(item.get("question"), str):
                raise ValueError(f"Line {line_no} must contain a question string.")
            gold = item.get("gold_evidence_ids", [])
            if not isinstance(gold, list) or any(not isinstance(x, str) for x in gold):
                raise ValueError(f"Line {line_no} gold_evidence_ids must be a list of strings.")
            should_abstain = bool(item.get("should_abstain", False))
            if not should_abstain and not gold:
                raise ValueError(f"Line {line_no} needs gold_evidence_ids or should_abstain=true.")
            ranked = retrieve(expand_bilingual_query(item["question"]), k=top_k)
            # retrieve() already applies its absolute relevance/coverage gate;
            # no returned passages means the system abstained.
            predicted_abstain = not ranked
            ids = [] if predicted_abstain else [str(x.get("evidence_id")) for x in ranked]
            rows.append({
                "line": line_no,
                "question": item["question"],
                "gold_evidence_ids": gold,
                "retrieved_evidence_ids": ids,
                **score_case(set(gold), ids, should_abstain, predicted_abstain, top_k),
            })
    if not rows:
        raise ValueError("The labelled evaluation file is empty.")
    answerable = [x for x in rows if x["hit_at_1"] is not None]
    abstain_cases = [x for x in rows if x["abstention_correct"] is not None]
    def mean(key: str) -> float | None:
        values = [float(x[key]) for x in answerable]
        return round(sum(values) / len(values), 4) if values else None
    return {
        "questions": len(rows),
        "answerable_questions": len(answerable),
        "abstention_questions": len(abstain_cases),
        "hit_at_1": mean("hit_at_1"),
        "hit_at_3": mean("hit_at_3"),
        "hit_at_5": mean("hit_at_5"),
        "mrr": mean("reciprocal_rank"),
        "abstention_accuracy": (
            round(sum(bool(x["abstention_correct"]) for x in abstain_cases) / len(abstain_cases), 4)
            if abstain_cases else None
        ),
        "per_question": rows,
        "note": "Retrieval-only metrics. These do not prove answer correctness, legal interpretation or translation quality.",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Evaluate NagrikLens retrieval against team-labelled evidence IDs.")
    parser.add_argument("--input", required=True, type=Path, help="Team-created JSONL evaluation file")
    parser.add_argument("--top-k", type=int, default=5)
    args = parser.parse_args()
    if not args.input.is_file():
        print(f"Input file not found: {args.input}", file=sys.stderr)
        return 2
    try:
        result = evaluate_file(args.input, max(1, min(args.top_k, 20)))
    except (ValueError, OSError) as exc:
        print(str(exc), file=sys.stderr)
        return 2
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
