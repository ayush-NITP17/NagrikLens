"""Before/after retrieval benchmark on the synthetic multi-page PDF corpus.

Usage (run once per code base; the app root decides which version is measured):

    python scripts/compare_retrieval.py --app-root <path-to-NagrikLens-root> --out result.json

The script ingests the fixture PDFs through the code base's own PDF upload path,
then runs the dev and held-out question sets with the selected document scoped
(as a citizen asking about the document they uploaded). Metrics:

* recall@context   - share of gold facets present in the evidence the LLM would see
* precision@context - share of returned passages that come from a gold page
* hit@1            - first passage satisfies a gold facet
* abstention       - unsupported questions that correctly return no evidence
* latency          - wall-clock time of the evidence-gathering call

These are retrieval metrics on a small, synthetic, self-authored corpus. They are
not answer-correctness, legal-accuracy or translation-quality measurements.
"""
from __future__ import annotations

import argparse
import importlib
import json
import os
import statistics
import sys
import tempfile
import time
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--app-root", required=True, type=Path)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    app_root = args.app_root.resolve()

    tmp = Path(tempfile.mkdtemp(prefix="nl-bench-"))
    os.environ["NAGRIKLENS_DB_FILE"] = str(tmp / "bench.sqlite3")
    os.environ["LLM_API_KEY"] = ""  # retrieval only; never call a model
    sys.path.insert(0, str(app_root))
    sys.path.insert(1, str(HERE / "evaluation" / "fixtures"))
    corpus = importlib.import_module("corpus")
    store = importlib.import_module("app.store")
    ingestion = importlib.import_module("app.ingestion")
    policy = importlib.import_module("app.policy")
    retrieval = importlib.import_module("app.retrieval")
    store.DB_FILE = tmp / "bench.sqlite3"
    store.init_db()

    doc_ids: dict[str, str] = {}
    for key, spec in corpus.DOCUMENTS.items():
        data = corpus.build_document(key)
        if hasattr(ingestion, "process_pdf_bytes"):
            saved = ingestion.process_pdf_bytes(data, spec["filename"], mode="all")
        else:
            saved = ingestion.ingest_pdf_upload(data, spec["filename"])
        doc_ids[key] = saved["document_id"]

    import inspect
    # Phase 2 adds explicit document_ids and multi-facet evidence gathering in
    # build_response. Older V9 checkouts do not expose this argument and retain
    # the legacy direct-BM25 benchmark path.
    phase2_pipeline = "document_ids" in inspect.signature(policy.build_response).parameters
    version = "v10_phase2" if phase2_pipeline else "v9"

    def evidence_for(question: str, document_id: str) -> list[dict]:
        if phase2_pipeline:
            response = policy.build_response(
                question, requested_language="auto", profile={}, use_llm=False,
                require_live_sources=False, document_id=document_id, document_ids=[document_id],
            )
            return response.get("evidence", [])[:8]
        variants = policy.build_query_variants(question)
        return retrieval.retrieve(question, k=12, document_id=document_id, query_variants=variants)[:8]

    def satisfied(row: dict, facet: tuple) -> bool:
        key, page, phrase = facet
        return (row.get("document_id") == doc_ids[key] and row.get("page") == page
                and phrase.casefold() in (row.get("text") or "").casefold())

    def run(questions: list[dict]) -> dict:
        per = []
        for item in questions:
            start = time.perf_counter()
            rows = evidence_for(item["q"], doc_ids[item["doc"]])
            elapsed = (time.perf_counter() - start) * 1000
            gold = [tuple(x) for x in item["gold"]]
            gold_pages = {(doc_ids[k], p) for k, p, _ in gold}
            found = [f for f in gold if any(satisfied(r, f) for r in rows)]
            relevant_rows = [r for r in rows if (r.get("document_id"), r.get("page")) in gold_pages]
            per.append({
                "q": item["q"], "cat": item["cat"], "returned": len(rows),
                "pages": [r.get("page") for r in rows],
                "recall": (len(found) / len(gold)) if gold else None,
                "precision": (len(relevant_rows) / len(rows)) if (gold and rows) else (0.0 if gold else None),
                "hit1": (any(satisfied(rows[0], f) for f in gold) if rows else False) if gold else None,
                "abstained": not rows,
                "ms": round(elapsed, 2),
            })
        answerable = [x for x in per if x["recall"] is not None]
        unsupported = [x for x in per if x["cat"] == "unsupported"]
        cats = sorted({x["cat"] for x in answerable})

        def mean(values):
            values = list(values)
            return round(sum(values) / len(values), 4) if values else None

        return {
            "questions": len(per),
            "answerable": len(answerable),
            "recall_at_context": mean(x["recall"] for x in answerable),
            "full_recall_rate": mean(1.0 if x["recall"] == 1.0 else 0.0 for x in answerable),
            "precision_at_context": mean(x["precision"] for x in answerable),
            "hit_at_1": mean(1.0 if x["hit1"] else 0.0 for x in answerable),
            "answerable_wrongly_abstained": sum(1 for x in answerable if x["abstained"]),
            "unsupported_questions": len(unsupported),
            "unsupported_correctly_abstained": sum(1 for x in unsupported if x["abstained"]),
            "median_latency_ms": round(statistics.median(x["ms"] for x in per), 2),
            "max_latency_ms": round(max(x["ms"] for x in per), 2),
            "recall_by_category": {c: mean(x["recall"] for x in answerable if x["cat"] == c) for c in cats},
            "per_question": per,
        }

    result = {"version": version, "app_root": app_root.name,
              "dev": run(corpus.DEV_QUESTIONS), "heldout": run(corpus.HELDOUT_QUESTIONS)}
    text = json.dumps(result, ensure_ascii=False, indent=2)
    if args.out:
        args.out.write_text(text, encoding="utf-8")
    summary = {k: {m: v for m, v in result[k].items() if m != "per_question"} for k in ("dev", "heldout")}
    print(json.dumps({"version": version, **summary}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
