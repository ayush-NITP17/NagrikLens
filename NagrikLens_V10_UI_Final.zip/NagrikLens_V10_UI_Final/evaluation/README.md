# Retrieval evaluation (team-labelled, no bundled test answers)

This directory deliberately contains no pre-populated question/answer dataset. The team must label a genuine evaluation set against documents actually ingested into the local application.

Recommended set: 60–100 questions, including English, Hindi, Hinglish, numeric conditions, exceptions, amendment/date questions, conflict questions and unsupported questions. For each answerable question, reviewers should record the exact gold evidence IDs from the ingested document view. For questions that should abstain, use an empty `gold_evidence_ids` list and set `should_abstain` to `true`.

## JSONL schema

One JSON object per line:

```json
{"question":"What is the family income limit?","gold_evidence_ids":["<document-id>::p2-c0"],"language":"en","should_abstain":false}
```

The line above is a schema illustration only. It is not included as a test record or loaded by the app.

## Run

1. Start NagrikLens and ingest the genuine documents used in the benchmark.
2. Create your own labelled `.jsonl` file outside the runtime `data/` directory.
3. From the project root run:

```powershell
python -m scripts.evaluate_retrieval --input evaluation/my_labelled_questions.jsonl --top-k 5
```

The script reports Hit/Recall@1, @3, @5, MRR and abstention classification. This evaluates retrieval only; it does not measure legal correctness, semantic entailment, translation quality or the correctness of the gold labels. Keep the reviewed labels and evaluation run output with the final submission for judge inspection.
