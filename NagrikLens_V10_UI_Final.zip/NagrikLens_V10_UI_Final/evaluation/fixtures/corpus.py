"""Synthetic multi-page evaluation corpus for NagrikLens retrieval and PDF tests.

Every document here is FICTIONAL test material written for NagrikLens V10
evaluation. Scheme names, amounts, offices and dates are invented and must never
be presented as real government rules.

Each fixture is rendered into a genuine PDF (one PDF page per list entry), so the
evaluation exercises the same extraction path as a citizen upload. Nothing in
this module imports the application package; the same corpus can therefore be
ingested by the V9 and V10 code bases for before/after comparison.
"""
from __future__ import annotations

from typing import Any

FREESERIF = "/usr/share/fonts/truetype/freefont/FreeSerif.ttf"

# ---------------------------------------------------------------------------
# Document A: English, 12 pages. Facts deliberately spread across pages.
# ---------------------------------------------------------------------------
BALIKA_PAGES = [
    # page 1
    """Department of Women and Child Development (Fictional State)
MUKHYAMANTRI BALIKA SHIKSHA PROTSAHAN YOJANA - OPERATIONAL GUIDELINES 2026
1. Introduction
These guidelines describe the incentive scheme for girl students who complete
school and college education. The objective is to reduce drop-out of girls after
Class 10 and to encourage higher education among daughters of low-income families.
The scheme is administered through the Directorate of Women Empowerment.""",
    # page 2
    """2. Eligibility
2.1 The applicant must be a girl student who is a permanent resident of the State.
2.2 The applicant must have passed the Class 10 examination from a recognised board
or completed graduation from a recognised university in the State.
2.3 The applicant must be unmarried at the time of applying for the Class 10 incentive.
2.4 Only two daughters of the same family may receive benefits under this scheme.""",
    # page 3
    """3. Definitions
3.1 "Family" means the father, mother, unmarried brothers and sisters of the applicant.
3.2 "Recognised board" means a school examination board approved by the State
Government or the Central Government.
3.3 "Sanctioning Officer" means the District Programme Officer of the district in
which the applicant permanently resides.""",
    # page 4
    """4. Benefit amount
The incentive is a direct benefit transfer to the bank account of the girl student.
The amounts payable are listed in the table below.
Stage | Incentive amount | Mode
Class 10 passed | Rs 10,000 | Single instalment
Graduation completed | Rs 25,000 | Single instalment
The incentive is paid only once for each stage.""",
    # page 5
    """5. Payment schedule
5.1 For the first daughter the incentive is released in a single instalment within
60 days of sanction.
5.2 For the second daughter the incentive is released in two equal instalments: the
first instalment on sanction and the second instalment after six months.
5.3 No interest is payable on delayed payment.""",
    # page 6
    """6. How to apply
6.1 Applications shall be submitted online on the State scholarship portal.
6.2 An applicant without internet access may apply through the nearest Common
Service Centre, which shall upload the form free of charge.
6.3 After submission the applicant receives an acknowledgement number by SMS.""",
    # page 7
    """7. Timeline and last date
7.1 The portal opens on 1 August 2026.
7.2 The last date for submitting applications is 30 November 2026.
7.3 Applications received after the last date shall not be considered for the
financial year 2026-27.""",
    # page 8
    """8. Income ceiling
8.1 The annual family income from all sources must not exceed Rs 2,50,000.
8.2 Income shall be certified by an income certificate issued by the Circle Officer
within the last twelve months.
8.3 Families holding an Antyodaya ration card are deemed to satisfy the income
ceiling.""",
    # page 9
    """9. Exclusions and exceptions
9.1 A girl student whose parent is a regular employee of the State or Central
Government is not eligible.
9.2 Exception: the daughter of a Group D employee is eligible notwithstanding
clause 9.1.
9.3 A student who has already received a similar incentive from any other State
scheme for the same stage is not eligible.""",
    # page 10
    """10. Documents required
The applicant must upload the following documents:
(a) Aadhaar card of the girl student;
(b) residence certificate;
(c) income certificate;
(d) Class 10 marksheet or graduation degree certificate;
(e) first page of the bank passbook showing the account number and IFSC.
A passport-size photograph is optional.""",
    # page 11
    """11. Verification and grievance redressal
11.1 Applications are verified by the Block Development Officer within 30 days.
11.2 Sanction orders are issued by the District Programme Officer.
11.3 A grievance may be filed with the District Grievance Redressal Officer within
45 days of rejection. The grievance officer shall decide within 30 days.""",
    # page 12
    """12. Penalty for false information
12.1 If any information or document submitted is found to be false, the entire
incentive shall be recovered from the beneficiary with interest at 12% per annum.
12.2 The applicant shall be debarred from all schemes of the Department for five years.
12.3 Officials who knowingly approve false applications face disciplinary action.""",
]

# ---------------------------------------------------------------------------
# Document B: Hindi, 5 pages.
# ---------------------------------------------------------------------------
PENSION_HI_PAGES = [
    """मुख्यमंत्री वृद्धजन सम्मान पेंशन योजना दिशानिर्देश (काल्पनिक)
1. परिचय
यह योजना राज्य के बुजुर्ग नागरिकों को सामाजिक सुरक्षा देने के लिए है।""",
    """2. पात्रता
2.1 आवेदक की आयु 60 वर्ष या उससे अधिक होनी चाहिए।
2.2 आवेदक राज्य का स्थायी निवासी होना चाहिए।
2.3 आवेदक किसी अन्य सरकारी पेंशन का लाभ नहीं ले रहा हो।""",
    """3. पेंशन राशि
3.1 60 से 79 वर्ष के लाभार्थी को 400 रुपये प्रतिमाह पेंशन दी जाएगी।
3.2 80 वर्ष या उससे अधिक आयु के लाभार्थी को 500 रुपये प्रतिमाह पेंशन दी जाएगी।
3.3 राशि सीधे बैंक खाते में भेजी जाएगी।""",
    """4. आवेदन और दस्तावेज
4.1 आवेदन प्रखंड विकास कार्यालय में जमा किया जाएगा।
4.2 आवश्यक दस्तावेज: आधार कार्ड, आयु प्रमाण पत्र, निवास प्रमाण पत्र और बैंक पासबुक।
4.3 आवेदन पर निर्णय 21 दिनों के भीतर लिया जाएगा।""",
    """5. गलत जानकारी पर दंड
5.1 गलत जानकारी देने पर पूरी पेंशन राशि वसूल की जाएगी।
5.2 ऐसे व्यक्ति को तीन वर्ष तक योजना से बाहर रखा जाएगा।""",
]

# ---------------------------------------------------------------------------
# Document C: English distractor, 6 pages, with a fee table.
# ---------------------------------------------------------------------------
SHOP_PAGES = [
    """SHOPS AND COMMERCIAL ESTABLISHMENTS REGISTRATION RULES 2026 (FICTIONAL)
Rule 1. Short title
These rules apply to every shop and commercial establishment in urban local bodies.""",
    """Rule 2. Registration
Every employer shall apply for registration of the establishment within 30 days of
commencing business. Registration is granted by the Labour Inspector of the ward.""",
    """Rule 3. Registration fee
Establishment size | Fee
Up to 9 workers | Rs 250
10 to 49 workers | Rs 1,000
50 or more workers | Rs 5,000
The fee is payable once at the time of registration.""",
    """Rule 4. Working hours
No worker shall be required to work for more than nine hours in any day or 48 hours
in any week. A weekly holiday is mandatory.""",
    """Rule 5. Renewal
Registration certificates are valid for five years and must be renewed 60 days
before expiry.""",
    """Rule 6. Penalties
An employer who runs an establishment without registration is liable to a fine of
Rs 10,000. Repeated violation attracts a fine of Rs 25,000.""",
]

DOCUMENTS: dict[str, dict[str, Any]] = {
    "balika": {"filename": "balika_guidelines_2026.pdf", "pages": BALIKA_PAGES, "font": None},
    "pension_hi": {"filename": "vridhjan_pension_hi.pdf", "pages": PENSION_HI_PAGES, "font": FREESERIF},
    "shop": {"filename": "shop_registration_rules.pdf", "pages": SHOP_PAGES, "font": None},
}


def build_pdf(pages: list[str], font_file: str | None = None, scanned_pages: set[int] | None = None,
              blank_pages: set[int] | None = None, dpi: int = 200) -> bytes:
    """Render pages to a real PDF.

    ``scanned_pages`` (1-based) are rendered as image-only pages: the text is
    drawn, rasterised and the raster is embedded on a fresh page with no text
    layer, imitating a scanned sheet. ``blank_pages`` get no content at all.
    """
    import fitz  # PyMuPDF

    scanned_pages = scanned_pages or set()
    blank_pages = blank_pages or set()
    doc = fitz.open()
    for number, text in enumerate(pages, start=1):
        page = doc.new_page(width=595, height=842)
        if number in blank_pages:
            continue
        if number in scanned_pages:
            scratch = fitz.open()
            sp = scratch.new_page(width=595, height=842)
            # insert_htmlbox shapes complex scripts (Devanagari) for a faithful
            # visual rendering; the extracted text layer is discarded anyway.
            html = "".join(f"<p>{line}</p>" for line in text.splitlines() if line.strip())
            css = "p { font-family: sans-serif; font-size: 13pt; margin: 0 0 6pt 0; }"
            if font_file:
                css = "@font-face {font-family: dev; src: url(FreeSerif.ttf);} p { font-family: dev; font-size: 14pt; margin: 0 0 6pt 0; }"
                import os
                archive = fitz.Archive(os.path.dirname(font_file))
                sp.insert_htmlbox(fitz.Rect(50, 50, 545, 800), html, css=css, archive=archive)
            else:
                sp.insert_htmlbox(fitz.Rect(50, 50, 545, 800), html, css=css)
            pix = sp.get_pixmap(dpi=dpi)
            page.insert_image(page.rect, stream=pix.tobytes("png"))
            scratch.close()
            continue
        y = 60
        if font_file:
            page.insert_font(fontname="dev", fontfile=font_file)
        for line in text.splitlines():
            if y > 800:
                break
            page.insert_text((50, y), line, fontsize=11, fontname="dev" if font_file else "helv")
            y += 16
    data = doc.tobytes()
    doc.close()
    return data


def build_document(key: str, **kwargs: Any) -> bytes:
    spec = DOCUMENTS[key]
    return build_pdf(spec["pages"], spec["font"], **kwargs)


def long_guideline_pages(total: int = 100) -> list[str]:
    """A long guideline: facts on pages 2, 7, 8 and 10; generic filler elsewhere.

    Filler pages use administrative vocabulary (committee, monitoring, audit) so
    that they are plausible distractors, not random noise.
    """
    special = {
        2: "Part 2. Eligibility of beneficiaries\nThe scheme is open to landless agricultural labourers who are residents of the State and aged between 18 and 59 years.",
        7: "Part 7. Closing date\nThe last date for applying for the labour welfare card is 15 January 2027. Late applications will be rejected.",
        8: "Part 8. Annual income threshold\nThe annual household income of the labourer must not exceed Rs 1,80,000.",
        10: "Part 10. Required papers\nApplicants must submit Aadhaar card, a job card issued under the rural employment programme, and a bank passbook.",
        57: "Part 57. Accident cover\nA registered labourer receives accident insurance cover of Rs 2,00,000 in case of accidental death.",
        93: "Part 93. Appeals\nAn appeal against rejection lies to the Sub-Divisional Officer within 30 days.",
    }
    topics = ["district monitoring committee meetings", "quarterly progress review", "audit of welfare fund accounts",
              "training of field functionaries", "information education and communication activities",
              "convergence with line departments", "data entry and record keeping standards"]
    pages = []
    for n in range(1, total + 1):
        if n in special:
            pages.append(special[n])
        else:
            topic = topics[n % len(topics)]
            pages.append(
                f"Part {n}. Administrative procedure on {topic}\n"
                f"This part sets out internal procedure number {n} concerning {topic}. "
                f"Officers shall maintain a register of {topic} and submit a report to the "
                f"State nodal office in the format prescribed in Annexure {n}."
            )
    return pages


# ---------------------------------------------------------------------------
# Labelled questions.
# gold: list of facets; each facet = (document key, page, required phrase).
# A retrieved chunk satisfies a facet when it is from that document and page and
# contains the phrase (case-insensitive). Recall = satisfied facets / facets.
# ---------------------------------------------------------------------------
# DEV set: used while developing retrieval changes.
DEV_QUESTIONS: list[dict[str, Any]] = [
    {"q": "What is the last date to apply?", "doc": "balika", "cat": "exact", "gold": [("balika", 7, "30 November 2026")]},
    {"q": "What is the income limit for this scheme?", "doc": "balika", "cat": "exact", "gold": [("balika", 8, "2,50,000")]},
    {"q": "Which documents do I need to upload?", "doc": "balika", "cat": "exact", "gold": [("balika", 10, "residence certificate")]},
    {"q": "How much money is given after graduation?", "doc": "balika", "cat": "paraphrase", "gold": [("balika", 4, "25,000")]},
    {"q": "Who decides my complaint if my form is rejected?", "doc": "balika", "cat": "vocab_gap", "gold": [("balika", 11, "Grievance Redressal Officer")]},
    {"q": "What happens if I give fake papers?", "doc": "balika", "cat": "vocab_gap", "gold": [("balika", 12, "recovered")]},
    {"q": "Who is eligible, what is the income limit, which documents are needed and what is the deadline?", "doc": "balika", "cat": "multi_page",
     "gold": [("balika", 2, "permanent resident"), ("balika", 8, "2,50,000"), ("balika", 10, "income certificate"), ("balika", 7, "30 November 2026")]},
    {"q": "Is the second daughter paid in instalments?", "doc": "balika", "cat": "exact", "gold": [("balika", 5, "two equal instalments")]},
    {"q": "छात्रवृत्ति के लिए अंतिम तारीख क्या है?", "doc": "balika", "cat": "cross_language", "gold": [("balika", 7, "last date")]},
    {"q": "pension ke liye umar kitni honi chahiye", "doc": "pension_hi", "cat": "hinglish", "gold": [("pension_hi", 2, "60 वर्ष")]},
    {"q": "पेंशन कितनी मिलती है?", "doc": "pension_hi", "cat": "exact", "gold": [("pension_hi", 3, "400 रुपये")]},
    {"q": "What is the registration fee for a shop with 20 workers?", "doc": "shop", "cat": "table", "gold": [("shop", 3, "1,000")]},
    {"q": "What is the penalty for running a shop without registration?", "doc": "shop", "cat": "exact", "gold": [("shop", 6, "10,000")]},
    {"q": "What is the capital of France?", "doc": "balika", "cat": "unsupported", "gold": []},
    {"q": "What is the interest rate on crop loans?", "doc": "balika", "cat": "unsupported", "gold": []},
    {"q": "Does this scheme give a free laptop to every girl?", "doc": "balika", "cat": "misleading", "gold": []},
]

# HELD-OUT set: written together with the dev set before any V10 retrieval change,
# never used for tuning. Results on this set are reported separately.
HELDOUT_QUESTIONS: list[dict[str, Any]] = [
    {"q": "By when must the form be submitted?", "doc": "balika", "cat": "paraphrase", "gold": [("balika", 7, "30 November 2026")]},
    {"q": "My parents earn 3 lakh a year, what is the maximum family earning allowed?", "doc": "balika", "cat": "natural", "gold": [("balika", 8, "2,50,000")]},
    {"q": "Can a girl whose father is a government employee get this money?", "doc": "balika", "cat": "natural", "gold": [("balika", 9, "regular employee")]},
    {"q": "Is there any exception for Group D staff children?", "doc": "balika", "cat": "exact", "gold": [("balika", 9, "Group D")]},
    {"q": "How much is paid to a girl who passed class 10?", "doc": "balika", "cat": "table", "gold": [("balika", 4, "10,000")]},
    {"q": "I don't have internet. Where can I fill the form?", "doc": "balika", "cat": "vocab_gap", "gold": [("balika", 6, "Common Service Centre")]},
    {"q": "Which office issues the income certificate?", "doc": "balika", "cat": "exact", "gold": [("balika", 8, "Circle Officer")]},
    {"q": "Who verifies the application and who sanctions it?", "doc": "balika", "cat": "multi_page", "gold": [("balika", 11, "Block Development Officer"), ("balika", 11, "District Programme Officer")]},
    {"q": "Tell me the eligibility conditions, the income ceiling, the papers to upload and the closing date.", "doc": "balika", "cat": "multi_page",
     "gold": [("balika", 2, "permanent resident"), ("balika", 8, "2,50,000"), ("balika", 10, "passbook"), ("balika", 7, "30 November 2026")]},
    {"q": "How many daughters of one family can benefit and how is the second daughter paid?", "doc": "balika", "cat": "multi_page",
     "gold": [("balika", 2, "two daughters"), ("balika", 5, "second daughter")]},
    {"q": "Is a photograph compulsory?", "doc": "balika", "cat": "exact", "gold": [("balika", 10, "optional")]},
    {"q": "पात्रता की शर्तें क्या हैं?", "doc": "balika", "cat": "cross_language", "gold": [("balika", 2, "eligibility")]},
    {"q": "आय सीमा कितनी है?", "doc": "balika", "cat": "cross_language", "gold": [("balika", 8, "2,50,000")]},
    {"q": "documents kaun kaun se chahiye", "doc": "balika", "cat": "hinglish", "gold": [("balika", 10, "income certificate")]},
    {"q": "What age is required for the old age pension?", "doc": "pension_hi", "cat": "cross_language", "gold": [("pension_hi", 2, "60 वर्ष")]},
    {"q": "पेंशन के लिए कौन से कागजात चाहिए?", "doc": "pension_hi", "cat": "exact", "gold": [("pension_hi", 4, "आधार कार्ड")]},
    {"q": "80 साल से ज्यादा उम्र वालों को कितनी पेंशन मिलेगी?", "doc": "pension_hi", "cat": "exact", "gold": [("pension_hi", 3, "500 रुपये")]},
    {"q": "गलत जानकारी देने पर क्या होगा?", "doc": "pension_hi", "cat": "exact", "gold": [("pension_hi", 5, "वसूल")]},
    {"q": "How long is the registration certificate valid?", "doc": "shop", "cat": "exact", "gold": [("shop", 5, "five years")]},
    {"q": "How many hours can a worker be made to work in a day?", "doc": "shop", "cat": "paraphrase", "gold": [("shop", 4, "nine hours")]},
    {"q": "Fee for a big establishment with 60 employees?", "doc": "shop", "cat": "table", "gold": [("shop", 3, "5,000")]},
    {"q": "Who gives the registration?", "doc": "shop", "cat": "exact", "gold": [("shop", 2, "Labour Inspector")]},
    {"q": "What is the GST rate on restaurant food?", "doc": "shop", "cat": "unsupported", "gold": []},
    {"q": "Who won the cricket world cup?", "doc": "balika", "cat": "unsupported", "gold": []},
    {"q": "पासपोर्ट बनवाने की फीस कितनी है?", "doc": "pension_hi", "cat": "unsupported", "gold": []},
    {"q": "Since boys also get Rs 25,000, how does my son apply?", "doc": "balika", "cat": "misleading", "gold": [("balika", 2, "girl student")]},
]
