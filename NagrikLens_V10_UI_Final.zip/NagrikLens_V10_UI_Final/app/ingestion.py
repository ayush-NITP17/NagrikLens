from __future__ import annotations

import hashlib
import ipaddress
import re
import shutil
import socket
import subprocess
import tempfile
import time
from pathlib import Path
from typing import Any
from urllib.parse import urljoin, urlparse, urlunparse

import fitz
import requests
from bs4 import BeautifulSoup

from .config import (
    ALLOWED_SOURCE_HOSTS, DEFAULT_MAX_LINKED_PDFS, DEFAULT_MAX_PAGES, MAX_CHUNK_CHARS, MAX_EXTRACTED_CHARS, MAX_HTML_CHARS,
    MAX_OCR_PAGES, MAX_PDF_PAGES, MAX_PROCESS_PAGES, MAX_SOURCE_BYTES, MAX_UPLOAD_BYTES,
    MIN_TEXT_CHARS_PER_PAGE, OCR_DPI, OCR_ENABLED, OCR_LANGUAGES, OCR_PAGE_TIMEOUT_SECONDS, REQUEST_TIMEOUT,
)
from .store import (
    get_effective_allowed_source_hosts, record_source_host_request, upsert_document, utcnow,
)

HEADERS = {
    "User-Agent": "NagrikLens/1.0 (citizen policy explainer; source-fetch request)",
    "Accept": "application/pdf,text/html,application/xhtml+xml;q=0.9,*/*;q=0.1",
}


class IngestionError(ValueError):
    pass


def _stable_id(prefix: str, value: str) -> str:
    digest = hashlib.sha256(value.encode("utf-8", errors="ignore")).hexdigest()[:16]
    return f"{prefix}-{digest}"


def _authority_status_for_host(hostname: str) -> str:
    host = (hostname or "").lower().rstrip(".")
    if host.endswith((".gov.in", ".nic.in")) or host in {"gov.in", "nic.in"}:
        return "OFFICIAL_DOMAIN_NOT_DOCUMENT_AUTHENTICATED"
    return "ALLOWLISTED_HOST_NOT_GOVERNMENT_VERIFIED"


def _validate_public_dns(host: str) -> None:
    """Reject all non-global DNS answers before connecting.

    This application-level check reduces SSRF exposure but does not eliminate
    DNS-rebinding TOCTOU. Public deployment also requires network egress controls.
    """
    try:
        answers = socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM)
    except OSError as exc:
        raise IngestionError(f"Could not resolve the approved source host: {type(exc).__name__}") from exc
    if not answers:
        raise IngestionError("The approved source host did not resolve to an IP address.")
    for answer in answers:
        ip = ipaddress.ip_address(answer[4][0].split("%", 1)[0])
        if not ip.is_global:
            raise IngestionError("The source host resolved to a non-public IP address and was blocked.")


def validate_source_url(url: str) -> str:
    if not isinstance(url, str) or len(url) > 2048:
        raise IngestionError("Enter a valid HTTPS URL under 2,048 characters.")
    parsed = urlparse(url.strip())
    host = (parsed.hostname or "").lower().rstrip(".")
    if parsed.scheme.lower() != "https":
        raise IngestionError("Only HTTPS source URLs are accepted.")
    try:
        port = parsed.port
    except ValueError as exc:
        raise IngestionError("The URL contains an invalid port.") from exc
    if not host or parsed.username or parsed.password or port not in (None, 443):
        raise IngestionError("The URL has an invalid host, credentials or port.")
    try:
        allowed = set(get_effective_allowed_source_hosts())
    except Exception:
        allowed = set(ALLOWED_SOURCE_HOSTS)
    if host not in allowed:
        try:
            record_source_host_request(host, "PENDING")
        except Exception:
            pass
        raise IngestionError(
            f"Source host '{host}' is not allowlisted. This exact hostname requires administrator approval before server-side fetching."
        )
    if parsed.fragment:
        parsed = parsed._replace(fragment="")
    _validate_public_dns(host)
    return urlunparse(parsed)


def _bounded_get(url: str) -> tuple[bytes, requests.Response]:
    """Fetch bounded HTTPS content; revalidate every redirect destination."""
    current_url = url
    max_redirects = 3
    try:
        for redirect_count in range(max_redirects + 1):
            safe_url = validate_source_url(current_url)
            response = requests.get(
                safe_url, headers=HEADERS, timeout=REQUEST_TIMEOUT,
                allow_redirects=False, stream=True,
            )
            if 300 <= response.status_code < 400:
                location = response.headers.get("Location", "")
                response.close()
                if not location:
                    raise IngestionError("The source returned a redirect without a destination URL.")
                if redirect_count >= max_redirects:
                    raise IngestionError("The source exceeded the maximum of three safe redirects.")
                current_url = urljoin(safe_url, location)
                validate_source_url(current_url)
                continue
            response.raise_for_status()
            final_url = getattr(response, "url", safe_url) or safe_url
            # A mocked or unusual response must not be able to report an
            # unvalidated final URL, even though requests redirects are disabled.
            validate_source_url(final_url)
            length = response.headers.get("Content-Length")
            if length:
                try:
                    declared_length = int(length)
                except (TypeError, ValueError):
                    response.close()
                    raise IngestionError("The source returned an invalid Content-Length header.")
                if declared_length < 0:
                    response.close()
                    raise IngestionError("The source returned an invalid Content-Length header.")
                if declared_length > MAX_SOURCE_BYTES:
                    response.close()
                    raise IngestionError(f"Source exceeds the configured {MAX_SOURCE_BYTES}-byte download limit.")
            chunks: list[bytes] = []
            total = 0
            for block in response.iter_content(chunk_size=64 * 1024):
                if not block:
                    continue
                total += len(block)
                if total > MAX_SOURCE_BYTES:
                    response.close()
                    raise IngestionError(f"Source exceeded the configured {MAX_SOURCE_BYTES}-byte download limit while downloading.")
                chunks.append(block)
            return b"".join(chunks), response
        raise IngestionError("The source could not be retrieved safely.")
    except IngestionError:
        raise
    except requests.Timeout as exc:
        raise IngestionError("Source fetch timed out. Try again later.") from exc
    except requests.RequestException as exc:
        raise IngestionError(f"Source fetch failed: {type(exc).__name__}.") from exc


def _heading_match(line: str) -> str | None:
    clean = line.strip()
    if not clean:
        return None
    if re.match(r"^SECTION:\s*", clean, re.I):
        return clean.split(":", 1)[1].strip()[:180] or "Document section"
    if re.match(r"^(?:section|sec\.?|rule|chapter|article|schedule|धारा|नियम|अध्याय)\s+[0-9A-Za-z()./-]+", clean, re.I):
        return clean[:180]
    if re.match(r"^\d+(?:\.\d+)*[.)]?\s+[A-Zअ-ह]", clean):
        return clean[:180]
    if len(clean) <= 120 and clean.isupper() and len(clean.split()) <= 12:
        return clean
    return None


def _split_page_text(text: str, page: int | None) -> list[dict[str, Any]]:
    text = re.sub(r"\r", "\n", text or "")
    text = re.sub(r"\n{3,}", "\n\n", text).strip()
    if not text:
        return []
    chunks: list[dict[str, Any]] = []
    current_heading = "Document text"
    start = 0
    idx = 0
    while start < len(text):
        # Carry the most recent heading forward into the chunk, even when it
        # appeared near the end of the preceding chunk.
        for line in text[:start].splitlines():
            matched = _heading_match(line)
            if matched:
                current_heading = matched
        end = min(len(text), start + MAX_CHUNK_CHARS)
        if end < len(text):
            boundary = max(text.rfind("\n\n", start, end), text.rfind(". ", start, end), text.rfind("\n", start, end))
            if boundary > start + int(MAX_CHUNK_CHARS * 0.55):
                end = boundary + (2 if text[boundary:boundary+2] == "\n\n" else 1)
        piece = text[start:end].strip()
        if piece:
            for line in piece.splitlines():
                matched = _heading_match(line)
                if matched:
                    current_heading = matched
                    break
            chunks.append({
                "evidence_id": f"p{page or 0}-c{idx}", "chunk_index": idx,
                "section": current_heading, "page": page, "text": piece,
            })
            idx += 1
        if end >= len(text):
            break
        start = max(start + 1, end - 220)
    return chunks


def _parse_page_selection(page_count: int, page_mode: str = "all", max_page_number: int | None = None,
                          selected_pages: list[int] | str | None = None) -> list[int]:
    mode = (page_mode or "all").strip().lower()
    if mode in {"max", "max_page", "maximum"}:
        maximum = max_page_number if max_page_number is not None else min(DEFAULT_MAX_PAGES, page_count)
        if isinstance(maximum, bool) or not isinstance(maximum, int) or maximum < 1:
            raise IngestionError("Maximum page number must be a positive integer.")
        if maximum > page_count:
            raise IngestionError(f"Maximum page number {maximum} exceeds the PDF page count ({page_count}).")
        pages = list(range(1, maximum + 1))
    elif mode in {"specific", "selected"}:
        if isinstance(selected_pages, str):
            try:
                values = [int(x.strip()) for x in selected_pages.split(",") if x.strip()]
            except ValueError as exc:
                raise IngestionError("Specific pages must be comma-separated positive integers, for example 2,8,10.") from exc
        else:
            values = list(selected_pages or [])
        if not values:
            raise IngestionError("Enter at least one page number to process.")
        if any(isinstance(x, bool) or not isinstance(x, int) for x in values):
            raise IngestionError("Specific pages must be integers.")
        pages = sorted(set(values))
        invalid = [x for x in pages if x < 1 or x > page_count]
        if invalid:
            raise IngestionError(f"Selected page(s) {invalid} are outside the PDF page range 1–{page_count}.")
    elif mode in {"all", "entire"}:
        pages = list(range(1, page_count + 1))
    else:
        raise IngestionError("Page mode must be 'max_page', 'specific' or 'all'.")
    if len(pages) > MAX_PROCESS_PAGES:
        raise IngestionError(f"This selection contains {len(pages)} pages, above the configured per-request processing limit of {MAX_PROCESS_PAGES}. Select fewer pages or adjust MAX_PROCESS_PAGES.")
    return pages




def _ocr_page_with_timeout(page) -> str:
    """Run Tesseract as a bounded subprocess so a malformed page cannot hang ingestion."""
    if not shutil.which("tesseract"):
        raise IngestionError("Tesseract is not installed.")
    pixmap = page.get_pixmap(dpi=OCR_DPI, alpha=False)
    with tempfile.TemporaryDirectory(prefix="nagriklens-ocr-") as temp_dir:
        image_path = Path(temp_dir) / "page.png"
        pixmap.save(str(image_path))
        try:
            completed = subprocess.run(
                ["tesseract", str(image_path), "stdout", "-l", OCR_LANGUAGES, "--psm", "6"],
                capture_output=True, text=True, timeout=OCR_PAGE_TIMEOUT_SECONDS, check=False,
            )
        except subprocess.TimeoutExpired as exc:
            raise IngestionError(f"OCR exceeded the {OCR_PAGE_TIMEOUT_SECONDS}-second page timeout.") from exc
        if completed.returncode != 0:
            detail = (completed.stderr or "").strip()[:240]
            raise IngestionError("Tesseract OCR failed" + (f": {detail}" if detail else "."))
        return (completed.stdout or "").strip()


def _pdf_pages(data: bytes, page_mode: str = "all", max_page_number: int | None = None,
               selected_pages: list[int] | str | None = None) -> tuple[str, int, list[dict[str, Any]], str | None, dict[str, Any], list[int]]:
    started = time.perf_counter()
    try:
        pdf = fitz.open(stream=data, filetype="pdf")
    except Exception as exc:
        raise IngestionError("The uploaded/downloaded file is not a readable PDF.") from exc
    if pdf.is_encrypted:
        pdf.close()
        raise IngestionError("Password-protected PDFs are not supported. Upload an unlocked copy.")
    page_count = len(pdf)
    if page_count == 0 or page_count > MAX_PDF_PAGES:
        pdf.close()
        raise IngestionError(f"PDF must contain between 1 and {MAX_PDF_PAGES} pages.")
    pages_selected = _parse_page_selection(page_count, page_mode, max_page_number, selected_pages)
    raw_pages: list[str] = []
    evidence: list[dict[str, Any]] = []
    extracted_pages: list[int] = []
    ocr_pages: list[int] = []
    unreadable_pages: list[int] = []
    failed_pages: list[dict[str, Any]] = []
    extracted_chars = 0
    tesseract_available = bool(shutil.which("tesseract"))
    for page_no in pages_selected:
        page = pdf[page_no - 1]
        page_text = ""
        try:
            page_text = page.get_text("text", sort=True).strip()
            if len(page_text) < MIN_TEXT_CHARS_PER_PAGE and OCR_ENABLED and tesseract_available and len(ocr_pages) < MAX_OCR_PAGES:
                try:
                    ocr_text = _ocr_page_with_timeout(page).strip()
                    if len(ocr_text) > len(page_text):
                        page_text = ocr_text
                        ocr_pages.append(page_no)
                except Exception as ocr_exc:
                    failed_pages.append({"page": page_no, "reason": f"OCR failed: {type(ocr_exc).__name__}: {str(ocr_exc)[:180]}"})
            if len(page_text) < MIN_TEXT_CHARS_PER_PAGE:
                unreadable_pages.append(page_no)
            else:
                extracted_pages.append(page_no)
                extracted_chars += len(page_text)
                if extracted_chars > MAX_EXTRACTED_CHARS:
                    raise IngestionError(f"Extracted text exceeds the {MAX_EXTRACTED_CHARS:,}-character safety limit. Upload a smaller or relevant excerpt.")
                evidence.extend(_split_page_text(page_text, page_no))
                raw_pages.append(f"[PDF PAGE {page_no}]\n{page_text}")
        except IngestionError:
            pdf.close()
            raise
        except Exception as exc:
            failed_pages.append({"page": page_no, "reason": f"Extraction failed: {type(exc).__name__}"})
    pdf.close()
    if not evidence:
        reason = "No extractable text was found in the selected pages. This may be a scanned PDF; OCR may require Tesseract and configured language packs."
        raise IngestionError(reason)
    partial = bool(unreadable_pages or failed_pages)
    note_parts = []
    if unreadable_pages:
        note_parts.append(f"{len(unreadable_pages)} page(s) contain little extractable text: {unreadable_pages}. OCR unavailable, disabled, over limit or unsuccessful; verify these pages manually.")
    if failed_pages:
        note_parts.append(f"Page extraction failures: {failed_pages}.")
    if len(pages_selected) < page_count:
        not_processed = sorted(set(range(1, page_count + 1)) - set(pages_selected))
        note_parts.append(f"Only selected pages were processed. Not processed: {not_processed[:30]}" + (" ..." if len(not_processed) > 30 else "") + ".")
    note = " ".join(note_parts) or None
    not_processed_pages = sorted(set(range(1, page_count + 1)) - set(pages_selected))
    selected_scope_complete = not partial and len(extracted_pages) == len(pages_selected)
    overall_completeness = selected_scope_complete and not not_processed_pages
    report = {
        "total_pages": page_count, "selected_pages": pages_selected,
        "extracted_pages": extracted_pages, "ocr_pages": ocr_pages,
        "unreadable_pages": unreadable_pages, "failed_pages": failed_pages,
        "text_length": extracted_chars, "chunk_count": len(evidence),
        "processing_duration_ms": round((time.perf_counter() - started) * 1000, 2),
        # COMPLETE means the whole PDF was processed. A fully processed subset
        # is explicitly PARTIAL at document level, even if the selected scope succeeded.
        "processing_status": "COMPLETE" if overall_completeness else "PARTIAL",
        "selected_scope_complete": selected_scope_complete,
        "indexing_status": "INDEXED" if evidence else "FAILED",
        "overall_completeness": overall_completeness,
        "not_processed_pages": not_processed_pages,
        "ocr_available": tesseract_available and OCR_ENABLED,
    }
    return "\n\n".join(raw_pages), page_count, evidence, note, report, pages_selected


def _html_document_detail(data: bytes) -> tuple[str, str, list[dict[str, str]], list[str]]:
    try:
        html = data.decode("utf-8", errors="replace")
    except Exception as exc:
        raise IngestionError("The HTML page could not be decoded.") from exc
    soup = BeautifulSoup(html, "html.parser")
    title = soup.title.get_text(" ", strip=True) if soup.title else ""
    for element in soup(["script", "style", "noscript", "svg", "nav", "footer", "header", "form"]):
        element.decompose()
    main = soup.find("main") or soup.find("article") or soup.find(id=re.compile("content|Content")) or soup.body or soup
    sections: list[dict[str, str]] = []
    lines: list[str] = []
    current_section = "Document body"
    linked_pdfs: list[str] = []
    for node in main.find_all(["h1", "h2", "h3", "h4", "h5", "h6", "p", "li", "table"]):
        if node.name.startswith("h"):
            heading = node.get_text(" ", strip=True)
            if heading:
                current_section = heading[:180]
                lines.extend([f"\nSECTION: {current_section}"])
                sections.append({"heading": current_section, "text": ""})
        elif node.name == "table":
            rows = []
            for tr in node.find_all("tr"):
                cells = [re.sub(r"\s+", " ", cell.get_text(" ", strip=True)) for cell in tr.find_all(["th", "td"])]
                if cells:
                    rows.append(" | ".join(cells))
            table_text = "\n".join(rows)
            if table_text:
                lines.append(f"TABLE ({current_section}):\n{table_text}")
                sections.append({"heading": current_section, "text": table_text})
        else:
            text = re.sub(r"\s+", " ", node.get_text(" ", strip=True))
            if text:
                lines.append(text)
                sections.append({"heading": current_section, "text": text})
    for anchor in main.find_all("a", href=True):
        href = urljoin("https://invalid.local/", anchor["href"])
        if urlparse(href).path.lower().endswith(".pdf"):
            linked_pdfs.append(anchor["href"])
    text = re.sub(r"\n{3,}", "\n\n", "\n".join(lines)).strip()
    if len(text) < 60:
        # Fallback for simple fixture pages or uncommon semantic markup.
        text = re.sub(r"\n{3,}", "\n\n", main.get_text("\n", strip=True)).strip()
    if len(text) < 60:
        raise IngestionError("The page yielded too little readable text. It may be JavaScript-rendered or block automated access; upload its official PDF instead.")
    return title, text, sections, list(dict.fromkeys(linked_pdfs))


def _html_document(data: bytes) -> tuple[str, str]:
    title, text, _, _ = _html_document_detail(data)
    return title, text


def _store_pdf_source(data: bytes, source_url: str, title: str, jurisdiction: str,
                      authority_status: str, provenance: str, page_mode: str,
                      max_page_number: int | None, selected_pages: list[int] | str | None) -> dict[str, Any]:
    raw_text, page_count, evidence, note, report, pages_selected = _pdf_pages(data, page_mode, max_page_number, selected_pages)
    report.update({"title": title, "source_url": source_url, "provenance": provenance})
    doc_id = _stable_id("doc", source_url) if provenance == "HTTP_FETCH" else _stable_id("upload", hashlib.sha256(data).hexdigest())
    saved = upsert_document({
        "document_id": doc_id, "title": title[:240], "source_url": source_url,
        "canonical_url": source_url if provenance == "HTTP_FETCH" else "", "jurisdiction": jurisdiction[:100],
        "issuing_authority": (urlparse(source_url).hostname or "") if provenance == "HTTP_FETCH" else "Not verified from the uploaded file",
        "authority_status": authority_status, "provenance": provenance,
        "freshness": "LIVE" if provenance == "HTTP_FETCH" else "USER_UPLOADED",
        "retrieved_at": utcnow(), "document_date": None, "content_type": "application/pdf",
        "raw_text": raw_text, "page_count": page_count, "extraction_note": note,
        "processing_report": report, "selected_pages": pages_selected, "evidence": evidence,
    })
    return {**saved, "title": title[:240], "source_url": source_url,
            "content_type": "application/pdf",
            "freshness": "LIVE" if provenance == "HTTP_FETCH" else "USER_UPLOADED",
            "authority_status": authority_status, "provenance": provenance,
            "page_count": page_count, "selected_pages": pages_selected,
            "processing_report": report, "extraction_note": note}


def ingest_url(url: str, title: str | None = None, jurisdiction: str = "India",
               include_linked_pdfs: bool = False, max_linked_pdfs: int = DEFAULT_MAX_LINKED_PDFS,
               page_mode: str = "all", max_page_number: int | None = None,
               selected_pages: list[int] | str | None = None) -> dict[str, Any]:
    started = time.perf_counter()
    safe_url = validate_source_url(url)
    data, response = _bounded_get(safe_url)
    content_type = (response.headers.get("Content-Type") or "").split(";", 1)[0].lower()
    final_url = response.url or safe_url
    response.close()
    if data.startswith(b"%PDF-") or content_type == "application/pdf":
        if not data.startswith(b"%PDF-"):
            raise IngestionError("The server declared a PDF but the content does not have a PDF signature.")
        guessed_title = Path(urlparse(final_url).path).name or "Official PDF document"
        result = _store_pdf_source(data, final_url, title or guessed_title, jurisdiction,
                                   _authority_status_for_host(urlparse(final_url).hostname or ""), "HTTP_FETCH",
                                   page_mode, max_page_number, selected_pages)
        result["ingestion_kind"] = "DIRECT_PDF_URL"
        return result
    if content_type not in {"text/html", "application/xhtml+xml", ""} and b"<html" not in data[:1000].lower():
        raise IngestionError(f"Unsupported source content type: {content_type or 'unknown'}. Provide an HTML page or PDF.")
    guessed_title, raw_text, sections, linked_paths = _html_document_detail(data)
    html_text_limit = min(MAX_HTML_CHARS, MAX_EXTRACTED_CHARS)
    if len(raw_text) > html_text_limit:
        raise IngestionError(f"Extracted HTML text exceeds the configured {html_text_limit:,}-character safety limit.")
    title_value = (title or guessed_title or "Government policy webpage")[:240]
    evidence = _split_page_text(raw_text, None)
    host = urlparse(final_url).hostname or ""
    report = {
        "title": title_value, "source_url": final_url, "provenance": "HTTP_FETCH",
        "total_pages": None, "selected_pages": [], "extracted_pages": [], "ocr_pages": [],
        "unreadable_pages": [], "failed_pages": [], "text_length": len(raw_text),
        "chunk_count": len(evidence), "processing_duration_ms": round((time.perf_counter() - started) * 1000, 2),
        "processing_status": "COMPLETE", "indexing_status": "INDEXED" if evidence else "FAILED",
        "overall_completeness": bool(evidence), "sections_extracted": len(sections),
        "linked_pdf_count_discovered": len(linked_paths),
    }
    if not evidence:
        raise IngestionError("The retrieved webpage did not yield indexable text.")
    authority_status = _authority_status_for_host(host)
    doc_id = _stable_id("doc", final_url)
    saved = upsert_document({
        "document_id": doc_id, "title": title_value, "source_url": final_url, "canonical_url": safe_url,
        "jurisdiction": jurisdiction[:100], "issuing_authority": host, "authority_status": authority_status,
        "provenance": "HTTP_FETCH", "freshness": "LIVE", "retrieved_at": utcnow(),
        "document_date": None, "content_type": "text/html", "raw_text": raw_text,
        "page_count": 0, "extraction_note": "HTML main content, headings and table rows extracted. Linked PDFs are not fetched unless explicitly requested.",
        "processing_report": report, "selected_pages": [], "evidence": evidence,
    })
    linked_results: list[dict[str, Any]] = []
    if include_linked_pdfs:
        count = max(0, min(int(max_linked_pdfs), DEFAULT_MAX_LINKED_PDFS, 5))
        origin_host = urlparse(final_url).hostname
        for link in linked_paths[:count]:
            linked_url = urljoin(final_url, link)
            linked_host = urlparse(linked_url).hostname
            if linked_host != origin_host:
                linked_results.append({"url": linked_url, "status": "SKIPPED_DIFFERENT_HOST", "reason": "Linked PDF host differs from the parent webpage host."})
                continue
            try:
                linked_data, linked_response = _bounded_get(linked_url)
                linked_final = linked_response.url or linked_url
                linked_type = (linked_response.headers.get("Content-Type") or "").split(";", 1)[0].lower()
                linked_response.close()
                if not linked_data.startswith(b"%PDF-") or (linked_type and linked_type not in {"application/pdf", "application/octet-stream"}):
                    raise IngestionError("Linked resource was not a verified PDF file.")
                linked_title = Path(urlparse(linked_final).path).name or "Linked official PDF"
                linked_results.append(_store_pdf_source(linked_data, linked_final, linked_title, jurisdiction,
                    _authority_status_for_host(urlparse(linked_final).hostname or ""), "HTTP_FETCH", page_mode, max_page_number, selected_pages))
            except IngestionError as exc:
                linked_results.append({"url": linked_url, "status": "FAILED", "reason": str(exc)})
    return {**saved, "title": title_value, "source_url": final_url, "freshness": "LIVE",
            "authority_status": authority_status, "provenance": "HTTP_FETCH", "page_count": 0,
            "processing_report": report, "linked_pdfs": linked_results,
            "note": "HTML was extracted from the retrieved webpage. Verify that it contains the complete underlying notice; linked PDFs are fetched only when explicitly requested and within the configured same-host limit."}



def inspect_pdf_upload(data: bytes, filename: str = "uploaded-document.pdf") -> dict[str, Any]:
    """Validate a PDF and return metadata for page selection without storing it."""
    if not data or len(data) > MAX_UPLOAD_BYTES:
        raise IngestionError(f"Upload is empty or exceeds the configured {MAX_UPLOAD_BYTES}-byte size limit.")
    if not data.startswith(b"%PDF-"):
        raise IngestionError("Only genuine PDF files are accepted. The file signature is not %PDF-.")
    try:
        pdf = fitz.open(stream=data, filetype="pdf")
    except Exception as exc:
        raise IngestionError("The PDF could not be opened. Try a valid, unlocked PDF file.") from exc
    try:
        page_count = len(pdf)
        if page_count < 1 or page_count > MAX_PDF_PAGES:
            raise IngestionError(f"PDF must contain between 1 and {MAX_PDF_PAGES} pages.")
        return {
            "filename": Path(filename or "uploaded-document.pdf").name[:160],
            "file_size_bytes": len(data),
            "max_upload_bytes": MAX_UPLOAD_BYTES,
            "total_pages": page_count,
            "default_max_page": min(DEFAULT_MAX_PAGES, page_count),
            "max_process_pages": MAX_PROCESS_PAGES,
            "stored": False,
            "note": "This is a metadata preview only. No document or evidence has been stored yet.",
        }
    finally:
        pdf.close()

def ingest_pdf_upload(data: bytes, filename: str, jurisdiction: str = "India", *,
                      page_mode: str = "all", max_page_number: int | None = None,
                      selected_pages: list[int] | str | None = None) -> dict[str, Any]:
    if not data or len(data) > MAX_UPLOAD_BYTES:
        raise IngestionError(f"Upload is empty or exceeds the configured {MAX_UPLOAD_BYTES}-byte size limit.")
    if not data.startswith(b"%PDF-"):
        raise IngestionError("Only genuine PDF files are accepted. The file signature is not %PDF-.")
    safe_name = re.sub(r"[^A-Za-z0-9._ -]", "_", Path(filename or "uploaded-document.pdf").name)[:120]
    title = safe_name or "Uploaded policy document"
    return _store_pdf_source(data, f"upload://{_stable_id('upload', hashlib.sha256(data).hexdigest())}", title,
        jurisdiction, "USER_UPLOADED_PUBLISHER_UNVERIFIED", "USER_UPLOAD", page_mode,
        max_page_number, selected_pages)
