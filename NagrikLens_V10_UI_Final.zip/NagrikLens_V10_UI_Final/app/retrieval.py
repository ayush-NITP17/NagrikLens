from __future__ import annotations

import math
import re
import threading
import unicodedata
from collections import Counter
from typing import Any

from . import store
from .store import get_all_evidence

# Devanagari vowel signs and other combining marks are Unicode category Mn/Mc/Me,
# not always matched correctly by a bare Python \w expression. Tokenise by Unicode
# categories so a word such as "छात्रवृत्ति" remains intact.
# Keep topical civic words in the index. Earlier versions treated terms such as
# income, money, benefit, family and documents as stopwords; those are exactly the
# words citizens use to ask policy questions. Only grammatical/filler tokens are
# removed here. Broad-but-meaningful terms remain indexed and are controlled by
# coverage, absolute scoring and out-of-domain topic checks below.
STOPWORDS = {
    "the", "a", "an", "and", "or", "but", "if", "when", "what", "which", "who", "whom", "how", "why",
    "i", "is", "are", "was", "were", "be", "been", "being", "to", "of", "in", "on", "for", "from", "by", "much", "every",
    "with", "about", "does", "do", "did", "say", "says", "mean", "means", "tell", "can", "could", "should",
    "would", "me", "my", "we", "you", "your", "it", "this", "that", "these", "those", "as", "at", "into",
    "under", "over", "within", "after", "before", "has", "have", "had", "please", "explain", "show", "current",
    "latest", "get", "give", "need", "want", "mujhe", "mujhko", "mere", "mera", "meri", "ke", "liye", "kya",
    "hai", "hain", "chahiye", "batao", "है", "हैं", "था", "थी", "थे", "क्या", "कैसे", "कब", "क्यों", "कौन",
    "किस", "किसे", "मुझे", "मेरे", "मेरा", "मेरी", "हम", "आप", "आपका", "की", "के", "को", "से", "में", "पर",
    "और", "या", "एक", "यह", "वह", "इस", "उस", "लिए", "करें", "करना", "होगा", "होनी", "होने", "सकता",
    "सकती", "चाहिए", "बताएं", "बता", "मिलेगा", "मिलेगी", "रहे", "रहा", "रही", "का", "तक", "द्वारा", "किसका",
}

# These terms remain in the token stream but are not sufficient by themselves to
# establish a useful topic. They still contribute to BM25 when paired with topic
# terms, and remain searchable in explicitly selected-document mode.
NON_DISTINCTIVE = STOPWORDS | {
    "annual", "year", "years", "amount", "limit", "eligible", "eligibility", "qualify", "qualifies", "criteria",
    "scheme", "schemes", "government", "policy", "policies", "guideline", "guidelines", "document", "documents",
    "application", "apply", "information", "support", "help", "rule", "rules", "condition", "conditions",
    "अधिक", "राशि", "योजना", "पात्र", "पात्रता", "सहायता", "आवेदन", "आवेदक", "वर्ष", "साल",
}

# A small, auditable set of domain stop words, including common English plural
# normalisation. Hindi semantic expansion itself lives in policy.py.
_TOKEN_CACHE_LIMIT = 50_000


def _unicode_tokens(text: str) -> list[str]:
    value = unicodedata.normalize("NFKC", (text or "").casefold())
    value = "".join(str(unicodedata.digit(ch)) if ch.isdecimal() else ch for ch in value)
    out: list[str] = []
    current: list[str] = []
    for ch in value:
        cat = unicodedata.category(ch)
        if cat[0] in {"L", "N"} or cat in {"Mn", "Mc", "Me"}:
            current.append(ch)
        else:
            if current:
                out.append("".join(current))
                current = []
    if current:
        out.append("".join(current))
    return out


def _english_normalise(token: str) -> str:
    # Conservative spelling/inflection normalisation. Do not apply aggressive
    # stemming to legal language because it can merge distinct statutory terms.
    if any("DEVANAGARI" in unicodedata.name(ch, "") for ch in token):
        for suffix in ("ियों", "ों", "ें", "एं", "ओं"):
            if len(token) > len(suffix) + 2 and token.endswith(suffix):
                return token[:-len(suffix)]
        return token
    if re.fullmatch(r"[a-z]+", token):
        spelling = {"license": "licence", "licenses": "licence", "licensed": "licence", "licensing": "licence",
                    "center": "centre", "centers": "centre"}
        token = spelling.get(token, token)
        irregular = {"women": "woman", "men": "man", "children": "child", "people": "person"}
        token = irregular.get(token, token)
        if len(token) > 5 and token.endswith("ies"):
            return token[:-3] + "y"
        if len(token) > 4 and token.endswith("s") and not token.endswith(("ss", "us", "is")):
            return token[:-1]
        if len(token) > 6 and token.endswith("ing"):
            stem = token[:-3]
            return stem if len(stem) > 3 else token
        if len(token) > 5 and token.endswith("ed"):
            return token[:-2]
        if len(token) > 5 and token.endswith("al") and token[:-2] in {"renew", "ann"}:
            return token[:-2]
    return token


def tokens(text: str) -> list[str]:
    result = []
    for token in _unicode_tokens(text):
        token = _english_normalise(token)
        if token and token not in STOPWORDS:
            result.append(token)
    return result


_INDEXED_PHRASES = {
    "family income": "family_income",
    "household income": "household_income",
    "parental income": "parental_income",
    "parents income": "parental_income",
    "income of parents": "parental_income",
    "annual family income": "family_income",
    "trade licence": "trade_licence",
    "trade license": "trade_licence",
    "driving licence": "driving_licence",
    "driving license": "driving_licence",
}


def _phrase_tokens(text: str) -> list[str]:
    normalized = unicodedata.normalize("NFKC", (text or "")).casefold()
    normalized = re.sub(r"\s+", " ", normalized)
    found = []
    for phrase, token in _INDEXED_PHRASES.items():
        if phrase in normalized:
            found.append(token)
            # Family/household/parental income are common equivalent labels in
            # eligibility prose. Shared phrase aliases bridge query wording to
            # source wording without treating standalone "income" as distinctive.
            if token in {"family_income", "household_income", "parental_income"}:
                found.extend({"family_income", "household_income", "parental_income"})
    return list(dict.fromkeys(found))


class _RetrievalIndex:
    def __init__(self, rows: list[dict[str, Any]], revision: int, db_path: str):
        self.rows = rows
        self.revision = revision
        self.db_path = db_path
        self.counters: list[Counter[str]] = []
        self.term_sets: list[set[str]] = []
        self.lengths: list[int] = []
        self.postings: dict[str, list[int]] = {}
        df: Counter[str] = Counter()
        for row_index, row in enumerate(rows):
            corpus_text = " ".join((row.get("title") or "", row.get("section") or "", row.get("text") or ""))
            term_counts = Counter(tokens(corpus_text) + _phrase_tokens(corpus_text))
            self.counters.append(term_counts)
            terms = set(term_counts)
            self.term_sets.append(terms)
            self.lengths.append(sum(term_counts.values()))
            df.update(terms)
            for term in terms:
                self.postings.setdefault(term, []).append(row_index)
        self.df = df
        self.n = max(1, len(rows))
        self.avgdl = sum(self.lengths) / self.n if self.rows else 1.0
        self.idf = {term: math.log(1.0 + (self.n - freq + 0.5) / (freq + 0.5)) for term, freq in df.items()}


_INDEX: _RetrievalIndex | None = None
_INDEX_LOCK = threading.RLock()


def _get_index() -> _RetrievalIndex:
    global _INDEX
    revision = store.get_retrieval_revision()
    db_path = str(store.DB_FILE)
    with _INDEX_LOCK:
        if _INDEX is None or _INDEX.revision != revision or _INDEX.db_path != db_path:
            _INDEX = _RetrievalIndex(get_all_evidence(), revision, db_path)
        return _INDEX


def _query_tokens(variant: str) -> list[str]:
    return list(dict.fromkeys(tokens(variant) + _phrase_tokens(variant)))


def _score_one_variant(
    qtokens: list[str], row_index: int, index: _RetrievalIndex
) -> tuple[float, float, float, int, list[str]]:
    if not qtokens:
        return 0.0, 0.0, 0.0, 0, []
    distinctive = [t for t in qtokens if t not in NON_DISTINCTIVE]
    # Do not manufacture confidence from generic words such as "tax", "income",
    # "scheme" or "help". Short queries need a sufficiently specific term.
    if not distinctive:
        return 0.0, 0.0, 0.0, 0, []
    counter = index.counters[row_index]
    term_set = index.term_sets[row_index]
    matched = [t for t in distinctive if t in term_set]
    matched_count = len(matched)
    coverage = matched_count / max(1, len(distinctive))
    if not matched_count or coverage < 0.45:
        return 0.0, coverage, 0.0, matched_count, matched
    if len(distinctive) >= 3 and matched_count < 2:
        return 0.0, coverage, 0.0, matched_count, matched
    if len(distinctive) == 1 and len(distinctive[0]) < 4 and not any("DEVANAGARI" in unicodedata.name(ch, "") for ch in distinctive[0]):
        return 0.0, coverage, 0.0, matched_count, matched

    # BM25 uses absolute corpus statistics; no max-score normalisation. A weak
    # hit cannot become "strong" merely because it is the best available result.
    raw_bm25 = 0.0
    dl = max(1, index.lengths[row_index])
    for term in qtokens:
        tf = counter.get(term, 0)
        if tf <= 0:
            continue
        idf = index.idf.get(term, 0.0)
        k1, b = 1.5, 0.75
        denominator = tf + k1 * (1 - b + b * dl / max(1.0, index.avgdl))
        raw_bm25 += idf * (tf * (k1 + 1)) / denominator

    # Score is a combination of absolute BM25 saturation and informative-term
    # coverage. It is a retrieval score, never a probability or answer confidence.
    bm25_saturated = raw_bm25 / (raw_bm25 + 3.0) if raw_bm25 > 0 else 0.0
    score = 0.55 * coverage + 0.45 * bm25_saturated
    return score, coverage, raw_bm25, matched_count, matched


def retrieve(
    question: str,
    k: int = 8,
    freshness: str | None = None,
    document_id: str | None = None,
    query_variants: list[str] | None = None,
    min_score: float = 0.42,
    question_context: str | None = None,
) -> list[dict[str, Any]]:
    """Return relevant passages using cached BM25 and strict topical gates.

    ``query_variants`` should contain independent language/translation variants,
    not one concatenated bag of many synonyms. The best valid variant is used
    per passage so irrelevant synonym expansion does not dilute query coverage.
    """
    variants = query_variants or [question]
    variants = [str(v).strip()[:3_000] for v in variants if str(v).strip()]
    if not variants:
        return []
    index = _get_index()
    if not index.rows:
        return []
    # Inverted postings avoid rescoring every passage on every query. Corpus-wide
    # IDF and document lengths remain cached; only rows containing at least one
    # informative query term become candidates. The topical coverage gate is still
    # applied afterwards, so a one-term coincidence cannot automatically pass.
    candidate_indices: set[int] = set()
    for variant in variants[:12]:
        for term in set(_query_tokens(variant)) - NON_DISTINCTIVE:
            candidate_indices.update(index.postings.get(term, []))
    if not candidate_indices:
        return []

    output: list[dict[str, Any]] = []
    # Facet retrieval must retain hard-negative constraints from the original
    # citizen question; otherwise an expanded generic facet could erase a
    # specific domain such as "crop loan" and retrieve unrelated "benefit" text.
    question_normal = unicodedata.normalize("NFKC", question_context or question or "").casefold()
    # A same-word collision must not confuse distinct licence domains. This is a
    # deliberately conservative hard-negative rule: if the citizen explicitly
    # asks about a driving licence, a trade-licence passage is not a substitute.
    driving_licence_query = bool(re.search(r"\bdriving\s+licen[cs]e\b|\bvehicle\s+licen[cs]e\b", question_normal))
    crop_loan_query = bool(re.search(r"\b(?:crop|farm|agricultural)\s+(?:credit|loan)s?\b", question_normal)
                           or re.search(r"फसल\s*(?:ऋण|कर्ज)|कृषि\s*(?:ऋण|कर्ज)", question_normal))
    for idx in sorted(candidate_indices):
        row = index.rows[idx]
        row_normal = unicodedata.normalize("NFKC", " ".join((row.get("title") or "", row.get("section") or "", row.get("text") or ""))).casefold()
        if driving_licence_query and re.search(r"\btrade\s+licen[cs]e\b", row_normal) and not re.search(r"\bdriving\s+licen[cs]e\b", row_normal):
            continue
        # Do not let generic "loan" facets substitute education, housing or
        # personal loans for an explicitly requested crop/farm credit topic.
        crop_context = bool(re.search(r"\b(?:crop|farm|agricultur|kisan|kcc)\w*\b|किसान|कृषि|फसल", row_normal))
        if crop_loan_query and not crop_context:
            continue
        if freshness and row.get("freshness") != freshness:
            continue
        if document_id and row.get("document_id") != document_id:
            continue
        best = (0.0, 0.0, 0.0, 0, [])
        best_variant = ""
        for variant in variants[:12]:
            candidate = _score_one_variant(_query_tokens(variant), idx, index)
            if candidate[0] > best[0]:
                best, best_variant = candidate, variant
        score, coverage, bm25_raw, matched_count, matched_terms = best
        if score < min_score:
            continue
        query_has_devanagari = bool(re.search(r"[\u0900-\u097f]", question or ""))
        row_text = " ".join((row.get("title") or "", row.get("section") or "", row.get("text") or ""))
        row_has_devanagari = bool(re.search(r"[\u0900-\u097f]", row_text))
        language_match = query_has_devanagari == row_has_devanagari
        copied = dict(row)
        copied.update({
            "bm25_score": round(bm25_raw, 5),
            "query_coverage": round(coverage, 4),
            "matched_terms": matched_terms,
            "matched_term_count": matched_count,
            "score": round(score, 5),
            "language_match": language_match,
            "retrieval_method": "cached_bm25_informative_coverage",
            "retrieval_variant": best_variant,
            "retrieval_candidate_count": len(candidate_indices),
            "indexed_corpus_size": len(index.rows),
        })
        output.append(copied)
    # Prefer evidence in the user's language when a relevant same-language
    # passage exists; cross-language evidence remains available as a fallback.
    # Retrieval relevance remains primary; script/language preference only breaks
    # near-ties so a weak same-language hit cannot outrank a much stronger source.
    # A bounded script-affinity bonus resolves near-ties in favour of the
    # language the citizen used, without allowing a materially weaker passage
    # to outrank a substantially stronger match. This is a ranking heuristic,
    # not a confidence adjustment; the unmodified BM25 score is retained.
    output.sort(
        key=lambda x: (
            x["score"] + (0.28 if x.get("language_match", False) else 0.0),
            x["score"],
            x.get("freshness") == "LIVE",
        ),
        reverse=True,
    )
    return output[: max(1, min(int(k), 20))]
