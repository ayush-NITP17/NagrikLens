from __future__ import annotations

import re
import unicodedata
from typing import Any

ALLOWED_OPERATORS = {"eq", "neq", "lte", "lt", "gte", "gt", "in", "not_in", "contains", "unknown"}

_HINDI_NUMBERS = {
    "शून्य": 0, "एक": 1, "दो": 2, "तीन": 3, "चार": 4, "पांच": 5, "पाँच": 5,
    "छह": 6, "छः": 6, "सात": 7, "आठ": 8, "नौ": 9, "दस": 10,
    "ग्यारह": 11, "बारह": 12, "तेरह": 13, "चौदह": 14, "पंद्रह": 15, "पन्द्रह": 15,
    "सोलह": 16, "सत्रह": 17, "अठारह": 18, "उन्नीस": 19, "बीस": 20,
    "इक्कीस": 21, "बाईस": 22, "तेईस": 23, "चौबीस": 24, "पच्चीस": 25,
    "छब्बीस": 26, "सत्ताईस": 27, "अट्ठाईस": 28, "उनतीस": 29, "तीस": 30,
    "चालीस": 40, "पचास": 50, "साठ": 60, "सत्तर": 70, "अस्सी": 80,
    "नब्बे": 90, "सौ": 100, "डेढ़": 1.5, "ढाई": 2.5,
}

_CATEGORY_ALIASES = {
    "SC": {"sc", "scheduled caste", "scheduled castes", "अनुसूचित जाति", "अनुसूचित जातियां", "अनुसूचित जातियाँ"},
    "ST": {"st", "scheduled tribe", "scheduled tribes", "अनुसूचित जनजाति", "अनुसूचित जनजातियां", "अनुसूचित जनजातियाँ"},
    "OBC": {"obc", "other backward class", "other backward classes", "अन्य पिछड़ा वर्ग", "अन्य पिछड़ा वर्ग"},
    "EBC": {"ebc", "extremely backward class", "अत्यंत पिछड़ा वर्ग", "अत्यंत पिछड़ा वर्ग"},
    "EWS": {"ews", "economically weaker section", "आर्थिक रूप से कमजोर वर्ग"},
    "GENERAL": {"general", "unreserved", "open category", "सामान्य", "अनारक्षित"},
}

_STATE_ALIASES = {
    "andhra pradesh": {"andhra pradesh", "आंध्र प्रदेश"}, "arunachal pradesh": {"arunachal pradesh", "अरुणाचल प्रदेश"},
    "assam": {"assam", "असम"}, "bihar": {"bihar", "बिहार"}, "chhattisgarh": {"chhattisgarh", "छत्तीसगढ़", "छत्तीसगढ़"},
    "goa": {"goa", "गोवा"}, "gujarat": {"gujarat", "गुजरात"}, "haryana": {"haryana", "हरियाणा"},
    "himachal pradesh": {"himachal pradesh", "हिमाचल प्रदेश"}, "jharkhand": {"jharkhand", "झारखंड"},
    "karnataka": {"karnataka", "कर्नाटक"}, "kerala": {"kerala", "केरल"}, "madhya pradesh": {"madhya pradesh", "मध्य प्रदेश"},
    "maharashtra": {"maharashtra", "महाराष्ट्र"}, "manipur": {"manipur", "मणिपुर"}, "meghalaya": {"meghalaya", "मेघालय"},
    "mizoram": {"mizoram", "मिजोरम"}, "nagaland": {"nagaland", "नागालैंड"}, "odisha": {"odisha", "orissa", "ओडिशा"},
    "punjab": {"punjab", "पंजाब"}, "rajasthan": {"rajasthan", "राजस्थान"}, "sikkim": {"sikkim", "सिक्किम"},
    "tamil nadu": {"tamil nadu", "तमिल नाडु"}, "telangana": {"telangana", "तेलंगाना"}, "tripura": {"tripura", "त्रिपुरा"},
    "uttar pradesh": {"uttar pradesh", "उत्तर प्रदेश"}, "uttarakhand": {"uttarakhand", "उत्तराखंड"},
    "west bengal": {"west bengal", "पश्चिम बंगाल"}, "delhi": {"delhi", "nct of delhi", "दिल्ली"},
    "jammu and kashmir": {"jammu and kashmir", "जम्मू और कश्मीर", "जम्मू कश्मीर"},
    "ladakh": {"ladakh", "लद्दाख"}, "puducherry": {"puducherry", "पुडुचेरी"},
}


def _digits_ascii(text: str) -> str:
    out = []
    for ch in text:
        try:
            out.append(str(unicodedata.digit(ch))) if ch.isdecimal() else out.append(ch)
        except (TypeError, ValueError):
            out.append(ch)
    return "".join(out)


def _number(value: Any, unit_hint: str = "") -> float | None:
    """Parse numbers with unit checking, Indian grouping, Devanagari digits and common Hindi number words."""
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, (int, float)):
        number = float(value)
        return number if number == number and abs(number) != float("inf") else None

    text = unicodedata.normalize("NFKC", _digits_ascii(str(value))).strip().casefold()
    text = re.sub(r"\s+", " ", text)
    if not text:
        return None

    english_numbers = {
        "zero": 0, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
        "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
        "eleven": 11, "twelve": 12, "thirteen": 13, "fourteen": 14, "fifteen": 15,
        "sixteen": 16, "seventeen": 17, "eighteen": 18, "nineteen": 19, "twenty": 20,
        "first": 1, "second": 2, "third": 3, "fourth": 4, "fifth": 5,
        "sixth": 6, "seventh": 7, "eighth": 8, "ninth": 9, "tenth": 10,
    }
    english_match = re.fullmatch(r"(zero|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty|first|second|third|fourth|fifth|sixth|seventh|eighth|ninth|tenth)(?:\s+(year|years|yr|yrs|semester|semesters))?", text)
    word_match = re.fullmatch(r"(डेढ़|ढाई|शून्य|एक|दो|तीन|चार|पांच|पाँच|छह|छः|सात|आठ|नौ|दस|ग्यारह|बारह|तेरह|चौदह|पंद्रह|पन्द्रह|सोलह|सत्रह|अठारह|उन्नीस|बीस|इक्कीस|बाईस|तेईस|चौबीस|पच्चीस|छब्बीस|सत्ताईस|अट्ठाईस|उनतीस|तीस|चालीस|पचास|साठ|सत्तर|अस्सी|नब्बे|सौ)(?:\s+(लाख|करोड़|करोड़|हजार|हज़ार|रुपये|रुपया|वर्ष|साल|एकड़|एकड़))?", text)
    if english_match:
        return float(english_numbers[english_match.group(1)])
    if word_match:
        number = float(_HINDI_NUMBERS[word_match.group(1)])
        suffix = word_match.group(2) or ""
        if suffix == "लाख": number *= 100_000
        elif suffix in {"करोड़", "करोड़"}: number *= 10_000_000
        elif suffix in {"हजार", "हज़ार"}: number *= 1_000
        elif suffix in {"रुपये", "रुपया"} and unit_hint.casefold() not in {"", "inr", "rupees", "rs", "₹"}:
            return None
        elif suffix in {"वर्ष", "साल"} and unit_hint.casefold() not in {"", "year", "years", "yr", "yrs"}:
            return None
        elif suffix in {"एकड़", "एकड़"} and unit_hint.casefold() not in {"", "acre", "acres"}:
            return None
        return number

    # Period suffixes are accepted only as period qualifiers, not as a different unit.
    period_re = r"(?:per\s+(?:annum|year|month)|p\.a\.|annually|annual|प्रतिवर्ष|वार्षिक|प्रति\s+वर्ष|प्रति\s+माह)?"
    pattern = re.compile(
        r"^\s*(?:₹|rs\.?\s*|inr\s*)?"
        r"(-?\d[\d,]*(?:\.\d+)?)\s*"
        r"(lakh|lakhs|lac|lacs|लाख|crore|crores|करोड़|करोड़|thousand|thousands|हजार|हज़ार|rupees|रुपये|रुपया|inr|rs\.?|acres?|years?|yrs?|kg|%|days?|weeks?|months?)?\s*"
        + period_re + r"\s*$", re.I,
    )
    match = pattern.fullmatch(text)
    if not match:
        return None
    number = float(match.group(1).replace(",", ""))
    suffix = (match.group(2) or "").replace(".", "")
    hint = (unit_hint or "").casefold()
    currency_units = {"lakh", "lakhs", "lac", "lacs", "लाख", "crore", "crores", "करोड़", "करोड़", "thousand", "thousands", "हजार", "हज़ार", "rupees", "रुपये", "रुपया", "inr", "rs"}
    land_units = {"acre", "acres"}
    time_units = {"year", "years", "yr", "yrs", "day", "days", "week", "weeks", "month", "months"}
    if hint in {"inr", "rupees", "rs", "₹"} and suffix and suffix not in currency_units:
        return None
    if hint in {"acre", "acres"} and suffix and suffix not in land_units:
        return None
    if hint in {"year", "years", "yr", "yrs"} and suffix and suffix not in time_units:
        return None
    if hint in {"percent", "%"} and suffix not in {"%"}:
        return None
    if suffix in {"lakh", "lakhs", "lac", "lacs", "लाख"}: number *= 100_000
    elif suffix in {"crore", "crores", "करोड़", "करोड़"}: number *= 10_000_000
    elif suffix in {"thousand", "thousands", "हजार", "हज़ार"}: number *= 1_000
    return number if number == number and abs(number) != float("inf") else None


def _norm(value: Any) -> str:
    """Normalise Latin and Indic text without dropping combining vowel marks."""
    text = unicodedata.normalize("NFKC", str(value or "")).casefold().strip()
    text = "".join(" " if ch in "_-/\\." else ch for ch in text)
    kept: list[str] = []
    previous_space = False
    for ch in text:
        category = unicodedata.category(ch)
        if category[0] in {"L", "N", "M"}:
            kept.append(ch)
            previous_space = False
        elif ch.isspace():
            if kept and not previous_space:
                kept.append(" ")
                previous_space = True
    return "".join(kept).strip()


def _enum_is_known(field: str, value: Any) -> bool:
    canonical = _canonical_value(field, value)
    if field == "category":
        return canonical in set(_CATEGORY_ALIASES)
    if field in {"state", "residence_state", "institution_state"}:
        return canonical in set(_STATE_ALIASES)
    if field == "gender":
        return canonical in {"female", "male", "other"}
    if field in {"disability", "is_disabled", "minority_status"}:
        return canonical in {"yes", "no"}
    if field == "land_status":
        return canonical in {"owner", "tenant", "sharecropper", "landless"}
    return True


def _canonical_value(field: str, value: Any) -> str:
    normal = _norm(value)
    if field == "category":
        for canonical, aliases in _CATEGORY_ALIASES.items():
            if normal in {_norm(x) for x in aliases}:
                return canonical
    elif field in {"state", "residence_state", "institution_state"}:
        for canonical, aliases in _STATE_ALIASES.items():
            if normal in {_norm(x) for x in aliases}:
                return canonical
    elif field == "gender":
        aliases = {"female": {"female", "woman", "girl", "महिला", "लड़की", "लड़की"},
                   "male": {"male", "man", "boy", "पुरुष", "लड़का", "लड़का"},
                   "other": {"other", "अन्य"}}
        for canonical, values in aliases.items():
            if normal in {_norm(x) for x in values}:
                return canonical
    elif field in {"disability", "is_disabled", "minority_status"}:
        if normal in {"yes", "true", "1", "हाँ", "हां", "दिव्यांग", "विकलांग"}:
            return "yes"
        if normal in {"no", "false", "0", "नहीं", "नही"}:
            return "no"
    elif field == "land_status":
        aliases = {
            "owner": {"owner", "land owner", "owner cultivator", "भूमि मालिक", "स्वयं की जमीन"},
            "tenant": {"tenant", "tenant farmer", "किरायेदार", "पट्टेदार"},
            "sharecropper": {"sharecropper", "बटाईदार", "बटाई पर खेती"},
            "landless": {"landless", "भूमिहीन"},
        }
        for canonical, values in aliases.items():
            if normal in {_norm(x) for x in values}:
                return canonical
    return normal


def _compare_leaf(condition: dict[str, Any], profile: dict[str, Any]) -> dict[str, Any]:
    field = str(condition.get("profile_field", "")).strip()
    operator = str(condition.get("operator", "unknown")).strip().lower()
    expected = condition.get("expected_value")
    actual = profile.get(field) if field else None
    status = "UNKNOWN"
    reason = "The required profile detail or a safely evaluable condition is missing or ambiguous."
    if operator not in ALLOWED_OPERATORS:
        operator = "unknown"
    if operator != "unknown" and field and actual is not None and str(actual).strip() != "":
        if operator in {"lte", "lt", "gte", "gt"}:
            unit_hint = str(condition.get("unit", ""))
            a, b = _number(actual, unit_hint), _number(expected, unit_hint)
            if a is not None and b is not None:
                passed = {"lte": a <= b, "lt": a < b, "gte": a >= b, "gt": a > b}[operator]
                status = "MET" if passed else "NOT_MET"
                reason = f"Your value ({actual}) was compared with the source condition ({operator} {expected})."
        elif operator in {"eq", "neq"}:
            if field in {"category", "state", "residence_state", "institution_state", "gender", "disability", "is_disabled", "minority_status", "land_status"} and (
                not _enum_is_known(field, actual) or not _enum_is_known(field, expected)
            ):
                status = "UNKNOWN"
                reason = "The value is not in the supported category/state vocabulary; it must be clarified rather than treated as ineligible."
            elif field in {"age", "annual_family_income", "marks_percent", "course_year", "land_acres"}:
                unit_hint = str(condition.get("unit", ""))
                a, b = _number(actual, unit_hint), _number(expected, unit_hint)
                if a is not None and b is not None:
                    passed = a == b
                    if operator == "neq": passed = not passed
                    status = "MET" if passed else "NOT_MET"
                    reason = "Your numeric profile value was compared with the extracted source condition."
            else:
                passed = _canonical_value(field, actual) == _canonical_value(field, expected)
                if operator == "neq": passed = not passed
                status = "MET" if passed else "NOT_MET"
                reason = "Your profile value was compared with the extracted source condition using supported aliases."
        elif operator in {"in", "not_in"}:
            choices = expected if isinstance(expected, list) else [expected]
            if field in {"category", "state", "residence_state", "institution_state", "gender", "disability", "is_disabled", "minority_status", "land_status"} and (
                not _enum_is_known(field, actual) or not all(_enum_is_known(field, choice) for choice in choices)
            ):
                status = "UNKNOWN"
                reason = "The value or allowed choices contain an unsupported category/state alias; clarification is required."
            else:
                passed = _canonical_value(field, actual) in {_canonical_value(field, x) for x in choices}
                if operator == "not_in": passed = not passed
                status = "MET" if passed else "NOT_MET"
                reason = "Your profile value was checked against the allowed values extracted from the source."
        elif operator == "contains":
            expected_text = _norm(expected)
            actual_text = _norm(actual)
            if not expected_text or not actual_text:
                status = "UNKNOWN"
            else:
                status = "MET" if expected_text in actual_text else "NOT_MET"
            reason = "The expected text was checked against your profile value."
    return {
        "condition": condition.get("text", "Condition from source"),
        "profile_field": field,
        "operator": operator,
        "expected_value": expected,
        "your_value": actual,
        "status": status,
        "reason": reason,
        "evidence_id": condition.get("evidence_id"),
        "source_quote": condition.get("exact_quote"),
        "question_to_ask": condition.get("question_to_ask", ""),
    }


def _evaluate_expression(
    expression: Any, profile: dict[str, Any], _depth: int = 0, _budget: list[int] | None = None
) -> dict[str, Any]:
    """Evaluate bounded nested all/any/not expressions; malformed trees stay UNKNOWN."""
    if _budget is None:
        _budget = [0]
    _budget[0] += 1
    if _depth > 8 or _budget[0] > 100 or not isinstance(expression, dict):
        return {"status": "UNKNOWN", "reason": "Condition logic is too deep, too large or malformed."}
    op = str(expression.get("logic", expression.get("op", "leaf"))).casefold()
    if op in {"all", "and", "any", "or"}:
        children = expression.get("conditions", [])
        if not isinstance(children, list) or not children or len(children) > 20:
            return {"status": "UNKNOWN", "reason": "Logical group is empty or exceeds the supported size."}
        results = [_evaluate_expression(x, profile, _depth + 1, _budget) for x in children]
        statuses = [x["status"] for x in results]
        if op in {"all", "and"}:
            status = "NOT_MET" if "NOT_MET" in statuses else ("UNKNOWN" if "UNKNOWN" in statuses else "MET")
        else:
            status = "MET" if "MET" in statuses else ("UNKNOWN" if "UNKNOWN" in statuses else "NOT_MET")
        return {"status": status, "reason": f"{op.upper()} group: {', '.join(statuses)}", "children": results}
    if op == "not":
        child = _evaluate_expression(expression.get("condition"), profile, _depth + 1, _budget)
        status = {"MET": "NOT_MET", "NOT_MET": "MET", "UNKNOWN": "UNKNOWN"}[child["status"]]
        return {"status": status, "reason": "NOT group: " + child["reason"], "children": [child]}
    if op not in {"leaf", ""}:
        return {"status": "UNKNOWN", "reason": "Unsupported condition operator."}
    leaf = _compare_leaf(expression, profile)
    return {"status": leaf["status"], "reason": leaf["reason"], "leaf": leaf}


def _expression_leaf_results(result: dict[str, Any]) -> list[dict[str, Any]]:
    """Flatten leaf evaluations for a UI while retaining the full expression tree."""
    found: list[dict[str, Any]] = []
    leaf = result.get("leaf")
    if isinstance(leaf, dict):
        found.append(leaf)
    for child in result.get("children", []) if isinstance(result.get("children"), list) else []:
        if isinstance(child, dict):
            found.extend(_expression_leaf_results(child))
    return found


def evaluate_conditions(conditions: list[dict[str, Any]], profile: dict[str, Any]) -> dict[str, Any]:
    """Evaluate extracted, source-linked conditions without turning unknowns into failures.

    Top-level conditions are ANDed by default. Each condition can carry an
    expression tree with all/any/not logic and an explicit exception_if tree.
    This remains a partial check, not an official eligibility determination.
    """
    if not isinstance(conditions, list):
        conditions = []
    truncated = len(conditions) > 30
    results = []
    for condition in conditions[:30]:
        if not isinstance(condition, dict):
            continue
        expression = condition.get("expression")
        if expression:
            base = _evaluate_expression(expression, profile)
            status, reason = base["status"], base["reason"]
            leaf_details = _expression_leaf_results(base)
        else:
            leaf = _compare_leaf(condition, profile)
            status, reason = leaf["status"], leaf["reason"]
            base = None
            leaf_details = [leaf]
        exception = condition.get("exception_if")
        if exception:
            exception_expr = exception if isinstance(exception, dict) else {"logic": condition.get("exception_logic", "any"), "conditions": exception}
            exception_result = _evaluate_expression(exception_expr, profile)
            effect = str(condition.get("exception_effect", "unknown")).casefold()
            if exception_result["status"] == "UNKNOWN":
                status, reason = "UNKNOWN", "An exception may affect this condition, but the exception profile details are incomplete."
            elif exception_result["status"] == "MET":
                if effect == "waives_requirement":
                    status, reason = "MET", "The explicitly extracted waiver exception is satisfied. " + exception_result["reason"]
                elif effect == "excludes_applicant":
                    status, reason = "NOT_MET", "The explicitly extracted exclusion exception applies. " + exception_result["reason"]
                else:
                    status, reason = "UNKNOWN", "The exception is satisfied, but its legal effect (waiver or exclusion) is not verified."
        results.append({
            "condition": condition.get("text", "Condition from source"),
            "status": status,
            "reason": reason,
            # Preserve the scalar schema consumed by the original UI for simple
            # conditions. For compound expressions, expose every evaluated leaf.
            "profile_field": leaf_details[0].get("profile_field") if len(leaf_details) == 1 else None,
            "operator": leaf_details[0].get("operator") if len(leaf_details) == 1 else None,
            "expected_value": leaf_details[0].get("expected_value") if len(leaf_details) == 1 else None,
            "your_value": leaf_details[0].get("your_value") if len(leaf_details) == 1 else None,
            "leaf_results": leaf_details,
            "evidence_id": condition.get("evidence_id"),
            "source_quote": condition.get("exact_quote"),
            "question_to_ask": condition.get("question_to_ask", ""),
            "expression_result": base,
            "exception_result": exception_result if exception else None,
        })
    statuses = [x["status"] for x in results]
    if truncated:
        overall = "INCOMPLETE_CONDITIONS_REVIEW_REQUIRED"
    elif not results:
        overall = "NO_STRUCTURED_CONDITIONS_FOUND"
    elif "NOT_MET" in statuses:
        overall = "ONE_OR_MORE_EXTRACTED_CONDITIONS_NOT_MET"
    elif "UNKNOWN" in statuses:
        overall = "MORE_INFORMATION_NEEDED"
    else:
        overall = "ALL_EXTRACTED_CONDITIONS_MET_NOT_OFFICIAL_ELIGIBILITY"
    return {
        "overall_status": overall,
        "conditions_evaluated": len(results),
        "conditions_provided": len(conditions),
        "analysis_incomplete": truncated,
        "conditions": results,
        "important_limit": (
            "This evaluates only conditions extracted from the selected document. It may not include every rule, "
            "amendment, exception, cross-reference or application-specific check. It is not an official eligibility decision or approval."
            + (" More than 30 conditions were supplied; only the first 30 were evaluated, so no overall eligibility conclusion is provided." if truncated else "")
        ),
    }
