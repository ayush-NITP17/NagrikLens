from pathlib import Path
import os
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]

def load_local_env() -> bool:
    """Load project .env before reading any environment-backed settings."""
    return load_dotenv(ROOT / ".env", override=False)


load_local_env()
DATA_DIR = ROOT / "data"
def _default_db_file() -> Path:
    # Continue using an existing V9 database (schema migrations are additive)
    # instead of silently starting an empty V10 store.
    v10, v09 = DATA_DIR / "nagriklens_v10.sqlite3", DATA_DIR / "nagriklens_v09.sqlite3"
    return v09 if (not v10.exists() and v09.exists()) else v10


DB_FILE = Path(os.getenv("NAGRIKLENS_DB_FILE", "").strip() or _default_db_file())
STAGING_DIR = Path(os.getenv("NAGRIKLENS_STAGING_DIR", str(DATA_DIR / "staging")))

def _int_env(name: str, default: int, low: int, high: int) -> int:
    try:
        value = int(str(os.getenv(name, str(default))).strip())
    except (TypeError, ValueError):
        value = default
    return max(low, min(value, high))


REQUEST_TIMEOUT = _int_env("REQUEST_TIMEOUT_SECONDS", 20, 5, 45)
MAX_SOURCE_BYTES = _int_env("MAX_SOURCE_BYTES", 25 * 1024 * 1024, 1_000_000, 100 * 1024 * 1024)
MAX_UPLOAD_BYTES = _int_env("MAX_UPLOAD_BYTES", 25 * 1024 * 1024, 1_000_000, 100 * 1024 * 1024)
MAX_PROFILE_BYTES = 8_192
MAX_QUESTION_CHARS = 3_000
MAX_JSON_BODY_BYTES = 64 * 1024
MAX_EVIDENCE_CHARS = 24_000
MAX_CHUNK_CHARS = 1_600
MAX_EXTRACTED_CHARS = 2_000_000
CHUNK_OVERLAP_CHARS = 220

# Exact host allowlist for server-side URL ingestion. Extend this list only
# after verifying that a domain is an official source for the intended data.
DEFAULT_ALLOWED_SOURCE_HOSTS = {
    "vidhansabha.bihar.gov.in",
    "digi-repo.bihar.gov.in",
    "betastate.bihar.gov.in",
    "egazette.bihar.gov.in",
    "www.pib.gov.in",
    "pib.gov.in",
    "clc.gov.in",
    "www.clc.gov.in",
    "labour.gov.in",
    "www.labour.gov.in",
    "scholarships.gov.in",
    "www.scholarships.gov.in",
    "pmkisan.gov.in",
    "www.pmkisan.gov.in",
    "pmfby.gov.in",
    "www.pmfby.gov.in",
    "indiacode.gov.in",
    "www.indiacode.gov.in",
    "education.gov.in",
    "www.education.gov.in",
    "socialjustice.gov.in",
    "www.socialjustice.gov.in",
    "tribal.gov.in",
    "www.tribal.gov.in",
    "depwd.gov.in",
    "www.depwd.gov.in",
    "agriinfra.dac.gov.in",
    "pmvidyalaxmi.co.in",
}
_env_hosts = os.getenv("ALLOWED_SOURCE_HOSTS", "").strip()
ALLOWED_SOURCE_HOSTS = DEFAULT_ALLOWED_SOURCE_HOSTS | {
    h.strip().lower() for h in _env_hosts.split(",") if h.strip()
}

# Gemini through Google's OpenAI-compatible Chat Completions endpoint.
# Verified against https://ai.google.dev/gemini-api/docs/openai (Nov 2026):
# base URL https://generativelanguage.googleapis.com/v1beta/openai/ . Google's
# deprecations page lists gemini-2.5-flash as not deprecated, but notes that 2.5
# access is limited to projects that used it before; new projects may need
# LLM_MODEL=gemini-3.8-flash. The connectivity check reports which case applies.
DEFAULT_LLM_BASE_URL = "https://generativelanguage.googleapis.com/v1beta/openai/"
DEFAULT_LLM_MODEL = "gemini-3.8-flash"
LLM_API_KEY = os.getenv("LLM_API_KEY", "").strip()
LLM_BASE_URL = (os.getenv("LLM_BASE_URL", "").strip() or DEFAULT_LLM_BASE_URL)
LLM_MODEL = (os.getenv("LLM_MODEL", "").strip() or DEFAULT_LLM_MODEL)
LLM_TIMEOUT = _int_env("LLM_TIMEOUT_SECONDS", 45, 8, 120)
# json_schema (default) | json_object | none. The response is always parsed and
# validated locally regardless of what the provider enforces.
LLM_RESPONSE_FORMAT = (os.getenv("LLM_RESPONSE_FORMAT", "json_schema").strip().lower() or "json_schema")
# Optional; empty = provider default. Gemini 2.5 Flash accepts "none" to disable thinking.
LLM_REASONING_EFFORT = os.getenv("LLM_REASONING_EFFORT", "").strip().lower()
LLM_MAX_RETRIES = _int_env("LLM_MAX_RETRIES", 1, 0, 3)
LLM_CONTEXT_CHARS = _int_env("LLM_CONTEXT_CHARS", 24_000, 4_000, 120_000)

# PDF processing scope and limits.
DEFAULT_MAX_PAGES = _int_env("DEFAULT_MAX_PAGES", 10, 1, 2_000)
MAX_PDF_PAGES = _int_env("MAX_PDF_PAGES", 500, 1, 2_000)          # pages a PDF may have at all
MAX_PROCESS_PAGES = _int_env("MAX_PROCESS_PAGES", 500, 1, 2_000)  # pages processed in one request
OCR_ENABLED = os.getenv("OCR_ENABLED", "1").strip().lower() not in {"0", "false", "no", "off"}
OCR_LANGUAGES = os.getenv("OCR_LANGUAGES", "eng+hin").strip() or "eng+hin"
MAX_OCR_PAGES = _int_env("MAX_OCR_PAGES", 60, 0, 2_000)
OCR_DPI = _int_env("OCR_DPI", 200, 100, 400)
OCR_PAGE_TIMEOUT_SECONDS = _int_env("OCR_PAGE_TIMEOUT_SECONDS", 60, 5, 600)
MIN_TEXT_CHARS_PER_PAGE = 40
STAGING_TTL_SECONDS = _int_env("STAGING_TTL_SECONDS", 3_600, 60, 86_400)
# Optional shared access gate for controlled demos. This is not multi-user
# authentication or tenant isolation; public deployments need a proper identity layer.
API_ACCESS_KEY = os.getenv("NAGRIKLENS_API_KEY", "").strip()
ADMIN_API_KEY = os.getenv("NAGRIKLENS_ADMIN_KEY", "").strip()
DEFAULT_MAX_LINKED_PDFS = _int_env("MAX_LINKED_PDFS", 3, 0, 5)
MAX_HTML_CHARS = _int_env("MAX_HTML_CHARS", 2_000_000, 10_000, 5_000_000)

CORS_ORIGINS = [x.strip() for x in os.getenv(
    "CORS_ORIGINS", "http://127.0.0.1:8000,http://localhost:8000"
).split(",") if x.strip()]
RATE_LIMIT_WINDOW = 60
RATE_LIMIT_MAX = _int_env("RATE_LIMIT_PER_MINUTE", 20, 5, 120)
