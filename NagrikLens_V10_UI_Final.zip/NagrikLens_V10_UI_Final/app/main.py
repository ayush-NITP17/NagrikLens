from __future__ import annotations

import hmac
import os
import uuid
import threading
import time
from collections import defaultdict, deque
from contextlib import asynccontextmanager
from fastapi import FastAPI, File, Form, Header, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles

from .config import ADMIN_API_KEY, API_ACCESS_KEY, CORS_ORIGINS, DEFAULT_MAX_LINKED_PDFS, LLM_API_KEY, LLM_BASE_URL, LLM_MODEL, MAX_JSON_BODY_BYTES, MAX_UPLOAD_BYTES, RATE_LIMIT_MAX, RATE_LIMIT_WINDOW, ROOT
from .ingestion import IngestionError, ingest_pdf_upload, ingest_url, inspect_pdf_upload
from .llm import LLMUnavailable, extract_policy_structure
from .models import (AdminRejectSourceRequest, AdminSourceRequest, AnalyseRequest, EligibilityRequest, IngestURLRequest, QueryRequest, QueryResponse)
from .policy import build_response
from .rules import evaluate_conditions
from .store import (
    approve_source_host, delete_document, get_all_evidence, get_document, get_document_versions,
    get_documents, get_policy_analysis, get_query_session, get_source_registry, init_db,
    mark_previous_live_as_cached, reject_source_host, save_policy_analysis, set_query_session,
)

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    mark_previous_live_as_cached()
    yield


app = FastAPI(
    title="NagrikLens V10 — Evidence-Grounded Government Document Intelligence",
    description=(
        "Upload a PDF or ingest an approved HTTPS source, select the document and pages, "
        "ask questions in English or Hindi, and inspect the supporting evidence and citations. "
        "Eligibility checks evaluate extracted conditions and are not official decisions."
    ),
    version="10.0.0",
    lifespan=lifespan,
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_methods=["GET", "POST", "DELETE"],
    allow_headers=["Content-Type", "X-Nagriklens-Language", "X-Nagriklens-API-Key", "X-Nagriklens-Admin-Key"],
)
app.mount("/static", StaticFiles(directory=ROOT / "app" / "static"), name="static")

_rate_lock = threading.Lock()
_rate_events: dict[str, deque[float]] = defaultdict(deque)


@app.middleware("http")
async def request_limits(request, call_next):
    # Optional shared-key gate for controlled demos. Health remains public so a
    # platform health check can determine whether the process is alive.
    if request.url.path.startswith("/api/") and request.url.path != "/api/health" and API_ACCESS_KEY:
        supplied_key = request.headers.get("x-nagriklens-api-key", "")
        if not hmac.compare_digest(supplied_key, API_ACCESS_KEY):
            from fastapi.responses import JSONResponse
            return JSONResponse(status_code=401, content={"detail": "A valid NagrikLens access key is required for this demo."})

    if request.method == "POST" and request.url.path.startswith("/api/"):
        body_limit = MAX_UPLOAD_BYTES + 128 * 1024 if request.url.path in {"/api/documents/upload", "/api/documents/inspect-pdf"} else MAX_JSON_BODY_BYTES
        content_length = request.headers.get("content-length")
        if content_length:
            try:
                if int(content_length) > body_limit:
                    from fastapi.responses import JSONResponse
                    return JSONResponse(status_code=413, content={"detail": "Request body exceeds the configured size limit."})
            except ValueError:
                from fastapi.responses import JSONResponse
                return JSONResponse(status_code=400, content={"detail": "Invalid Content-Length header."})

        # Enforce the same limit while streaming, including chunked requests with
        # no Content-Length. Replay the bounded body for FastAPI's normal parser.
        chunks = []
        total = 0
        async for chunk in request.stream():
            total += len(chunk)
            if total > body_limit:
                from fastapi.responses import JSONResponse
                return JSONResponse(status_code=413, content={"detail": "Request body exceeds the configured size limit."})
            chunks.append(chunk)
        request._body = b"".join(chunks)
        # Starlette's cached middleware request replays _body to downstream
        # parsers (JSON and multipart) without exposing the consumed stream.

        # Per-process, per-client/path rate limiting is a local demo safeguard.
        # Use a trusted gateway limiter for multi-worker/public deployments.
        host = request.client.host if request.client else "unknown"
        key = f"{host}:{request.url.path}"
        now = time.monotonic()
        with _rate_lock:
            events = _rate_events[key]
            while events and now - events[0] > RATE_LIMIT_WINDOW:
                events.popleft()
            if len(events) >= RATE_LIMIT_MAX:
                from fastapi.responses import JSONResponse
                return JSONResponse(status_code=429, content={"detail": "Too many requests. Please wait and try again."})
            events.append(now)
    return await call_next(request)


@app.get("/", response_class=HTMLResponse)
def home():
    return (ROOT / "app" / "static" / "index.html").read_text(encoding="utf-8")


@app.get("/api/health")
def health():
    docs = get_documents()
    return {
        "status": "ok", "application": "NagrikLens", "version": app.version,
        "documents": len(docs),
        "live_documents": sum(x.get("freshness") == "LIVE" for x in docs),
        "user_uploaded_documents": sum(x.get("provenance") in {"USER_UPLOAD", "USER_UPLOADED"} for x in docs),
        "llm_configured": bool(LLM_API_KEY),
        "auth_required": bool(API_ACCESS_KEY),
    }


@app.get("/api/documents")
def documents():
    return {
        "documents": get_documents(),
        "note": "No bundled scheme catalogue or source snapshot is loaded as current data. Add a genuine source by HTTPS URL or upload a PDF.",
    }


@app.post("/api/documents/ingest-url")
def ingest_url_route(req: IngestURLRequest):
    try:
        return ingest_url(
            req.url, title=req.title, jurisdiction=req.jurisdiction,
            include_linked_pdfs=req.include_linked_pdfs,
            max_linked_pdfs=min(req.max_linked_pdfs, DEFAULT_MAX_LINKED_PDFS),
            page_mode=req.page_mode, max_page_number=req.max_page_number,
            selected_pages=req.selected_pages or None,
        )
    except IngestionError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    except Exception:
        raise HTTPException(status_code=502, detail="The source could not be retrieved or processed. Check the URL and try again.")


@app.post("/api/documents/inspect-pdf")
async def inspect_pdf_document(file: UploadFile = File(...)):
    filename = file.filename or "policy.pdf"
    if not filename.lower().endswith(".pdf"):
        raise HTTPException(status_code=415, detail="Only PDF uploads are supported.")
    data = await file.read(MAX_UPLOAD_BYTES + 1)
    await file.close()
    if len(data) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail=f"PDF exceeds the configured {MAX_UPLOAD_BYTES}-byte upload limit.")
    try:
        return inspect_pdf_upload(data, filename)
    except IngestionError as exc:
        raise HTTPException(status_code=422, detail=str(exc))


@app.post("/api/documents/upload")
async def upload_document(
    file: UploadFile = File(...),
    jurisdiction: str = Form(default="India"),
    page_mode: str = Form(default="max_page"),
    max_page_number: int | None = Form(default=None),
    selected_pages: str = Form(default=""),
):
    filename = file.filename or "policy.pdf"
    if not filename.lower().endswith(".pdf"):
        raise HTTPException(status_code=415, detail="Only PDF uploads are supported.")
    data = await file.read(MAX_UPLOAD_BYTES + 1)
    await file.close()
    if len(data) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail=f"PDF exceeds the configured {MAX_UPLOAD_BYTES}-byte upload limit.")
    try:
        return ingest_pdf_upload(
            data, filename, jurisdiction=jurisdiction, page_mode=page_mode,
            max_page_number=max_page_number, selected_pages=selected_pages or None,
        )
    except IngestionError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    except Exception:
        raise HTTPException(status_code=400, detail="The PDF could not be processed. Try a text-searchable, unlocked PDF.")


@app.get("/api/documents/{document_id}")
def document_detail(document_id: str):
    doc = get_document(document_id)
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found.")
    evidence = get_all_evidence(document_id=document_id)
    doc.pop("raw_text", None)
    return {"document": doc, "evidence": evidence}


@app.get("/api/documents/{document_id}/versions")
def document_versions(document_id: str):
    if not get_document(document_id):
        raise HTTPException(status_code=404, detail="Document not found.")
    return {"document_id": document_id, "versions": get_document_versions(document_id)}


@app.post("/api/documents/{document_id}/analyse")
def analyse_document(document_id: str, req: AnalyseRequest):
    doc = get_document(document_id)
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found.")
    evidence = get_all_evidence(document_id=document_id)
    try:
        result = extract_policy_structure(evidence, language=req.language)
        result["document"] = {
            "document_id": document_id, "title": doc["title"],
            "source_url": doc["source_url"], "freshness": doc["freshness"],
            "authority_status": doc["authority_status"], "retrieved_at": doc["retrieved_at"],
        }
        extraction_note = doc.get("extraction_note") or ""
        processing_report = doc.get("processing_report") or {}
        if not processing_report.get("overall_completeness", True):
            result["analysis_coverage"]["complete"] = False
            result["analysis_coverage"]["processing_report"] = processing_report
        if extraction_note:
            result["analysis_coverage"]["extraction_note"] = extraction_note
        analysis_id = save_policy_analysis(document_id, doc["normalized_hash"], req.language, result)
        result["analysis_id"] = analysis_id
        result["note"] = "This extraction is a reading aid. Check the original document, all amendments, commencement notices and full scheme guidelines before acting."
        if not result.get("analysis_coverage", {}).get("complete", False):
            result["note"] += " The document was only partially analysed because of the processing limit; do not treat missing items as absent from the full document."
        return result
    except LLMUnavailable as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    except Exception:
        raise HTTPException(status_code=502, detail="The document could not be structured safely. Try fewer pages or a different model configuration.")


@app.post("/api/documents/{document_id}/eligibility")
def document_eligibility(document_id: str, req: EligibilityRequest):
    doc = get_document(document_id)
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found.")
    language = req.answer_language
    analysis = get_policy_analysis(document_id, doc["normalized_hash"], language)
    if not analysis:
        try:
            analysis = extract_policy_structure(get_all_evidence(document_id=document_id), language=language)
            save_policy_analysis(document_id, doc["normalized_hash"], language, analysis)
        except LLMUnavailable as exc:
            raise HTTPException(status_code=503, detail=str(exc))
        except Exception:
            raise HTTPException(status_code=502, detail="Conditions could not be extracted and verified from this document.")
    conditions = analysis.get("eligibility_conditions", [])
    result = evaluate_conditions(conditions, req.profile)
    processing_report = doc.get("processing_report") or {}
    coverage = dict(analysis.get("analysis_coverage", {"complete": True}))
    extraction_complete = bool(processing_report.get("overall_completeness", True))
    if not extraction_complete:
        coverage["complete"] = False
        coverage["document_processing_report"] = processing_report
        result["overall_status"] = "INCOMPLETE_DOCUMENT_ANALYSIS_REVIEW_REQUIRED"
    statuses = [item.get("status") for item in result.get("conditions", [])]
    result["conditions_found"] = len(result.get("conditions", []))
    result["conditions_met"] = sum(status == "MET" for status in statuses)
    result["conditions_not_met"] = sum(status == "NOT_MET" for status in statuses)
    result["conditions_unknown"] = sum(status == "UNKNOWN" for status in statuses)
    result["missing_user_information"] = [
        {"condition": item.get("condition"), "question_to_ask": item.get("question_to_ask") or item.get("reason")}
        for item in result.get("conditions", []) if item.get("status") == "UNKNOWN"
    ]
    evidence_by_id = {row.get("evidence_id"): row for row in get_all_evidence(document_id=document_id)}
    citations = []
    for item in result.get("conditions", []):
        evidence_id = item.get("evidence_id")
        evidence_row = evidence_by_id.get(evidence_id)
        if evidence_row and evidence_id not in {x["evidence_id"] for x in citations}:
            citations.append({"evidence_id": evidence_id, "document_id": document_id,
                "title": doc.get("title"), "page": evidence_row.get("page"),
                "section": evidence_row.get("section"), "source_url": doc.get("source_url"),
                "quote": item.get("source_quote"), "authority_status": doc.get("authority_status"),
                "provenance": doc.get("provenance")})
    result["citations"] = citations
    result["analysis_coverage"] = coverage
    result["processing_report"] = processing_report
    result["document"] = {"document_id": document_id, "title": doc["title"], "source_url": doc["source_url"],
                          "provenance": doc.get("provenance"), "authority_status": doc.get("authority_status")}
    result["extraction_note"] = "Conditions were extracted with source quotes and compared deterministically with the profile. Missing, vague or unsupported conditions remain UNKNOWN. This is not an official eligibility decision."
    if not extraction_complete or not coverage.get("complete", True):
        result["extraction_note"] += " Processing or structured extraction is partial; other conditions may exist in passages not analysed."
    return result


@app.get("/api/sessions/new")
def new_query_session():
    # The caller should retain this opaque ID locally and reuse it for follow-ups.
    return {"session_id": str(uuid.uuid4()), "note": "A session retains selected document IDs only; it is not user authentication or conversational transcript storage."}


@app.post("/api/query", response_model=QueryResponse)
def query(req: QueryRequest):
    selected_ids = list(dict.fromkeys(([req.document_id] if req.document_id else []) + req.document_ids))
    if not selected_ids and req.session_id:
        selected_ids = get_query_session(req.session_id)
    if not selected_ids:
        raise HTTPException(status_code=422, detail="Select an active document before asking a question. Provide document_id/document_ids or a session_id with a previously selected source.")
    for selected_id in selected_ids:
        if not get_document(selected_id):
            raise HTTPException(status_code=404, detail=f"Selected document '{selected_id}' was not found.")
    if req.session_id:
        set_query_session(req.session_id, selected_ids)
    requested_language = req.answer_language if req.answer_language != "same_as_question" else req.language
    try:
        return build_response(
            req.question, requested_language, req.profile, req.use_llm,
            req.require_live_sources, document_id=selected_ids[0] if len(selected_ids) == 1 else None,
            document_ids=selected_ids,
        )
    except Exception:
        raise HTTPException(status_code=500, detail="The question could not be processed safely. Check the source selection and try again.")


@app.get("/api/documents/{document_id}/processing-report")
def document_processing_report(document_id: str):
    doc = get_document(document_id)
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found.")
    return {"document_id": document_id, "title": doc.get("title"),
            "source_url": doc.get("source_url"), "provenance": doc.get("provenance"),
            "processing_report": doc.get("processing_report") or {},
            "selected_pages": doc.get("selected_pages") or [],
            "extraction_note": doc.get("extraction_note")}


@app.get("/api/sources/registry")
def source_registry():
    from urllib.parse import urlparse
    docs = get_documents()
    ingested_documents = []
    for doc in docs:
        user_upload = doc.get("provenance") in {"USER_UPLOAD", "USER_UPLOADED"}
        ingested_documents.append({
            "document_id": doc.get("document_id"), "title": doc.get("title"),
            "source_url": doc.get("source_url"), "hostname": None if user_upload else urlparse(doc.get("source_url", "")).hostname,
            "provenance": doc.get("provenance"), "authority_status": doc.get("authority_status"),
            "document_ingested": True,
            "host_fetch_status": "NOT_APPLICABLE_USER_UPLOAD" if user_upload else "FETCHED_FROM_ALLOWLISTED_HOST",
        })
    return {"sources": get_source_registry(), "ingested_documents": ingested_documents,
            "note": "Host approval permits fetching from that exact hostname only. It does not independently authenticate an individual document or its legal authority."}


def _require_admin_key(supplied: str) -> None:
    if not ADMIN_API_KEY:
        raise HTTPException(status_code=503, detail="Administrator source approval is disabled. Configure NAGRIKLENS_ADMIN_KEY on the server.")
    if not supplied or not hmac.compare_digest(supplied, ADMIN_API_KEY):
        raise HTTPException(status_code=401, detail="A valid administrator key is required.")


@app.post("/api/admin/sources/approve")
def admin_approve_source(req: AdminSourceRequest, x_nagriklens_admin_key: str = Header(default="")):
    _require_admin_key(x_nagriklens_admin_key)
    try:
        result = approve_source_host(req.hostname, req.authority, req.verification_status)
        return {"source": result, "note": "The exact hostname is approved for fetching after public-DNS validation. This action does not authenticate individual documents or establish legal authority."}
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))


@app.post("/api/admin/sources/reject")
def admin_reject_source(req: AdminRejectSourceRequest, x_nagriklens_admin_key: str = Header(default="")):
    _require_admin_key(x_nagriklens_admin_key)
    try:
        return {"source": reject_source_host(req.hostname, req.reason)}
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))


@app.delete("/api/documents/{document_id}")
def delete_document_route(document_id: str):
    if not delete_document(document_id):
        raise HTTPException(status_code=404, detail="Document not found.")
    return {"deleted": True, "document_id": document_id}


@app.get("/api/metrics")
def metrics():
    docs = get_documents()
    evidence = get_all_evidence()
    return {
        "documents": len(docs), "evidence_chunks": len(evidence),
        "live_documents": sum(x.get("freshness") == "LIVE" for x in docs),
        "cached_documents": sum(x.get("freshness") == "CACHED" for x in docs),
        "user_uploaded_documents": sum(x.get("provenance") in {"USER_UPLOAD", "USER_UPLOADED"} for x in docs),
        "note": "Metrics describe documents actually ingested into this installation; no bundled sample scheme records are included.",
    }


@app.get("/api/changes")
def changes():
    docs = get_documents()
    versions = []
    for doc in docs:
        versions.extend(get_document_versions(doc["document_id"], 5))
    return {
        "versions": sorted(versions, key=lambda x: x.get("retrieved_at", ""), reverse=True),
        "note": "Text changes are review flags, not automatic proof of a legal amendment. Open the source and compare the exact changed passage.",
    }


@app.get("/api/llm-status")
def llm_status():
    return {
        "configured": bool(LLM_API_KEY),
        "model": LLM_MODEL,
        "base_url_configured": bool(LLM_BASE_URL),
        "note": "An external model call has not been tested unless you have configured your own valid key and exercised it from this installation.",
    }
