from __future__ import annotations

import difflib
import hashlib
import json
import re
import sqlite3
import unicodedata
from datetime import datetime, timezone
from typing import Any

from .config import DB_FILE


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def connect() -> sqlite3.Connection:
    DB_FILE.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_FILE, timeout=20)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=20000")
    return conn


def normalize_for_hash(text: str) -> str:
    text = unicodedata.normalize("NFKC", text or "")
    text = re.sub(r"\[PDF PAGE \d+\]", " ", text, flags=re.I)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def _short_hash(value: str, length: int = 16) -> str:
    return hashlib.sha256(value.encode("utf-8", errors="ignore")).hexdigest()[:length]



def _section_map(text: str) -> dict[str, str]:
    """Best-effort section partition; preserve same-line heading body as content."""
    lines = (text or "").splitlines()
    heading_re = re.compile(
        r"^\s*((?:section|sec\.?|rule|chapter|article|schedule|धारा|नियम|अध्याय)"
        r"\s+[0-9A-Za-z()./-]+\.?)(?:\s*[-—:]\s*|\s+)?(.*)$", re.I
    )
    current = "Document body"
    buckets: dict[str, list[str]] = {current: []}
    for line in lines:
        clean = line.strip()
        match = heading_re.match(clean)
        if match:
            current = re.sub(r"\s+", " ", match.group(1)).strip().rstrip(".")
            buckets.setdefault(current, [])
            remainder = (match.group(2) or "").strip()
            if remainder:
                buckets[current].append(remainder)
        else:
            buckets.setdefault(current, []).append(line)
    return {key: normalize_for_hash("\n".join(value)) for key, value in buckets.items() if normalize_for_hash("\n".join(value))}


def _section_diff(previous_text: str, current_text: str) -> tuple[str, str]:
    old = _section_map(previous_text)
    new = _section_map(current_text)
    changed = []
    for key in sorted(set(old) | set(new)):
        if key not in old:
            changed.append(f"ADDED {key}: {new[key][:260]}")
        elif key not in new:
            changed.append(f"REMOVED {key}: {old[key][:260]}")
        elif old[key] != new[key]:
            matcher = difflib.SequenceMatcher(a=old[key], b=new[key], autojunk=False)
            excerpts = []
            def context(value: str, start: int, end: int, width: int = 90) -> str:
                left = max(0, start - width)
                right = min(len(value), max(end, start + 1) + width)
                return value[left:right].strip()
            for tag, i1, i2, j1, j2 in matcher.get_opcodes():
                if tag == "equal":
                    continue
                if tag in {"replace", "delete"} and old[key][i1:i2].strip():
                    excerpts.append("OLD: " + context(old[key], i1, i2)[:240])
                if tag in {"replace", "insert"} and new[key][j1:j2].strip():
                    excerpts.append("NEW: " + context(new[key], j1, j2)[:240])
                if len(excerpts) >= 4:
                    break
            changed.append(f"CHANGED {key}: " + " | ".join(excerpts))
    if changed:
        return "SECTION_TEXT_CHANGED_REVIEW_REQUIRED", "\n".join(changed[:20])
    before = [x.strip() for x in previous_text.splitlines() if len(x.strip()) > 35]
    after = [x.strip() for x in current_text.splitlines() if len(x.strip()) > 35]
    diff = list(difflib.unified_diff(before, after, fromfile="previous", tofile="current", lineterm=""))
    return "TEXT_CHANGED_REVIEW_REQUIRED", "\n".join(diff[:50]) or "Extracted text changed; inspect the source."

def init_db() -> None:
    with connect() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS documents (
            document_id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            source_url TEXT NOT NULL,
            canonical_url TEXT,
            jurisdiction TEXT,
            issuing_authority TEXT,
            authority_status TEXT NOT NULL,
            provenance TEXT NOT NULL,
            freshness TEXT NOT NULL,
            retrieved_at TEXT NOT NULL,
            document_date TEXT,
            content_type TEXT,
            raw_hash TEXT NOT NULL,
            normalized_hash TEXT NOT NULL,
            raw_text TEXT NOT NULL,
            page_count INTEGER NOT NULL DEFAULT 0,
            extraction_note TEXT,
            processing_report_json TEXT NOT NULL DEFAULT '{}',
            selected_pages_json TEXT NOT NULL DEFAULT '[]'
        );
        CREATE TABLE IF NOT EXISTS evidence (
            evidence_id TEXT PRIMARY KEY,
            document_id TEXT NOT NULL,
            chunk_index INTEGER NOT NULL,
            section TEXT,
            page INTEGER,
            text TEXT NOT NULL,
            FOREIGN KEY(document_id) REFERENCES documents(document_id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_evidence_doc ON evidence(document_id);
        CREATE TABLE IF NOT EXISTS document_versions (
            version_id TEXT PRIMARY KEY,
            document_id TEXT NOT NULL,
            version_number INTEGER NOT NULL,
            raw_hash TEXT NOT NULL,
            normalized_hash TEXT NOT NULL,
            change_kind TEXT NOT NULL,
            change_summary TEXT NOT NULL,
            retrieved_at TEXT NOT NULL,
            source_url TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS policy_analyses (
            analysis_id TEXT PRIMARY KEY,
            document_id TEXT NOT NULL,
            normalized_hash TEXT NOT NULL,
            language TEXT NOT NULL,
            result_json TEXT NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY(document_id) REFERENCES documents(document_id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_analysis_doc ON policy_analyses(document_id, created_at DESC);
        CREATE TABLE IF NOT EXISTS app_meta (
            meta_key TEXT PRIMARY KEY,
            meta_value INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS source_registry (
            hostname TEXT PRIMARY KEY,
            authority TEXT NOT NULL DEFAULT '',
            approval_status TEXT NOT NULL CHECK(approval_status IN ('APPROVED','PENDING','REJECTED')),
            verification_status TEXT NOT NULL DEFAULT 'NOT_INDEPENDENTLY_VERIFIED',
            added_by TEXT NOT NULL DEFAULT 'system',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS query_sessions (
            session_id TEXT PRIMARY KEY,
            document_ids_json TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        INSERT OR IGNORE INTO app_meta(meta_key, meta_value) VALUES('retrieval_revision', 0);
        """)
        # v0.7 used UNIQUE(document_id, normalized_hash), which accidentally
        # prevented recording a legitimate revert from A -> B -> A as version 3.
        # Migrate older databases to append-only version history keyed by version_id.
        version_indexes = c.execute("PRAGMA index_list(document_versions)").fetchall()
        needs_rebuild = False
        for index_row in version_indexes:
            if not index_row["unique"] or index_row["origin"] != "u":
                continue
            columns = [x["name"] for x in c.execute(f'PRAGMA index_info("{index_row["name"]}")').fetchall()]
            if columns == ["document_id", "normalized_hash"]:
                needs_rebuild = True
                break
        if needs_rebuild:
            c.execute("DROP INDEX IF EXISTS idx_versions_doc")
            c.execute("ALTER TABLE document_versions RENAME TO document_versions_legacy")
            c.execute("""CREATE TABLE document_versions (
                version_id TEXT PRIMARY KEY, document_id TEXT NOT NULL,
                version_number INTEGER NOT NULL, raw_hash TEXT NOT NULL,
                normalized_hash TEXT NOT NULL, change_kind TEXT NOT NULL,
                change_summary TEXT NOT NULL, retrieved_at TEXT NOT NULL, source_url TEXT NOT NULL
            )""")
            c.execute("""INSERT INTO document_versions
                (version_id, document_id, version_number, raw_hash, normalized_hash,
                 change_kind, change_summary, retrieved_at, source_url)
                SELECT version_id, document_id, version_number, raw_hash, normalized_hash,
                 change_kind, change_summary, retrieved_at, source_url
                FROM document_versions_legacy""")
            c.execute("DROP TABLE document_versions_legacy")
        c.execute("CREATE INDEX IF NOT EXISTS idx_versions_doc ON document_versions(document_id, version_number DESC)")
        # Additive Phase 2 metadata migration; safe for an existing V9/V10 database.
        columns = {row["name"] for row in c.execute("PRAGMA table_info(documents)").fetchall()}
        if "processing_report_json" not in columns:
            c.execute("ALTER TABLE documents ADD COLUMN processing_report_json TEXT NOT NULL DEFAULT '{}'")
        if "selected_pages_json" not in columns:
            c.execute("ALTER TABLE documents ADD COLUMN selected_pages_json TEXT NOT NULL DEFAULT '[]'")


def mark_previous_live_as_cached() -> None:
    """LIVE means fetched in the current process/session, not merely once in the past."""
    init_db()
    with connect() as c:
        cur = c.execute("UPDATE documents SET freshness='CACHED' WHERE freshness='LIVE'")
        if cur.rowcount:
            c.execute("UPDATE app_meta SET meta_value=meta_value+1 WHERE meta_key='retrieval_revision'")


def get_retrieval_revision() -> int:
    """Monotonic revision used to invalidate the in-process retrieval index."""
    init_db()
    with connect() as c:
        row = c.execute("SELECT meta_value FROM app_meta WHERE meta_key='retrieval_revision'").fetchone()
        return int(row[0]) if row else 0


def upsert_document(doc: dict[str, Any]) -> dict[str, Any]:
    init_db()
    now = utcnow()
    raw_text = doc.get("raw_text", "")
    raw_hash = hashlib.sha256(raw_text.encode("utf-8", errors="ignore")).hexdigest()
    normalized_hash = hashlib.sha256(normalize_for_hash(raw_text).encode("utf-8")).hexdigest()
    document_id = doc["document_id"]
    retrieved_at = doc.get("retrieved_at") or now
    previous = None
    with connect() as c:
        previous = c.execute(
            "SELECT normalized_hash, raw_hash, raw_text FROM documents WHERE document_id=?",
            (document_id,),
        ).fetchone()
        record_version = False
        if previous is None:
            version_number = c.execute(
                "SELECT COALESCE(MAX(version_number),0)+1 FROM document_versions WHERE document_id=?",
                (document_id,),
            ).fetchone()[0]
            change_kind = "BASELINE"
            change_summary = "First stored version. This is a baseline, not evidence of a policy change."
            record_version = True
        elif previous["normalized_hash"] == normalized_hash:
            version_number = c.execute(
                "SELECT COALESCE(MAX(version_number),1) FROM document_versions WHERE document_id=?",
                (document_id,),
            ).fetchone()[0]
            change_kind = "UNCHANGED_AFTER_NORMALIZATION"
            change_summary = "No substantive extracted-text difference after whitespace/page-marker normalization."
        else:
            version_number = c.execute(
                "SELECT COALESCE(MAX(version_number),0)+1 FROM document_versions WHERE document_id=?",
                (document_id,),
            ).fetchone()[0]
            change_kind, section_changes = _section_diff(previous["raw_text"], raw_text)
            change_summary = (
                "Extracted source text changed; this is not automatically a legal amendment. "
                "Review changed section passages in the official source.\n" + section_changes
            )
            record_version = True

        if record_version:
            version_id = _short_hash(f"{document_id}:{version_number}:{normalized_hash}:{retrieved_at}", 24)
            c.execute("""INSERT INTO document_versions
                (version_id, document_id, version_number, raw_hash, normalized_hash,
                 change_kind, change_summary, retrieved_at, source_url)
                VALUES(?,?,?,?,?,?,?,?,?)""",
                (version_id, document_id, version_number, raw_hash, normalized_hash,
                 change_kind, change_summary, retrieved_at, doc.get("source_url", "")))

        c.execute("""INSERT INTO documents
            (document_id,title,source_url,canonical_url,jurisdiction,issuing_authority,
             authority_status,provenance,freshness,retrieved_at,document_date,content_type,
             raw_hash,normalized_hash,raw_text,page_count,extraction_note,processing_report_json,selected_pages_json)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(document_id) DO UPDATE SET
              title=excluded.title, source_url=excluded.source_url, canonical_url=excluded.canonical_url,
              jurisdiction=excluded.jurisdiction, issuing_authority=excluded.issuing_authority,
              authority_status=excluded.authority_status, provenance=excluded.provenance,
              freshness=excluded.freshness, retrieved_at=excluded.retrieved_at,
              document_date=excluded.document_date, content_type=excluded.content_type,
              raw_hash=excluded.raw_hash, normalized_hash=excluded.normalized_hash,
              raw_text=excluded.raw_text, page_count=excluded.page_count,
              extraction_note=excluded.extraction_note,
              processing_report_json=excluded.processing_report_json,
              selected_pages_json=excluded.selected_pages_json""",
            (document_id, doc.get("title") or "Untitled source", doc.get("source_url", ""),
             doc.get("canonical_url", ""), doc.get("jurisdiction", "India"),
             doc.get("issuing_authority", "Not identified"), doc.get("authority_status", "UNVERIFIED"),
             doc.get("provenance", "USER_SUPPLIED"), doc.get("freshness", "USER_UPLOADED"),
             retrieved_at, doc.get("document_date"), doc.get("content_type", "application/pdf"),
             raw_hash, normalized_hash, raw_text, int(doc.get("page_count", 0)), doc.get("extraction_note", ""),
             json.dumps(doc.get("processing_report", {}), ensure_ascii=False),
             json.dumps(doc.get("selected_pages", []), ensure_ascii=False)))

        # IDs are namespaced by document, so identical source-local IDs cannot collide.
        c.execute("DELETE FROM evidence WHERE document_id=?", (document_id,))
        for idx, item in enumerate(doc.get("evidence", [])):
            source_local_id = item.get("evidence_id") or f"chunk-{idx}"
            evidence_id = f"{document_id}::{source_local_id}"
            c.execute("""INSERT INTO evidence(evidence_id,document_id,chunk_index,section,page,text)
                VALUES(?,?,?,?,?,?)""",
                (evidence_id, document_id, int(item.get("chunk_index", idx)),
                 item.get("section", "Document text"), item.get("page"), item.get("text", "")))

        # An updated document invalidates prior extracted facts. They are version-specific.
        c.execute("DELETE FROM policy_analyses WHERE document_id=? AND normalized_hash<>?", (document_id, normalized_hash))
        c.execute("UPDATE app_meta SET meta_value=meta_value+1 WHERE meta_key='retrieval_revision'")

    return {
        "document_id": document_id, "version_number": version_number,
        "change_kind": change_kind, "change_summary": change_summary,
        "raw_hash": raw_hash, "normalized_hash": normalized_hash,
        "evidence_count": len(doc.get("evidence", [])),
    }


def get_all_evidence(freshness: str | None = None, document_id: str | None = None) -> list[dict[str, Any]]:
    sql = """SELECT e.*, d.title, d.source_url, d.canonical_url, d.jurisdiction,
        d.issuing_authority, d.authority_status, d.provenance, d.freshness,
        d.retrieved_at, d.document_date, d.content_type, d.normalized_hash,
        d.extraction_note, d.page_count, d.processing_report_json, d.selected_pages_json
        FROM evidence e JOIN documents d ON e.document_id=d.document_id WHERE 1=1"""
    params: list[Any] = []
    if freshness:
        sql += " AND d.freshness=?"
        params.append(freshness)
    if document_id:
        sql += " AND d.document_id=?"
        params.append(document_id)
    sql += " ORDER BY d.retrieved_at DESC, e.chunk_index ASC"
    with connect() as c:
        rows = [dict(row) for row in c.execute(sql, params).fetchall()]
    for item in rows:
        item["processing_report"] = _json_or(item.pop("processing_report_json", "{}"), {})
        item["selected_pages"] = _json_or(item.pop("selected_pages_json", "[]"), [])
    return rows


def get_documents() -> list[dict[str, Any]]:
    with connect() as c:
        rows = c.execute("""SELECT document_id,title,source_url,canonical_url,jurisdiction,
            issuing_authority,authority_status,provenance,freshness,retrieved_at,
            document_date,content_type,raw_hash,normalized_hash,page_count,extraction_note,
            processing_report_json,selected_pages_json
            FROM documents ORDER BY retrieved_at DESC""").fetchall()
        result = [dict(row) for row in rows]
        for item in result:
            item["processing_report"] = _json_or(item.pop("processing_report_json", "{}"), {})
            item["selected_pages"] = _json_or(item.pop("selected_pages_json", "[]"), [])
        return result


def _json_or(value: str | None, fallback: Any) -> Any:
    try:
        return json.loads(value or "")
    except (TypeError, ValueError):
        return fallback


def get_document(document_id: str) -> dict[str, Any] | None:
    with connect() as c:
        row = c.execute("SELECT * FROM documents WHERE document_id=?", (document_id,)).fetchone()
        if not row:
            return None
        result = dict(row)
        result["processing_report"] = _json_or(result.pop("processing_report_json", "{}"), {})
        result["selected_pages"] = _json_or(result.pop("selected_pages_json", "[]"), [])
        return result


def get_document_versions(document_id: str, limit: int = 20) -> list[dict[str, Any]]:
    with connect() as c:
        rows = c.execute("""SELECT * FROM document_versions WHERE document_id=?
            ORDER BY version_number DESC LIMIT ?""", (document_id, max(1, min(limit, 50)))).fetchall()
        return [dict(row) for row in rows]


def save_policy_analysis(document_id: str, normalized_hash: str, language: str, result: dict[str, Any]) -> str:
    analysis_id = _short_hash(f"{document_id}:{normalized_hash}:{language}:{utcnow()}", 24)
    with connect() as c:
        c.execute("""INSERT INTO policy_analyses(analysis_id,document_id,normalized_hash,language,result_json,created_at)
            VALUES(?,?,?,?,?,?)""",
            (analysis_id, document_id, normalized_hash, language, json.dumps(result, ensure_ascii=False), utcnow()))
    return analysis_id


def get_policy_analysis(document_id: str, normalized_hash: str, language: str | None = None) -> dict[str, Any] | None:
    sql = "SELECT result_json FROM policy_analyses WHERE document_id=? AND normalized_hash=?"
    params: list[Any] = [document_id, normalized_hash]
    if language:
        sql += " AND language=?"
        params.append(language)
    sql += " ORDER BY created_at DESC LIMIT 1"
    with connect() as c:
        row = c.execute(sql, params).fetchone()
        return json.loads(row[0]) if row else None


# ---------------- Phase 2 source registry and document lifecycle ----------------
def get_effective_allowed_source_hosts() -> set[str]:
    from .config import ALLOWED_SOURCE_HOSTS
    hosts = set(ALLOWED_SOURCE_HOSTS)
    try:
        with connect() as c:
            rows = c.execute("SELECT hostname,approval_status FROM source_registry").fetchall()
        for row in rows:
            if row["approval_status"] == "APPROVED":
                hosts.add(str(row["hostname"]).lower())
            elif row["approval_status"] == "REJECTED":
                hosts.discard(str(row["hostname"]).lower())
    except sqlite3.Error:
        # Configured hosts remain available before first database initialization.
        pass
    return hosts


def record_source_host_request(hostname: str, status: str = "PENDING") -> None:
    host = (hostname or "").lower().rstrip(".")
    if not host or len(host) > 253:
        return
    status = status.upper()
    if status not in {"PENDING", "REJECTED"}:
        status = "PENDING"
    init_db()
    now = utcnow()
    with connect() as c:
        existing = c.execute("SELECT approval_status FROM source_registry WHERE hostname=?", (host,)).fetchone()
        if existing and existing[0] in {"APPROVED", "REJECTED"}:
            return
        c.execute("""INSERT INTO source_registry(hostname,authority,approval_status,verification_status,added_by,created_at,updated_at)
            VALUES(?,?,?,?,?,?,?) ON CONFLICT(hostname) DO UPDATE SET
            approval_status=excluded.approval_status,updated_at=excluded.updated_at""",
            (host, "", status, "NOT_INDEPENDENTLY_VERIFIED", "citizen_request", now, now))


def approve_source_host(hostname: str, authority: str = "", verification_status: str = "ADMIN_APPROVED_HOST_DOCUMENT_NOT_AUTHENTICATED") -> dict[str, Any]:
    host = (hostname or "").strip().lower().rstrip(".")
    # Exact DNS hostname only; no schemes, paths, wildcards, ports or IP literals.
    if not host or len(host) > 253 or "*" in host or "/" in host or ":" in host or "@" in host or " " in host:
        raise ValueError("Enter an exact hostname only, without scheme, path, port or wildcard.")
    import re
    import ipaddress
    try:
        ipaddress.ip_address(host)
        raise ValueError("IP literals cannot be approved; approve an exact DNS hostname instead.")
    except ValueError as exc:
        if "cannot be approved" in str(exc):
            raise
    if not re.fullmatch(r"(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)(?:\.(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?))*", host):
        raise ValueError("The hostname format is invalid.")
    now = utcnow()
    init_db()
    with connect() as c:
        c.execute("""INSERT INTO source_registry(hostname,authority,approval_status,verification_status,added_by,created_at,updated_at)
            VALUES(?,?,?,?,?,?,?) ON CONFLICT(hostname) DO UPDATE SET authority=excluded.authority,
            approval_status='APPROVED',verification_status=excluded.verification_status,
            added_by='administrator',updated_at=excluded.updated_at""",
            (host, (authority or "")[:200], "APPROVED", (verification_status or "ADMIN_APPROVED_HOST_DOCUMENT_NOT_AUTHENTICATED")[:120], "administrator", now, now))
    return {"hostname": host, "authority": (authority or "")[:200], "approval_status": "APPROVED",
            "verification_status": (verification_status or "ADMIN_APPROVED_HOST_DOCUMENT_NOT_AUTHENTICATED")[:120],
            "document_authentication": "NOT_PERFORMED"}


def reject_source_host(hostname: str, reason: str = "Rejected by administrator") -> dict[str, Any]:
    host = (hostname or "").strip().lower().rstrip(".")
    if not host or "*" in host or "/" in host or ":" in host or "@" in host:
        raise ValueError("Enter an exact hostname only.")
    now = utcnow()
    init_db()
    with connect() as c:
        c.execute("""INSERT INTO source_registry(hostname,authority,approval_status,verification_status,added_by,created_at,updated_at)
            VALUES(?,?,?,?,?,?,?) ON CONFLICT(hostname) DO UPDATE SET approval_status='REJECTED',
            verification_status=excluded.verification_status,added_by='administrator',updated_at=excluded.updated_at""",
            (host, "", "REJECTED", (reason or "REJECTED")[:120], "administrator", now, now))
    return {"hostname": host, "approval_status": "REJECTED", "verification_status": (reason or "REJECTED")[:120]}


def get_source_registry() -> list[dict[str, Any]]:
    from .config import ALLOWED_SOURCE_HOSTS
    configured = set(ALLOWED_SOURCE_HOSTS)
    rows: dict[str, dict[str, Any]] = {}
    for host in configured:
        rows[host] = {
            "hostname": host, "authority": "Publisher not configured",
            "approval_status": "APPROVED", "host_fetch_status": "ALLOWED",
            "verification_status": "GOVERNMENT_HOST_ALLOWLISTED_DOCUMENT_NOT_AUTHENTICATED" if host.endswith((".gov.in", ".nic.in")) or host in {"gov.in", "nic.in"} else "ALLOWLISTED_HOST_NOT_GOVERNMENT_VERIFIED",
            "document_ingested": False,
        }
    init_db()
    with connect() as c:
        for row in c.execute("SELECT hostname,authority,approval_status,verification_status,added_by,created_at,updated_at FROM source_registry").fetchall():
            d = dict(row)
            host = d["hostname"]
            if d["approval_status"] == "APPROVED":
                d["host_fetch_status"] = "ALLOWED"
            else:
                d["host_fetch_status"] = "BLOCKED"
            d["document_ingested"] = False
            rows[host] = d
        docs = c.execute("SELECT source_url,issuing_authority,authority_status,provenance FROM documents").fetchall()
    for doc in docs:
        # User-uploaded files are not website hosts and must not pollute the
        # fetch-allowlist registry with synthetic upload:// hostnames.
        if doc["provenance"] in {"USER_UPLOAD", "USER_UPLOADED"}:
            continue
        from urllib.parse import urlparse
        host = (urlparse(str(doc["source_url"])).hostname or "").lower()
        if not host:
            continue
        item = rows.setdefault(host, {"hostname": host, "authority": doc["issuing_authority"] or "",
            "approval_status": "NOT_APPLICABLE", "host_fetch_status": "NOT_FETCHABLE_BY_SERVER",
            "verification_status": doc["authority_status"], "document_ingested": False})
        item["document_ingested"] = True
        if not item.get("authority") or item.get("authority") == "Publisher not configured":
            item["authority"] = doc["issuing_authority"] or "Publisher not configured"
        item.setdefault("documents", []).append({"provenance": doc["provenance"], "authority_status": doc["authority_status"]})
    return sorted(rows.values(), key=lambda x: x["hostname"])


def delete_document(document_id: str) -> bool:
    init_db()
    with connect() as c:
        cur = c.execute("DELETE FROM documents WHERE document_id=?", (document_id,))
        c.execute("DELETE FROM policy_analyses WHERE document_id=?", (document_id,))
        c.execute("DELETE FROM document_versions WHERE document_id=?", (document_id,))
        if cur.rowcount:
            session_rows = c.execute("SELECT session_id,document_ids_json FROM query_sessions").fetchall()
            for row in session_rows:
                ids = _json_or(row["document_ids_json"], [])
                remaining = [x for x in ids if x != document_id]
                if remaining:
                    c.execute("UPDATE query_sessions SET document_ids_json=?,updated_at=? WHERE session_id=?",
                              (json.dumps(remaining), utcnow(), row["session_id"]))
                else:
                    c.execute("DELETE FROM query_sessions WHERE session_id=?", (row["session_id"],))
            c.execute("UPDATE app_meta SET meta_value=meta_value+1 WHERE meta_key='retrieval_revision'")
        return bool(cur.rowcount)


# Session context stores only selected document IDs, not question content or profiles.
def set_query_session(session_id: str, document_ids: list[str]) -> None:
    if not session_id or len(session_id) > 80:
        raise ValueError("Invalid session identifier.")
    cleaned = list(dict.fromkeys(str(x) for x in document_ids if x))
    if not cleaned or len(cleaned) > 10:
        raise ValueError("A session must select between 1 and 10 documents.")
    now = utcnow()
    with connect() as c:
        c.execute("""INSERT INTO query_sessions(session_id,document_ids_json,updated_at) VALUES(?,?,?)
            ON CONFLICT(session_id) DO UPDATE SET document_ids_json=excluded.document_ids_json,updated_at=excluded.updated_at""",
            (session_id, json.dumps(cleaned), now))


def get_query_session(session_id: str) -> list[str]:
    if not session_id:
        return []
    with connect() as c:
        row = c.execute("SELECT document_ids_json FROM query_sessions WHERE session_id=?", (session_id,)).fetchone()
    if not row:
        return []
    value = _json_or(row[0], [])
    return value if isinstance(value, list) else []
