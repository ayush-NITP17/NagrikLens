from __future__ import annotations

import re
import unicodedata
from typing import Any

from .config import MAX_EVIDENCE_CHARS
from .llm import GroundingError, LLMUnavailable, _concepts, _numeric_facts, synthesize_grounded
from .retrieval import STOPWORDS, retrieve
from .store import get_all_evidence, get_document_versions

HI_MARKERS = ("क्या", "है", "मुझे", "मेरे", "कब", "कैसे", "किस", "क्यों", "करें", "मिल", "अधिकार", "शिकायत", "भुगतान", "पैसा")
HINGLISH_MARKERS = {"mujhe", "kya", "kaise", "kab", "hai", "chahiye", "mera", "meri", "kitna", "kitni", "milta", "milega", "karna", "sakta", "sakti", "ke liye", "batao"}

# Small, transparent query-expansion lexicon for common civic terms. This helps
# English-language source documents remain discoverable from common Hindi/Hinglish
# questions when a multilingual embedding model or translation API is unavailable.
# It does not translate answers or establish legal meaning.
BILINGUAL_QUERY_TERMS = {
    "छात्रवृत्ति": "scholarship stipend",
    "स्कॉलरशिप": "scholarship stipend",
    "पात्रता": "eligibility qualify criteria",
    "योग्यता": "eligibility qualification criteria",
    "परिवार की आय": "family income annual household income",
    "आय सीमा": "income limit annual family income",
    "दस्तावेज": "certificate",
    "दस्तावेज़": "certificate",
    "कागजात": "certificate",
    "अंतिम तारीख": "deadline last date closing date",
    "आवेदन": "application apply registration",
    "अधिकार": "rights entitlements legal protections",
    "किसान": "farmer cultivator agriculture",
    "फसल बीमा": "crop insurance PMFBY",
    "बीमा": "insurance policy claim premium",
    "किसान क्रेडिट कार्ड": "Kisan Credit Card KCC agriculture credit",
    "कृषि ऋण": "agriculture loan farm credit",
    "कर्ज": "loan credit borrowing",
    "कर्ज़": "loan credit borrowing",
    "ब्याज": "interest rate subsidy",
    "सब्सिडी": "subsidy grant financial assistance",
    "भूमि": "land agricultural land holding",
    "किरायेदार किसान": "tenant farmer sharecropper cultivator",
    "पेंशन": "pension old age pension social security",
    "उम्र": "age years old",
    "आयु": "age years old",
    "दादाजी": "grandfather elderly old age pension",
    "दादीजी": "grandmother elderly old age pension",
    "बुढ़ापा": "old age elderly pension senior citizen",
    "बुढ़ापे": "old age elderly pension senior citizen",
    "बुजुर्ग": "elderly senior citizen pension",
    "वृद्धावस्था": "old age elderly pension",
    "कमाई": "income",
    "आमदनी": "income",
    "लाभ": "benefit assistance entitlement",
    "योजना": "scheme programme policy",
    "chhatravritti": "stipend",
    "patrata": "eligibility criteria",
    "aay": "income",
    "dastavez": "documents certificates",
    "kisan": "farmer cultivator",
    "fasal bima": "crop insurance PMFBY",
    "karz": "loan credit",
    "byaaj": "interest rate",
    "yojana": "scheme programme",
}

HINDI_SYNONYMS = {
    "दादाजी": "वृद्धावस्था पेंशन",
    "दादीजी": "वृद्धावस्था पेंशन",
    "बुढ़ापा": "वृद्धावस्था पेंशन",
    "बुढ़ापे": "वृद्धावस्था पेंशन",
    "बुजुर्ग": "वृद्धावस्था पेंशन",
    "वृद्धावस्था": "वृद्धावस्था पेंशन",
    "पेंशन": "वृद्धावस्था पेंशन",
    "उम्र": "आयु",
    "आयु": "उम्र",
    "निवास": "निवासी राज्य",
    "निवासी": "निवास राज्य",
    "शर्त": "पात्रता नियम",
    "कमाई": "आय",
    "आमदनी": "आय",
    "छात्रवृत्ति": "छात्रवृत्ति स्कॉलरशिप",
    "दस्तावेज़": "दस्तावेज कागजात",
}

EN_QUERY_SYNONYMS = {
    "college funding": "student scholarship stipend education funding",
    "family income": "parents guardian household annual income",
    "income limit": "income ceiling maximum threshold",
    "daughter": "student",
    "son": "student",
    "earnings": "income",
    "low income": "low family income",
    "college": "education",
    "papers": "documents certificates",
    "scholarship": "stipend",
    "grandfather": "elderly pension",
    "grandmother": "elderly pension",
    "crop loss": "crop insurance claim",
    "tea stall": "shopkeeper trade licence municipal corporation",
    "permission": "licence permit authorisation",
    "opening": "commencing business starting a shop",
    "shop": "shopkeeper trade licence",
    "building a house": "housing grant pucca house construction",
    "house construction": "housing grant pucca house",
    "pregnancy money": "maternity assistance pregnant women cash assistance",
    "pregnancy": "maternity assistance pregnant women",
    "pregnant": "maternity assistance pregnant women",
    "benefit amount": "cash assistance grant payment",
    "documents required": "certificates proof passbook upload",
    "license renewal": "trade licence renewal expiry",
    "dukaan": "shopkeeper trade licence",
    "dukan": "shopkeeper trade licence",
    "garbhvati": "pregnant women maternity assistance",
    "beti": "daughter girl",
    "madad": "assistance benefit cash assistance",
    "paise": "money rupees cash assistance",
    "kitni": "amount money rupees",
    "kitna": "amount money rupees",
}

# Phrase expansions are retrieval hints, never answer facts. Keep them small,
# reviewable and context-triggered; do not inject unrelated scheme-specific terms.
QUERY_EXPANSIONS = {
    **EN_QUERY_SYNONYMS,
    "documents": "certificate income passbook",
    "document": "certificate income passbook",
    "गर्भवती महिला": "pregnant women maternity assistance",
    "गर्भवती": "pregnant women maternity assistance",
    "कितने रुपये": "cash assistance amount rupees",
    "कितनी मदद": "cash assistance benefit",
    "मदद मिलेगी": "cash assistance benefit",
    "दुकान": "shopkeeper trade licence",
    "दुकानदार": "shopkeeper trade licence",
    "लाइसेंस": "licence permit",
    "नवीकरण": "renewal expiry",
    "नवीनीकरण": "renewal expiry",
    "लाइसेंस समाप्त": "licence expiry renewal",
}


def _has_term(text: str, term: str) -> bool:
    value = unicodedata.normalize("NFKC", text or "").casefold()
    needle = unicodedata.normalize("NFKC", term or "").casefold()
    if not needle:
        return False
    if re.fullmatch(r"[a-z0-9 ]+", needle):
        pattern = r"(?<![a-z0-9])" + r"\s+".join(re.escape(x) for x in needle.split()) + r"(?![a-z0-9])"
        return re.search(pattern, value) is not None
    return needle in value


def _replace_term(text: str, term: str, expansion: str) -> str:
    if re.fullmatch(r"[a-z0-9 ]+", term.casefold()):
        pattern = r"(?<![a-z0-9])" + r"\s+".join(re.escape(x) for x in term.split()) + r"(?![a-z0-9])"
        return re.sub(pattern, expansion, text, flags=re.I)
    return text.replace(term, expansion)


def _english_expansion(question: str) -> str:
    q = (question or "").casefold()
    additions: list[str] = []
    for term, expansion in sorted(BILINGUAL_QUERY_TERMS.items(), key=lambda x: len(x[0]), reverse=True):
        if _has_term(q, term):
            n = 3 if len(term.split()) > 1 else 2
            additions.append(" ".join(expansion.split()[:n]))
    for term, expansion in sorted(EN_QUERY_SYNONYMS.items(), key=lambda x: len(x[0]), reverse=True):
        if _has_term(q, term):
            additions.append(" ".join(expansion.split()[:4]))
    return " ".join(dict.fromkeys(additions))


def build_query_variants(question: str) -> list[str]:
    """Build focused, context-aware retrieval variants without substring rewrites.

    The original query is always retained. Expansions are separate variants so
    they can improve recall without diluting the original query's term coverage.
    They are hints for locating source text, not evidence or generated answers.
    """
    q = (question or "").strip()[:3_000]
    if not q:
        return []
    lower = unicodedata.normalize("NFKC", q).casefold()
    variants = [q]

    for term, expansion in sorted(HINDI_SYNONYMS.items(), key=lambda x: len(x[0]), reverse=True):
        if _has_term(lower, term):
            variants.append(expansion)

    english = _english_expansion(q)
    if english:
        variants.append(english)

    for term, expansion in sorted(QUERY_EXPANSIONS.items(), key=lambda x: len(x[0]), reverse=True):
        if _has_term(lower, term):
            variants.append(expansion)

    # Handle common, genuinely distinct citizen vocabulary. These exact phrase
    # rewrites avoid the former substring bug (e.g. "son" inside "personal").
    rewritten = q
    replacements = 0
    for term, expansion in sorted(EN_QUERY_SYNONYMS.items(), key=lambda x: len(x[0]), reverse=True):
        if _has_term(rewritten, term):
            updated = _replace_term(rewritten, term, expansion)
            if updated != rewritten:
                rewritten = updated
                replacements += 1
    if replacements:
        variants.append(rewritten)

    return list(dict.fromkeys(x.strip() for x in variants if x.strip()))[:16]

def expand_bilingual_query(question: str) -> str:
    """Compatibility helper returning focused cross-language topic terms.

    It deliberately favours the bilingual lexicon over every incidental word in
    the query, so a phrase like "crop insurance documents" does not become a
    noisy bag of unrelated certificate/passbook terms.
    """
    q = (question or "").strip()
    focused = []
    for term, expansion in sorted(BILINGUAL_QUERY_TERMS.items(), key=lambda x: len(x[0]), reverse=True):
        if _has_term(q.casefold(), term):
            focused.append(" ".join(expansion.split()[:2]))
    for term, expansion in sorted(EN_QUERY_SYNONYMS.items(), key=lambda x: len(x[0]), reverse=True):
        if term in {"scholarship", "papers", "college funding", "family income", "income limit", "crop loss"} and _has_term(q.casefold(), term):
            focused.append(" ".join(expansion.split()[:3]))
    if focused:
        return " ".join(dict.fromkeys(focused))
    english = _english_expansion(q)
    if english:
        return english
    variants = build_query_variants(q)
    return variants[-1] if len(variants) > 1 else q


def detect_language(question: str, requested: str = "auto") -> str:
    if requested in ("en", "hi"):
        return requested
    q = (question or "").lower()
    if re.search(r"[\u0900-\u097f]", q) or any(x in q for x in HI_MARKERS):
        return "hi"
    words = set(re.findall(r"[a-z]+", q))
    if len(words & HINGLISH_MARKERS) >= 2 or any(x in q for x in HINGLISH_MARKERS if " " in x):
        return "hi"
    return "en"


def detect_intent(question: str) -> str:
    q = (question or "").lower()
    if any(x in q for x in ("amendment", "amended", "changed", "change", "latest version", "old version", "संशोधन", "बदलाव")):
        return "policy_change"
    if any(x in q for x in ("eligible", "eligibility", "qualify", "can i get", "can i apply", "पात्र", "योग्य", "मिल सकता")):
        return "eligibility_question"
    if any(x in q for x in ("deadline", "last date", "closing date", "कब तक", "अंतिम तारीख")):
        return "deadline_question"
    if any(x in q for x in ("right", "entitlement", "obligation", "must", "may", "अधिकार", "जिम्मेदारी")):
        return "rights_and_obligations"
    if any(x in q for x in ("document", "certificate", "paper", "दस्तावेज", "कागज")):
        return "document_question"
    return "policy_question"


def _fallback_answer(question: str, language: str, evidence: list[dict[str, Any]], model_issue: str | None) -> str:
    if language == "hi":
        heading = "आपके सवाल से जुड़े दस्तावेज़ के हिस्से"
        note = "अभी सरल हिंदी में AI व्याख्या उपलब्ध नहीं है। नीचे स्रोत का मूल पाठ दिया गया है।" if model_issue else "नीचे आधिकारिक स्रोत से मिले संबंधित अंश हैं।"
        unknown = "इस जानकारी से अकेले अंतिम पात्रता या कानूनी स्थिति तय नहीं की जा सकती।"
    else:
        heading = "Relevant passages from the retrieved documents"
        note = "Plain-language AI explanation is not available right now. The source text is shown below." if model_issue else "These are the passages retrieved for your question."
        unknown = "These passages alone may not establish final eligibility or current legal effect."
    parts = [f"**{heading}**\n{note}"]
    for row in evidence[:5]:
        text = (row.get("text") or "").strip()
        if len(text) > 850:
            text = text[:850].rsplit(" ", 1)[0] + "…"
        citation = f"[{row.get('evidence_id')}]"
        parts.append(f"- **{row.get('title')} — {row.get('section') or 'Document text'}**: {text} {citation}")
    parts.append(f"**What is not confirmed**\n{unknown}")
    return "\n\n".join(parts)


def _retrieval_strength(evidence: list[dict[str, Any]]) -> str:
    """Describe lexical retrieval match only; this is not answer correctness."""
    if not evidence:
        return "insufficient"
    top = evidence[0].get("score", 0)
    # Retrieval already applies a minimum score gate (currently 0.42).
    # Do not label every admitted result "strong". These bands are descriptive
    # heuristics, not calibrated probabilities or answer-confidence values.
    if top >= 0.72:
        return "strong"
    if top >= 0.42:
        return "moderate"
    return "weak"


def _potential_conflicts(evidence: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Flag comparable cross-source numeric differences without declaring legal conflict."""
    rows = []
    for item in evidence:
        text = item.get("text", "") or ""
        # Typed values avoid comparing an age with a rupee amount. RAW numbers are
        # intentionally ignored because their units are not established.
        numeric = {fact for fact in _numeric_facts(text) if fact[0] in {
            "INR", "PERCENT", "DAYS", "WEEKS", "MONTHS", "YEARS"
        }}
        concepts = {x for x in _concepts(text) if not x.startswith("num:") and len(x) >= 3}
        concepts -= STOPWORDS
        concepts -= {"must", "shall", "may", "will", "should", "only", "more", "less", "than",
                     "all", "every", "any", "can", "could", "need", "required", "require",
                     "apply", "applies", "according", "under", "from", "into", "with", "without",
                     "this", "that", "rule", "rules", "source", "document"}
        rows.append((item, numeric, concepts))
    out = []
    seen_pairs: set[tuple[str, str]] = set()
    for i, (a, nums_a, terms_a) in enumerate(rows):
        for b, nums_b, terms_b in rows[i + 1:]:
            if a.get("document_id") == b.get("document_id") or not nums_a or not nums_b:
                continue
            shared = terms_a & terms_b
            union = terms_a | terms_b
            # Compare only like units; an age of 18 and a grant of INR 18,000
            # are not competing values. Require multiple shared concepts to
            # reduce false flags from a generic word such as "income".
            common_units = {unit for unit, _ in nums_a} & {unit for unit, _ in nums_b}
            comparable_a = {fact for fact in nums_a if fact[0] in common_units}
            comparable_b = {fact for fact in nums_b if fact[0] in common_units}
            overlap = len(shared) / max(1, len(union))
            if len(shared) < 2 or overlap < 0.18 or not common_units or comparable_a == comparable_b:
                continue
            left_id, right_id = str(a.get("evidence_id")), str(b.get("evidence_id"))
            pair = tuple(sorted((left_id, right_id)))
            if pair in seen_pairs:
                continue
            seen_pairs.add(pair)
            out.append({
                "type": "POTENTIAL_NUMERIC_DIFFERENCE",
                "evidence_ids": [a.get("evidence_id"), b.get("evidence_id")],
                "shared_concepts": sorted(shared)[:8],
                "left_title": a.get("title"), "right_title": b.get("title"),
                "left_authority_status": a.get("authority_status"),
                "right_authority_status": b.get("authority_status"),
                "left_numeric_facts": sorted(comparable_a), "right_numeric_facts": sorted(comparable_b),
                "message": (
                    "Two different source passages share policy concepts but contain different typed numeric facts. "
                    "This is a review flag only: the sources may concern different dates, categories, jurisdictions, "
                    "versions or provisions. Do not choose a governing value without checking the full official documents."
                ),
            })
            if len(out) >= 5:
                return out
    return out


def _question_facets(question: str) -> list[str]:
    """Create bounded, topic-specific retrieval facets for compound questions.

    These are retrieval hints only. They never become answer facts. Facets are
    emitted only when the corresponding topic is explicitly present in the query.
    """
    q = unicodedata.normalize("NFKC", question or "").casefold()
    facets: list[str] = []
    patterns = [
        (r"eligib|पात्रता|पात्र|योग्यता", "eligibility conditions eligible applicants qualifying criteria पात्रता शर्तें"),
        (r"income|कमाई|आय|आमदनी", "annual family household parental income threshold income ceiling वार्षिक पारिवारिक आय सीमा"),
        (r"document|certificate|paper|कागजात|दस्तावेज|प्रमाणपत्र", "required documents certificates records upload submit दस्तावेज प्रमाणपत्र"),
        (r"deadline|last date|due date|कब तक|अंतिम तिथि|आखिरी तारीख", "application deadline last date submission closing date अंतिम तिथि आवेदन"),
        (r"benefit|assistance|amount|loan|लाभ|सहायता|राशि|ऋण|कर्ज", "benefit assistance financial amount loan instalment लाभ सहायता राशि ऋण किस्त"),
        (r"penalt|fine|punish|दंड|जुर्माना|सजा", "penalty fine offence punishment दंड जुर्माना"),
        (r"authority|department|office|किस विभाग|कार्यालय|प्राधिकरण", "responsible authority department office implementing agency विभाग प्राधिकरण"),
        (r"exception|exempt|छूट|अपवाद", "exceptions exemption waiver excluded category अपवाद छूट"),
    ]
    for pattern, facet in patterns:
        if re.search(pattern, q, re.I):
            facets.append(facet)
    return list(dict.fromkeys(facets))[:8]


def build_response(
    question: str,
    requested_language: str = "auto",
    profile: dict | None = None,
    use_llm: bool = True,
    require_live_sources: bool = False,
    document_id: str | None = None,
    document_ids: list[str] | None = None,
) -> dict[str, Any]:
    profile = profile or {}
    language = detect_language(question, requested_language)
    intent = detect_intent(question)
    workflow: list[dict[str, Any]] = []

    workflow.append({"step": "parse_request", "status": "completed", "detail": f"Language={language}; request type={intent}."})
    freshness = "LIVE" if require_live_sources else None
    variants = build_query_variants(question)
    explicit_document_ids = list(dict.fromkeys(document_ids or ([document_id] if document_id else [])))
    facets = _question_facets(question)
    query_specs = [(question, variants)] + [(facet, build_query_variants(facet)) for facet in facets]
    candidates: dict[str, dict[str, Any]] = {}
    search_documents = explicit_document_ids or [None]
    for selected_id in search_documents:
        for facet_question, facet_variants in query_specs:
            rows = retrieve(facet_question, k=10, freshness=freshness,
                            document_id=selected_id, query_variants=facet_variants,
                            question_context=question)
            for row in rows:
                row_id = row.get("evidence_id")
                if not row_id:
                    continue
                previous = candidates.get(row_id)
                if previous is None or float(row.get("score", 0)) > float(previous.get("score", 0)):
                    item = dict(row)
                    item["query_facet"] = facet_question if facet_question != question else "original_question"
                    candidates[row_id] = item
    evidence = sorted(candidates.values(), key=lambda x: (float(x.get("score", 0)), x.get("freshness") == "LIVE"), reverse=True)
    workflow.append({"step": "tool_search_evidence", "status": "completed", "detail": f"Retrieved {len(evidence)} distinct passages across {len(search_documents)} explicitly selected document(s), using BM25 and {len(query_specs)} question facets."})

    # A selected-document change-history request is about comparing stored
    # versions, not finding a passage that repeats the words "what changed".
    # When lexical retrieval has no match, provide bounded document context for
    # the version diff and mark it as a history-context fallback, not a match.
    history_document_id = document_id or (explicit_document_ids[0] if len(explicit_document_ids) == 1 else None)
    if not evidence and intent == "policy_change" and history_document_id:
        history_context = get_all_evidence(freshness=freshness, document_id=history_document_id)
        evidence = []
        for row in history_context[:8]:
            item = dict(row)
            item.update({
                "score": 0.0,
                "query_coverage": 0.0,
                "matched_terms": [],
                "matched_term_count": 0,
                "retrieval_method": "selected_document_version_history_context",
                "retrieval_variant": "",
            })
            evidence.append(item)
        if evidence:
            workflow.append({"step": "selected_document_history_context", "status": "completed",
                             "detail": "No lexical match for the change question; loaded selected-document passages only to accompany the stored version history. This is context, not a relevance score."})

    evidence = evidence[:12]
    if require_live_sources:
        evidence = [x for x in evidence if x.get("freshness") == "LIVE"]
    if explicit_document_ids:
        evidence = [x for x in evidence if x.get("document_id") in set(explicit_document_ids)]

    if not evidence:
        answer = (
            "इस सवाल का जवाब देने के लिए संबंधित स्रोत नहीं मिला। कृपया सही सरकारी PDF/URL जोड़ें या सवाल को थोड़ा स्पष्ट करें।"
            if language == "hi" else
            "I could not find a sufficiently relevant source passage for this question. Add the official policy PDF/URL or make the question more specific. I will not guess."
        )
        workflow.append({"step": "evidence_gate", "status": "abstained", "detail": "No relevant evidence passed the minimum retrieval threshold."})
        return {"answer": answer, "language": language, "intent": intent, "evidence": [], "citations": [],
                "retrieval_strength": "insufficient", "status_note": "No sufficiently relevant source evidence was retrieved.",
                "workflow": workflow, "tool_calls": [x["step"] for x in workflow if x["step"].startswith("tool_")],
                "llm_used": False, "source_mode": "live_required" if require_live_sources else "retrieved_sources",
                "potential_conflicts": [], "versions": [],
                "selected_document_ids": explicit_document_ids, "answer_language": language}

    workflow.append({"step": "evidence_gate", "status": "completed", "detail": f"{len(evidence)} source passages passed relevance retrieval; provenance labels retained."})
    possible_conflicts = _potential_conflicts(evidence)
    workflow.append({"step": "tool_check_source_differences", "status": "completed", "detail": f"Flagged {len(possible_conflicts)} possible numeric source differences; no legal conflict is inferred."})

    versions = []
    doc_ids = list(dict.fromkeys(x.get("document_id") for x in evidence))
    if intent == "policy_change":
        for doc_id in doc_ids[:4]:
            versions.extend(get_document_versions(doc_id, limit=5))
        workflow.append({"step": "tool_compare_document_versions", "status": "completed", "detail": f"Loaded {len(versions)} stored document-version records."})

    answer_payload = None
    llm_used = False
    model_issue = None
    if use_llm:
        workflow.append({"step": "tool_generate_grounded_explanation", "status": "started", "detail": "Sending ranked source passages to the configured LLM with exact-quote requirements. Profile values remain local."})
        try:
            answer_payload = synthesize_grounded(question, language, evidence, profile)
            llm_used = True
            if answer_payload.get("validation_attempts", 1) > 1:
                workflow.append({"step": "tool_self_correction", "status": "completed", "detail": "The first generated draft failed deterministic citation/number checks; one bounded correction pass was run."})
            workflow.append({"step": "tool_verify_claims_and_citations", "status": "completed", "detail": "Cited quote presence and numeric consistency passed deterministic checks. Semantic entailment is not formally proven."})
        except (LLMUnavailable, GroundingError) as exc:
            model_issue = str(exc)
            workflow.append({"step": "tool_verify_claims_and_citations", "status": "failed", "detail": f"Grounded generation unavailable or failed verification: {type(exc).__name__}."})

    if answer_payload:
        summary_ids = answer_payload["summary_evidence_ids"]
        answer = f"**In simple words**\n{answer_payload['simple_answer']} " + " ".join(f"[{x}]" for x in summary_ids)
        if answer_payload["claims"]:
            answer += "\n\n**What the source says**\n" + "\n".join(
                f"- {claim['text']} " + " ".join(f"[{x}]" for x in claim["evidence_ids"])
                for claim in answer_payload["claims"]
            )
        if answer_payload["unknowns"]:
            answer += "\n\n**What is not confirmed**\n" + "\n".join(f"- {x}" for x in answer_payload["unknowns"])
        if answer_payload["next_steps"]:
            answer += "\n\n**Next steps supported by the source**\n" + "\n".join(
                f"- {item['text']} " + " ".join(f"[{x}]" for x in item["evidence_ids"])
                for item in answer_payload["next_steps"]
            )
        cited_ids = list(dict.fromkeys(
            summary_ids
            + [i for c in answer_payload["claims"] for i in c["evidence_ids"]]
            + [i for step in answer_payload["next_steps"] for i in step["evidence_ids"]]
        ))
        grounded = True
    else:
        answer = _fallback_answer(question, language, evidence, model_issue)
        if intent == "policy_change" and versions:
            history_lines = []
            for version in versions[:5]:
                kind = str(version.get("change_kind") or "UNKNOWN")
                summary = str(version.get("change_summary") or "No section summary available.")
                history_lines.append(f"- Version {version.get('version_number', '?')} — {kind}: {summary}")
            heading = "Stored version history (text changes require human review; this does not determine which legal rule governs):"
            if language == "hi":
                heading = "सहेजा गया संस्करण इतिहास (पाठ में बदलाव की मानवीय समीक्षा आवश्यक है; इससे यह तय नहीं होता कि कौन-सा कानूनी नियम लागू है):"
            answer = heading + "\n" + "\n".join(history_lines) + "\n\n" + answer
        cited_ids = [x.get("evidence_id") for x in evidence[:5]]
        grounded = False
        workflow.append({"step": "tool_extractive_fallback", "status": "completed", "detail": "Returned exact source passages rather than inventing a paraphrase because grounded LLM output was unavailable."})

    evidence_by_id = {x["evidence_id"]: x for x in evidence}
    citations = []
    for evidence_id in cited_ids:
        item = evidence_by_id.get(evidence_id)
        if not item:
            continue
        citations.append({
            "evidence_id": evidence_id, "document_id": item.get("document_id"),
            "title": item.get("title"), "page_title": item.get("title"),
            "section": item.get("section"), "page": item.get("page"),
            "source_url": item.get("source_url"),
            "quote": item.get("text", ""),
            "provenance": item.get("provenance"),
            "authority_status": item.get("authority_status"), "freshness": item.get("freshness"),
        })
    retrieval_strength = _retrieval_strength(evidence)
    authority_notes = sorted(set(x.get("authority_status", "UNVERIFIED") for x in evidence))
    provenance_notes = sorted(set(x.get("freshness", "UNKNOWN") for x in evidence))
    status_note = ("Citations were checked for exact quote presence and deterministic numeric/date/policy checks; this is not a formal proof that every paraphrase is legally entailed. Review the original passage." if llm_used else "Only source passages are shown; a plain-language model explanation was not produced.")
    if answer_payload and answer_payload.get("rejected_claims"):
        status_note += f" {len(answer_payload['rejected_claims'])} model claim(s) were omitted because they did not pass evidence validation."
    if answer_payload and answer_payload.get("redacted_identifier_types"):
        status_note += " Some personal identifiers were redacted before the external AI request."
    if answer_payload and answer_payload.get("prompt_injection_evidence_ids"):
        status_note += " One or more source passages contained instruction-like text; those passages were treated as untrusted document data."
    if any(x == "USER_UPLOADED_PUBLISHER_UNVERIFIED" for x in authority_notes):
        status_note += " At least one source was user-uploaded and its publisher was not independently verified."
    if any("little extractable text" in str(x.get("extraction_note") or "").lower() for x in evidence):
        status_note += " Some PDF pages contain little extractable text; OCR is not configured, so check those pages in the original PDF."
    workflow.append({"step": "render_answer", "status": "completed", "detail": f"Returned {len(citations)} evidence references; retrieval_strength={retrieval_strength}."})
    return {
        "answer": answer, "language": language, "intent": intent,
        "evidence": evidence, "citations": citations, "retrieval_strength": retrieval_strength,
        "status_note": status_note, "workflow": workflow,
        "tool_calls": [x["step"] for x in workflow if x["step"].startswith("tool_")],
        "llm_used": llm_used,
        "grounding_warnings": (answer_payload or {}).get("rejected_claims", []),
        "prompt_injection_evidence_ids": (answer_payload or {}).get("prompt_injection_evidence_ids", []),
        "redacted_identifier_types": (answer_payload or {}).get("redacted_identifier_types", []),
        "source_mode": "live_required" if require_live_sources else "retrieved_sources",
        "selected_document_ids": explicit_document_ids,
        "answer_language": language,
        "authority_statuses": authority_notes, "freshness_statuses": provenance_notes,
        "potential_conflicts": possible_conflicts, "versions": versions,
    }
