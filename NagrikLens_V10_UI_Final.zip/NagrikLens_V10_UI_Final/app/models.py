from __future__ import annotations

import json
import math
from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator

from .config import MAX_PROFILE_BYTES, MAX_QUESTION_CHARS


def _validate_profile(value: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ValueError("Profile must be a JSON object.")
    try:
        encoded = json.dumps(value, ensure_ascii=False, allow_nan=False)
    except (TypeError, ValueError) as exc:
        raise ValueError("Profile must contain valid JSON values and finite numbers.") from exc
    if len(value) > 30 or len(encoded) > MAX_PROFILE_BYTES:
        raise ValueError("Profile must contain at most 30 fields and 8 KB.")
    for key, val in value.items():
        if not isinstance(key, str) or not key.strip() or len(key) > 80:
            raise ValueError("Profile field names must be non-empty strings under 80 characters.")
        if isinstance(val, float) and not math.isfinite(val):
            raise ValueError("Profile numbers must be finite.")
        if isinstance(val, list):
            if len(val) > 50 or any(
                not isinstance(item, (str, int, float, bool, type(None)))
                or (isinstance(item, float) and not math.isfinite(item))
                for item in val
            ):
                raise ValueError("Profile lists may contain at most 50 simple, finite values.")
        elif not isinstance(val, (str, int, float, bool, type(None))):
            raise ValueError("Profile values must be simple scalar values or lists of simple values.")
        if isinstance(val, str) and len(val) > 1_000:
            raise ValueError("Individual profile text values must be under 1,000 characters.")
    return value


class QueryRequest(BaseModel):
    question: str = Field(min_length=3, max_length=MAX_QUESTION_CHARS)
    # Legacy field retained for V9 clients.
    language: Literal["auto", "en", "hi"] = "auto"
    # Explicit answer language always takes precedence over detected question language.
    answer_language: Literal["same_as_question", "en", "hi"] = "same_as_question"
    profile: dict[str, Any] = Field(default_factory=dict)
    use_llm: bool = True
    require_live_sources: bool = False
    document_id: str | None = Field(default=None, max_length=80)
    document_ids: list[str] = Field(default_factory=list, max_length=10)
    session_id: str | None = Field(default=None, min_length=16, max_length=80)

    @field_validator("document_ids")
    @classmethod
    def unique_document_ids(cls, value: list[str]) -> list[str]:
        cleaned = list(dict.fromkeys(x.strip() for x in value if isinstance(x, str) and x.strip()))
        if len(cleaned) > 10:
            raise ValueError("At most 10 documents may be explicitly selected.")
        return cleaned

    @field_validator("profile")
    @classmethod
    def profile_size(cls, value: dict[str, Any]) -> dict[str, Any]:
        return _validate_profile(value)


class IngestURLRequest(BaseModel):
    url: str = Field(min_length=12, max_length=2048)
    title: str | None = Field(default=None, max_length=240)
    jurisdiction: str = Field(default="India", max_length=100)
    include_linked_pdfs: bool = False
    max_linked_pdfs: int = Field(default=3, ge=0, le=5)
    page_mode: Literal["max_page", "specific", "all"] = "max_page"
    max_page_number: int | None = Field(default=None, ge=1, le=2000)
    selected_pages: list[int] = Field(default_factory=list, max_length=2000)


class AnalyseRequest(BaseModel):
    language: Literal["en", "hi"] = "en"


class EligibilityRequest(BaseModel):
    profile: dict[str, Any] = Field(default_factory=dict)
    answer_language: Literal["en", "hi"] = "en"

    @field_validator("profile")
    @classmethod
    def profile_size(cls, value: dict[str, Any]) -> dict[str, Any]:
        return _validate_profile(value)


class QueryResponse(BaseModel):
    answer: str
    language: str
    intent: str
    evidence: list[dict[str, Any]]
    citations: list[dict[str, Any]] = Field(default_factory=list)
    retrieval_strength: Literal["strong", "moderate", "weak", "insufficient"]
    status_note: str | None = None
    workflow: list[dict[str, Any]]
    tool_calls: list[str] = Field(default_factory=list)
    llm_used: bool = False
    source_mode: str
    selected_document_ids: list[str] = Field(default_factory=list)
    answer_language: str = "en"
    potential_conflicts: list[dict[str, Any]] = Field(default_factory=list)
    versions: list[dict[str, Any]] = Field(default_factory=list)
    grounding_warnings: list[dict[str, Any]] = Field(default_factory=list)
    prompt_injection_evidence_ids: list[str] = Field(default_factory=list)
    redacted_identifier_types: list[str] = Field(default_factory=list)
    authority_statuses: list[str] = Field(default_factory=list)
    freshness_statuses: list[str] = Field(default_factory=list)


class AdminSourceRequest(BaseModel):
    hostname: str = Field(min_length=3, max_length=253)
    authority: str = Field(default="", max_length=200)
    verification_status: str = Field(default="ADMIN_APPROVED_HOST_DOCUMENT_NOT_AUTHENTICATED", max_length=120)


class AdminRejectSourceRequest(BaseModel):
    hostname: str = Field(min_length=3, max_length=253)
    reason: str = Field(default="REJECTED_BY_ADMINISTRATOR", max_length=120)
