from __future__ import annotations

import pytest

from app import store
from app.ingestion import _split_page_text
from app.llm import GroundingError, validate_grounded_payload
from app.policy import build_query_variants
from app.retrieval import retrieve
from app.rules import evaluate_conditions


@pytest.fixture(autouse=True)
def isolated_db(tmp_path, monkeypatch):
    monkeypatch.setattr(store, "DB_FILE", tmp_path / "v09.sqlite3")
    store.init_db()


def add_doc(document_id: str, title: str, text: str) -> None:
    store.upsert_document({
        "document_id": document_id,
        "title": title,
        "source_url": f"https://synthetic.test/{document_id}",
        "canonical_url": "",
        "jurisdiction": "Synthetic test only",
        "issuing_authority": "synthetic.test",
        "authority_status": "OFFICIAL_DOMAIN_NOT_DOCUMENT_AUTHENTICATED",
        "provenance": "HTTP_FETCH",
        "freshness": "LIVE",
        "retrieved_at": store.utcnow(),
        "document_date": None,
        "content_type": "application/pdf",
        "raw_text": text,
        "page_count": 1,
        "evidence": _split_page_text(text, 1),
    })


def validate_claim(claim: str, quote: str) -> None:
    evidence = [{"evidence_id": "doc::p1-c0", "text": quote}]
    payload = {
        "simple_answer": claim,
        "summary_evidence": [{"evidence_id": "doc::p1-c0", "quote": quote}],
        "claims": [{"text": claim, "evidence": [{"evidence_id": "doc::p1-c0", "quote": quote}]}],
        "unknowns": [],
        "next_steps": [],
    }
    validate_grounded_payload(payload, evidence)


def test_v09_retrieves_held_out_citizen_wording_and_prefers_same_language():
    add_doc("housing", "Housing Grant Guideline", "Beneficiary households must not own a pucca house. Annual household earnings shall not exceed Rs 3,00,000. A grant of Rs 1,20,000 is released in three instalments. Applications to be submitted at the Block Development Office by 15 January 2027.")
    add_doc("cropint", "Crop Loan Interest Subvention", "Farmers availing short-term crop loans up to Rs 3 lakh receive interest subvention of 2% per annum. An additional 3% prompt repayment incentive applies. Kisan Credit Card holders are eligible.")
    add_doc("maternity", "Maternity Assistance", "Pregnant women aged 19 years or above are eligible for cash assistance of Rs 5,000 in two instalments for the first living child. Registration at the Anganwadi centre must be completed within 150 days.")
    add_doc("tradelic", "Trade Licence Rules", "Every shopkeeper shall obtain a trade licence from the municipal corporation before commencing business. Licence fee is Rs 500 annually. Renewal must be applied for 30 days before expiry. Operating without a licence attracts a fine up to Rs 5,000.")
    add_doc("scholar", "Post-Matric Scholarship Guideline", "Parental income must not exceed Rs 2.5 lakh per annum. Applicants must upload caste certificate, income certificate and bank passbook. Last date for applications is 31 October.")
    add_doc("hi-trade", "दुकान लाइसेंस नियम", "प्रत्येक दुकानदार को व्यापार शुरू करने से पहले नगर निगम से लाइसेंस लेना होगा। वार्षिक शुल्क 500 रुपये है। लाइसेंस समाप्त होने से 30 दिन पहले नवीकरण आवेदन करें।")
    add_doc("hi-mat", "मातृत्व सहायता", "गर्भवती महिलाओं को पहले जीवित बच्चे के लिए 5,000 रुपये की नकद सहायता दो किस्तों में दी जाएगी। आंगनवाड़ी केंद्र में 150 दिन के भीतर पंजीकरण करें।")

    cases = [
        ("I own a small tea stall. Do I need permission from the city before opening?", "tradelic"),
        ("How much money will I get for building a house?", "housing"),
        ("Is my wife eligible for pregnancy money if she is 18?", "maternity"),
        ("What happens if I run my shop without a licence?", "tradelic"),
        ("When do I have to renew my licence?", "tradelic"),
        ("Is there an interest discount on crop loans?", "cropint"),
        ("Which papers do I need for the scholarship application?", "scholar"),
        ("What is the last date for the housing grant application?", "housing"),
        ("दुकान चलाने के लिए लाइसेंस कहाँ से लेना है", "hi-trade"),
        ("गर्भवती महिला को कितने रुपये मिलते हैं", "hi-mat"),
        ("मेरी बेटी गर्भवती है, उसे कितनी मदद मिलेगी", "maternity"),
        ("dukaan ka license renew kab karna hai", "tradelic"),
    ]
    for question, expected in cases:
        results = retrieve(question, query_variants=build_query_variants(question), k=5)
        assert results, question
        assert results[0]["document_id"] == expected, (question, [(x["document_id"], x["score"]) for x in results])


def test_v09_abstains_on_unrelated_questions_and_driving_vs_trade_licence():
    add_doc("tradelic", "Trade Licence Rules", "Every shopkeeper shall obtain a trade licence from the municipal corporation before commencing business. Licence fee is Rs 500 annually. Renewal must be applied for 30 days before expiry.")
    add_doc("scholar", "Scholarship Guideline", "Student scholarship eligibility depends on annual family income and domicile. Applicants upload income certificate and bank passbook.")
    unsupported = [
        "How do I get a passport?", "What is the minimum wage in Bihar?", "Can I withdraw my PF?",
        "Who won the cricket match yesterday?", "Is my personal data safe on this app?",
        "What is the reason for the delay in my refund?", "How do I file my income tax return?",
        "What are the rules for driving licence renewal?", "How do I get a home loan from a bank?",
        "What is the penalty for tax evasion?", "पासपोर्ट कैसे बनवाएं?", "बिजली का बिल कैसे जमा करें",
    ]
    for question in unsupported:
        assert retrieve(question, query_variants=build_query_variants(question)) == [], question


def test_expansion_uses_word_boundaries_and_does_not_corrupt_ordinary_words():
    for question in ("Is my personal data safe?", "What is the reason for the delay?", "Who is the person to contact?", "What is the season for sowing?"):
        variants = build_query_variants(question)
        assert not any("student" in variant.casefold() for variant in variants), (question, variants)
        assert all("perstudental" not in variant and "reastudent" not in variant for variant in variants)


def test_selected_document_answers_natural_income_and_document_questions():
    add_doc("scholar", "Scholarship Guideline", "Parental income must not exceed Rs 2.5 lakh per annum. Applicants must upload caste certificate, income certificate and bank passbook.")
    for question in ("What is the income limit?", "What is the income limit for this scheme?", "What documents are required?"):
        assert retrieve(question, document_id="scholar", query_variants=build_query_variants(question)), question


def test_grounding_rejects_number_word_ordinal_deadline_office_modality_and_frequency_changes():
    maternity = "Pregnant women aged 19 years or above are eligible for cash assistance of Rs 5,000 in two instalments for the first living child. Registration at the Anganwadi centre must be completed within 150 days."
    for wrong in (
        "Pregnant women aged 19 years or above get Rs 5,000 in three instalments for the first living child.",
        "Pregnant women aged 19 years or above get Rs 5,000 in two instalments for the second living child.",
        "Pregnant women aged 19 years or above can register at the district hospital within 150 days.",
        "Registration at the Anganwadi centre can be completed within one year.",
    ):
        with pytest.raises(GroundingError):
            validate_claim(wrong, maternity)

    trade = "Every shopkeeper shall obtain a trade licence from the municipal corporation before commencing business. Licence fee is Rs 500 annually."
    for wrong in (
        "A shopkeeper may obtain a trade licence from the municipal corporation if they wish.",
        "Every shopkeeper shall obtain a trade licence from the police before commencing business.",
        "The licence fee is Rs 500 as a one-time payment.",
        "The licence fee is Rs 500 every month.",
    ):
        with pytest.raises(GroundingError):
            validate_claim(wrong, trade)


def test_grounding_accepts_faithful_paraphrases_with_words_and_frequency():
    maternity = "Pregnant women aged 19 years or above are eligible for cash assistance of Rs 5,000 in two instalments for the first living child."
    validate_claim("Pregnant women who are 19 years or older can receive Rs 5,000 in two parts for the first child.", maternity)
    trade = "Licence fee is Rs 500 annually."
    validate_claim("You pay a licence fee of Rs 500 each year.", trade)


def test_grounding_still_rejects_an_unrelated_entitlement_claim():
    quote = "Annual family income of the applicant must not exceed Rs. 2,50,000 per annum."
    with pytest.raises(GroundingError):
        validate_claim("The applicant receives a free laptop every year.", quote)


def test_eligibility_result_restores_scalar_fields_and_exposes_compound_leaves():
    simple = evaluate_conditions([
        {"text": "Income <= 2.5 lakh", "profile_field": "annual_family_income", "operator": "lte", "expected_value": 250000, "unit": "INR", "evidence_id": "E1"}
    ], {"annual_family_income": 200000})
    condition = simple["conditions"][0]
    assert condition["your_value"] == 200000
    assert condition["expected_value"] == 250000
    assert condition["profile_field"] == "annual_family_income"

    compound = evaluate_conditions([{
        "text": "Age and income requirements",
        "expression": {"logic": "all", "conditions": [
            {"profile_field": "age", "operator": "gte", "expected_value": 18, "unit": "years"},
            {"profile_field": "annual_family_income", "operator": "lte", "expected_value": 250000, "unit": "INR"},
        ]},
    }], {"age": 20, "annual_family_income": 200000})
    leaves = compound["conditions"][0]["leaf_results"]
    assert len(leaves) == 2
    assert {x["profile_field"] for x in leaves} == {"age", "annual_family_income"}
    assert {x["status"] for x in leaves} == {"MET"}


def test_new_scholarship_profile_fields_are_supported_and_compare_correctly():
    from app.llm import _field_supported_in_quote

    assert _field_supported_in_quote("marks_percent", "Applicants must obtain at least 60 percent marks.")
    assert _field_supported_in_quote("course_year", "Students in the second year of study may apply.")
    assert _field_supported_in_quote("minority_status", "Applicants from a notified minority community are eligible.")
    assert _field_supported_in_quote("residence_state", "The applicant must be domiciled in Bihar.")
    assert _field_supported_in_quote("institution_state", "The college is located in Bihar.")

    result = evaluate_conditions([
        {"text": "Marks >= 60%", "profile_field": "marks_percent", "operator": "gte", "expected_value": 60, "unit": "percent", "evidence_id": "E1"},
        {"text": "Residence state = Bihar", "profile_field": "residence_state", "operator": "eq", "expected_value": "Bihar", "unit": "", "evidence_id": "E2"},
    ], {"marks_percent": 78.5, "residence_state": "बिहार"})
    assert [x["status"] for x in result["conditions"]] == ["MET", "MET"]


def test_optional_shared_api_key_gates_api_but_keeps_health_public(monkeypatch):
    from fastapi.testclient import TestClient
    from app import main

    monkeypatch.setattr(main, "API_ACCESS_KEY", "demo-secret")
    with TestClient(main.app) as client:
        assert client.get("/api/health").status_code == 200
        assert client.get("/api/documents").status_code == 401
        response = client.get("/api/documents", headers={"X-Nagriklens-API-Key": "demo-secret"})
        assert response.status_code == 200


def test_health_does_not_claim_seed_data_was_loaded():
    from fastapi.testclient import TestClient
    from app import main

    with TestClient(main.app) as client:
        payload = client.get("/api/health").json()
    assert "startup_seed_data_loaded" not in payload


def test_api_pdf_upload_then_query_end_to_end_without_external_llm():
    import fitz
    from fastapi.testclient import TestClient
    from app import main

    doc = fitz.open()
    page = doc.new_page()
    page.insert_text((72, 72), "Post-Matric Scholarship Guideline. Annual family income must not exceed Rs 2,50,000 per annum. Applicants must upload caste certificate and bank passbook.")
    pdf_bytes = doc.tobytes()
    doc.close()

    with TestClient(main.app) as client:
        home = client.get("/")
        assert home.status_code == 200
        assert "NagrikLens v0.9.0" in home.text
        upload = client.post("/api/documents/upload", files={"file": ("scholarship.pdf", pdf_bytes, "application/pdf")}, data={"jurisdiction": "India"})
        assert upload.status_code == 200, upload.text
        document_id = upload.json()["document_id"]
        query = client.post("/api/query", json={
            "question": "What is the annual family income limit?",
            "language": "en",
            "use_llm": False,
            "document_id": document_id,
        })
        assert query.status_code == 200, query.text
        result = query.json()
        assert result["evidence"]
        assert "2,50,000" in " ".join(x["text"] for x in result["evidence"])
        assert result["citations"]


def test_grounded_llm_request_uses_quotes_but_never_sends_citizen_profile(monkeypatch):
    import json
    from app import llm

    evidence = [{
        "evidence_id": "scholar::p1-c0",
        "document_id": "scholar",
        "title": "Synthetic Scholarship Guideline",
        "text": "Annual family income must not exceed Rs 2,50,000 per annum.",
        "page": 1,
    }]
    captured = {}

    def fake_completion(system: str, user: str):
        captured["payload"] = json.loads(user)
        quote = evidence[0]["text"]
        return {
            "simple_answer": "Annual family income must not exceed Rs 2,50,000 per annum.",
            "summary_evidence": [{"evidence_id": "scholar::p1-c0", "quote": quote}],
            "claims": [{"text": "Annual family income must not exceed Rs 2,50,000 per annum.", "evidence": [{"evidence_id": "scholar::p1-c0", "quote": quote}]}],
            "unknowns": [],
            "next_steps": [],
        }

    monkeypatch.setattr(llm, "_json_completion", fake_completion)
    result = llm.synthesize_grounded(
        "What is the family income limit?", "en", evidence,
        profile={"annual_family_income": 123456, "state": "Bihar"},
    )
    assert result["claims"]
    assert set(captured["payload"]) == {"question", "retrieved_sources"}
    assert "123456" not in json.dumps(captured["payload"])
    assert "Bihar" not in json.dumps(captured["payload"])


def test_course_year_ordinals_and_minority_profile_values_are_not_misread():
    from app.llm import _expected_value_supported_in_quote, _validate_condition_expression

    quote = "Applicants studying in the second year of the course may apply if they belong to a minority community."
    checked = _validate_condition_expression({
        "profile_field": "course_year", "operator": "eq", "expected_value": 2, "unit": "years"
    }, quote, {"course_year"}, {"eq", "unknown"})
    assert checked["operator"] == "eq"
    assert _expected_value_supported_in_quote("minority_status", "yes", quote)
    assert not _expected_value_supported_in_quote("minority_status", "no", quote)
    evaluated = evaluate_conditions([
        {"text": "Second-year requirement", "profile_field": "course_year", "operator": "eq", "expected_value": 2, "unit": "years"}
    ], {"course_year": "second year"})
    assert evaluated["conditions"][0]["status"] == "MET"


def test_may_month_does_not_trigger_optional_modality():
    from app.llm import _modality_markers

    assert "MANDATORY" in _modality_markers("Applications must be submitted by 31 May 2026.")
    assert "OPTIONAL" not in _modality_markers("Applications must be submitted by 31 May 2026.")
    assert "OPTIONAL" in _modality_markers("Eligible students may apply.")


def test_english_state_value_is_supported_by_hindi_domicile_quote():
    from app.llm import _expected_value_supported_in_quote

    assert _expected_value_supported_in_quote("residence_state", "Bihar", "आवेदक बिहार का निवासी होना चाहिए।")
    assert not _expected_value_supported_in_quote("residence_state", "Bihar", "आवेदक झारखंड का निवासी होना चाहिए।")


def test_may_month_date_forms_are_not_treated_as_optional_modal():
    from app.llm import _modality_markers

    for sentence in (
        "Applications must be submitted by 31 May 2026.",
        "Applications must be submitted by May 31, 2026.",
    ):
        assert "MANDATORY" in _modality_markers(sentence)
        assert "OPTIONAL" not in _modality_markers(sentence)


def test_same_language_preference_does_not_override_a_materially_higher_score():
    from app.retrieval import _score_one_variant
    # Ordering semantics are tested directly by the production sort key below
    # via two rows whose scores are controlled by a focused monkeypatch.
    from app import retrieval

    class FakeIndex:
        rows = [
            {"document_id": "same-language", "title": "Hindi", "section": "", "text": "income scholarship", "freshness": "LIVE"},
            {"document_id": "strong-cross-language", "title": "English", "section": "", "text": "income scholarship guideline", "freshness": "LIVE"},
        ]
        postings = {"income": [0, 1], "scholarship": [0, 1]}

    monkeypatch_index = FakeIndex()
    original_get_index = retrieval._get_index
    original_score = retrieval._score_one_variant
    try:
        retrieval._get_index = lambda: monkeypatch_index
        retrieval._score_one_variant = lambda tokens, idx, index: ((0.48, 0.6, 1.0, 1, ["income"]) if idx == 0 else (0.91, 1.0, 3.0, 3, ["income", "scholarship", "guideline"]))
        rows = retrieval.retrieve("छात्रवृत्ति आय", query_variants=["income scholarship"], k=2)
        assert rows[0]["document_id"] == "strong-cross-language"
    finally:
        retrieval._get_index = original_get_index
        retrieval._score_one_variant = original_score
