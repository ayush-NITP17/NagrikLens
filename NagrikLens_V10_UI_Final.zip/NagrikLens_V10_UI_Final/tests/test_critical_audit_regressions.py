from __future__ import annotations

import json

import pytest

from app import store
from app.ingestion import _split_page_text
from app.llm import (
    GroundingError,
    _comparison_direction,
    _extract_policy_batch,
    validate_grounded_payload,
)
from app.policy import build_query_variants, expand_bilingual_query
from app.retrieval import retrieve, tokens
from app.rules import _number, evaluate_conditions


@pytest.fixture(autouse=True)
def isolated_db(tmp_path, monkeypatch):
    monkeypatch.setattr(store, "DB_FILE", tmp_path / "critical-regressions.sqlite3")
    store.init_db()


def add_doc(document_id: str, title: str, text: str, *, page: int = 1) -> None:
    evidence = _split_page_text(text, page)
    store.upsert_document({
        "document_id": document_id,
        "title": title,
        "source_url": f"https://synthetic.test/{document_id}.pdf",
        "canonical_url": f"https://synthetic.test/{document_id}.pdf",
        "jurisdiction": "Test only",
        "issuing_authority": "synthetic.test",
        "authority_status": "OFFICIAL_DOMAIN_NOT_DOCUMENT_AUTHENTICATED",
        "provenance": "HTTP_FETCH",
        "freshness": "LIVE",
        "retrieved_at": store.utcnow(),
        "document_date": None,
        "content_type": "application/pdf",
        "raw_text": text,
        "page_count": 1,
        "evidence": evidence,
    })


def test_devanagari_tokenizer_preserves_combining_marks_and_words():
    assert "छात्रवृत्ति" in tokens("छात्रवृत्ति के लिए आय सीमा क्या है")
    assert "किसान" in tokens("किसान क्रेडिट कार्ड")
    assert "क्रेडिट" in tokens("किसान क्रेडिट कार्ड")
    assert "परिवार" in tokens("परिवार की वार्षिक आय")


def test_hindi_queries_retrieve_hindi_sources_for_six_citizen_phrasings():
    add_doc("hi-scholar", "छात्रवृत्ति", "छात्रवृत्ति के लिए आवेदक के माता-पिता की वार्षिक आय सीमा निर्धारित है। आवेदन की अंतिम तारीख घोषित की जाएगी। पात्र छात्रों को शैक्षणिक सत्र के लिए सहायता राशि दी जाएगी।")
    add_doc("hi-crop", "फसल बीमा", "फसल बीमा योजना में किसान को प्रीमियम जमा करना होगा। प्राकृतिक आपदा से फसल नुकसान होने पर दावा किया जा सकता है। बीमा दावा सत्तर घंटे के भीतर सूचित करें।")
    add_doc("hi-pension", "वृद्धावस्था पेंशन", "वृद्धावस्था पेंशन के लिए आवेदक की आयु साठ वर्ष से अधिक होनी चाहिए। पेंशन राशि प्रतिमाह बैंक खाते में भेजी जाएगी। आवेदन ग्राम पंचायत में जमा करें।")
    add_doc("hi-ration", "राशन कार्ड", "राशन कार्ड के लिए परिवार के सभी सदस्यों के नाम दर्ज होंगे। राशन दुकान से अनाज प्राप्त करने हेतु कार्ड आवश्यक है। पते में परिवर्तन होने पर सूचना दें।")
    cases = [
        ("छात्रवृत्ति के लिए आय सीमा क्या है", "hi-scholar"),
        ("फसल बीमा का दावा कितने समय में करना होगा", "hi-crop"),
        ("पेंशन के लिए उम्र कितनी होनी चाहिए", "hi-pension"),
        ("राशन कार्ड में पता बदलने पर क्या करें", "hi-ration"),
        ("मेरे दादाजी को बुढ़ापे में पैसा कैसे मिलेगा", "hi-pension"),
        ("अनाज की दुकान से सामान लेने के लिए क्या चाहिए", "hi-ration"),
    ]
    for question, expected in cases:
        results = retrieve(question, query_variants=build_query_variants(question), k=3)
        assert results and results[0]["document_id"] == expected, (question, results[:1])


def test_hindi_scholarship_query_finds_english_policy_despite_late_variant():
    add_doc(
        "en-scholarship",
        "Post-Matric Stipend Guideline",
        "Section 3. Eligibility. A student applying for the Post-Matric Stipend must be domiciled in the State. "
        "The annual income of parents or guardian from all sources shall not exceed Rs. 2,50,000 per annum.",
    )
    question = "छात्रवृत्ति के लिए आय सीमा क्या है"
    variants = build_query_variants(question)
    results = retrieve(question, query_variants=variants)
    assert results and results[0]["document_id"] == "en-scholarship"
    assert any("stipend" in x.casefold() for x in variants)


def test_hinglish_scholarship_question_retrieves_english_policy():
    add_doc(
        "en-scholarship",
        "Post-Matric Stipend Guideline",
        "Applicants for the Post-Matric Stipend must upload caste certificate, income certificate, previous marksheet and bank passbook.",
    )
    question = "mujhe scholarship ke liye kya documents chahiye"
    results = retrieve(question, query_variants=build_query_variants(question))
    assert results and results[0]["document_id"] == "en-scholarship"


def test_parent_earnings_college_funding_paraphrase_retrieves_scholarship():
    add_doc(
        "en-scholarship",
        "Post-Matric Stipend Guideline",
        "A student applying for the Post-Matric Stipend must be domiciled in the State. "
        "The annual income of parents or guardian from all sources shall not exceed Rs. 2,50,000 per annum.",
    )
    question = "Can my daughter get money for college if my earnings are low?"
    results = retrieve(question, query_variants=build_query_variants(question))
    assert results and results[0]["document_id"] == "en-scholarship"


def test_family_income_phrase_retrieves_relevant_source_not_farmer_family():
    add_doc("scholar", "Scholarship guideline", "Annual family income must not exceed ₹2,50,000. A student must be domiciled in Bihar.")
    add_doc("farm", "Farmer support guideline", "All landholding farmer families may receive income support of ₹6,000 per year, subject to exclusions.")
    results = retrieve("What is the family income limit?", k=5)
    assert results and results[0]["document_id"] == "scholar"


def test_farmer_query_does_not_get_scholarship_from_bad_money_synonym():
    add_doc("scholar", "Scholarship guideline", "A student applying for the Post-Matric Stipend must meet the scholarship conditions.")
    add_doc("farm", "Farmer support guideline", "Landholding farmer families may receive income support of ₹6,000 per year, subject to exclusions.")
    results = retrieve("How much money does a farmer family get every year?", query_variants=build_query_variants("How much money does a farmer family get every year?"))
    assert results and results[0]["document_id"] == "farm"


def test_irrelevant_tax_capital_and_single_tax_queries_abstain():
    add_doc("farm", "Farmer support", "Landholding farmer families may receive income support. Income-tax payers are excluded.")
    add_doc("scholar", "Scholarship", "Student scholarship eligibility depends on annual family income and domicile.")
    for question in (
        "What is the penalty for tax evasion under the Income Tax Act?",
        "tax",
        "What is the capital of France?",
    ):
        assert retrieve(question) == [], question


def test_bm25_index_is_invalidated_when_documents_are_added():
    add_doc("first", "First", "A student scholarship requires an income certificate and domicile proof.")
    first = retrieve("scholarship domicile certificate")
    assert first and first[0]["document_id"] == "first"
    add_doc("second", "Second", "A later student scholarship guideline states a new income certificate requirement.")
    second = retrieve("scholarship income certificate")
    assert {x["document_id"] for x in second} >= {"first", "second"}


def test_category_state_and_hindi_aliases_are_normalised():
    conditions = [
        {"text": "Must belong to Scheduled Caste", "profile_field": "category", "operator": "eq", "expected_value": "SC", "unit": ""},
        {"text": "Must be resident of Bihar", "profile_field": "state", "operator": "eq", "expected_value": "Bihar", "unit": ""},
    ]
    result = evaluate_conditions(conditions, {"category": "अनुसूचित जाति", "state": "बिहार"})
    assert [x["status"] for x in result["conditions"]] == ["MET", "MET"]


def test_unsupported_enum_value_is_unknown_not_false_ineligibility():
    conditions = [{"text": "Must be SC", "profile_field": "category", "operator": "eq", "expected_value": "SC", "unit": ""}]
    result = evaluate_conditions(conditions, {"category": "SC/ST or unsure"})
    assert result["conditions"][0]["status"] == "UNKNOWN"
    assert result["overall_status"] == "MORE_INFORMATION_NEEDED"


def test_hindi_number_and_indian_amount_formats_are_parsed():
    assert _number("ढाई लाख", "INR") == 250000
    assert _number("2,50,000 per year", "INR") == 250000
    assert _number("बीस", "years") == 20
    assert _number("₹२.५ लाख", "INR") == 250000
    assert _number("50kg", "INR") is None


def test_explicit_disability_exception_can_override_income_failure():
    conditions = [{
        "text": "Income must not exceed ₹2.5 lakh, except applicants with disabilities.",
        "expression": {"logic": "leaf", "profile_field": "annual_family_income", "operator": "lte", "expected_value": 250000, "unit": "INR"},
        "exception_if": {"logic": "any", "conditions": [
            {"profile_field": "disability", "operator": "eq", "expected_value": "yes"}
        ]},
        "exception_effect": "waives_requirement",
        "evidence_id": "E1",
    }]
    result = evaluate_conditions(conditions, {"annual_family_income": 900000, "disability": "दिव्यांग"})
    assert result["conditions"][0]["status"] == "MET"
    assert "exception" in result["conditions"][0]["reason"].lower()


def test_missing_exception_profile_makes_income_failure_unknown():
    conditions = [{
        "text": "Income must not exceed ₹2.5 lakh, except applicants with disabilities.",
        "expression": {"logic": "leaf", "profile_field": "annual_family_income", "operator": "lte", "expected_value": 250000, "unit": "INR"},
        "exception_if": {"logic": "any", "conditions": [
            {"profile_field": "disability", "operator": "eq", "expected_value": "yes"}
        ]},
        "exception_effect": "waives_requirement",
    }]
    result = evaluate_conditions(conditions, {"annual_family_income": 900000})
    assert result["conditions"][0]["status"] == "UNKNOWN"
    assert result["overall_status"] == "MORE_INFORMATION_NEEDED"


def test_or_expression_is_evaluated_without_flattening_to_and():
    conditions = [{
        "text": "Applicant must be either under 25 or belong to SC category.",
        "expression": {"logic": "any", "conditions": [
            {"profile_field": "age", "operator": "lt", "expected_value": 25, "unit": "years"},
            {"profile_field": "category", "operator": "eq", "expected_value": "SC", "unit": ""},
        ]},
    }]
    result = evaluate_conditions(conditions, {"age": 30, "category": "Scheduled Caste"})
    assert result["conditions"][0]["status"] == "MET"


def test_comparator_direction_parser_distinguishes_boundaries():
    assert _comparison_direction("Income must not exceed ₹2.5 lakh") == {"lte"}
    assert _comparison_direction("Age must be at least 18 years") == {"gte"}
    assert _comparison_direction("Applicant must be below 25 years") == {"lt"}
    assert _comparison_direction("Only income greater than ₹2.5 lakh qualifies") == {"gt"}
    assert _comparison_direction("आय 2.5 लाख से अधिक नहीं होनी चाहिए") == {"lte"}


def test_grounding_rejects_reversed_income_limit_even_with_exact_quote():
    quote = "Annual family income of the applicant must not exceed Rs. 2,50,000 per annum."
    evidence = [{"evidence_id": "doc::p1", "text": quote}]
    payload = {
        "simple_answer": "Only families earning MORE than 2,50,000 qualify.",
        "summary_evidence": [{"evidence_id": "doc::p1", "quote": quote}],
        "claims": [{"text": "Only families earning MORE than 2,50,000 qualify.", "evidence": [{"evidence_id": "doc::p1", "quote": quote}]}],
        "unknowns": [], "next_steps": [],
    }
    with pytest.raises(GroundingError, match="comparison operator"):
        validate_grounded_payload(payload, evidence)


def test_grounding_rejects_universal_eligibility_against_restrictive_quote():
    quote = "A student is eligible only if annual family income does not exceed ₹2.5 lakh."
    evidence = [{"evidence_id": "doc::p1", "text": quote}]
    payload = {
        "simple_answer": "Students from every income group are eligible.",
        "summary_evidence": [{"evidence_id": "doc::p1", "quote": quote}],
        "claims": [{"text": "Students from every income group are eligible.", "evidence": [{"evidence_id": "doc::p1", "quote": quote}]}],
        "unknowns": [], "next_steps": [],
    }
    with pytest.raises(GroundingError):
        validate_grounded_payload(payload, evidence)


def test_grounding_accepts_faithful_hindi_digits_and_lakh_paraphrases():
    quote = "Annual family income of the applicant must not exceed Rs. 2,50,000 per annum."
    evidence = [{"evidence_id": "doc::p1", "text": quote}]
    for answer in (
        "परिवार की वार्षिक आय २,५०,००० रुपये से अधिक नहीं होनी चाहिए।",
        "परिवार की वार्षिक आय 2.5 लाख रुपये से अधिक नहीं होनी चाहिए।",
        "Family income must not exceed 2.5 lakh rupees per year.",
    ):
        payload = {
            "simple_answer": answer,
            "summary_evidence": [{"evidence_id": "doc::p1", "quote": quote}],
            "claims": [{"text": answer, "evidence": [{"evidence_id": "doc::p1", "quote": quote}]}],
            "unknowns": [], "next_steps": [],
        }
        assert validate_grounded_payload(payload, evidence)["claims"]


def test_grounding_rejects_unrelated_claim_even_when_quote_exists():
    quote = "Annual family income of the applicant must not exceed Rs. 2,50,000 per annum."
    evidence = [{"evidence_id": "doc::p1", "text": quote}]
    payload = {
        "simple_answer": "The applicant receives a free laptop every year.",
        "summary_evidence": [{"evidence_id": "doc::p1", "quote": quote}],
        "claims": [{"text": "The applicant receives a free laptop every year.", "evidence": [{"evidence_id": "doc::p1", "quote": quote}]}],
        "unknowns": [], "next_steps": [],
    }
    with pytest.raises(GroundingError):
        validate_grounded_payload(payload, evidence)


def test_extraction_downgrades_unrepresented_exception_to_unknown(monkeypatch):
    from app import llm
    quote = "Annual family income must not exceed ₹2.5 lakh, except applicants with disabilities."
    passages = [{"evidence_id": "doc::p1-c0", "text": quote, "document_id": "doc", "title": "Test", "page": 1}]
    response = {
        "document_summary": "The source contains an income limit.",
        "document_summary_evidence": [{"evidence_id": "doc::p1-c0", "exact_quote": quote}],
        "rights": [], "eligibility_conditions": [{
            "text": "Annual family income must not exceed ₹2.5 lakh.", "evidence_id": "doc::p1-c0", "exact_quote": quote,
            "profile_field": "annual_family_income", "operator": "lte", "expected_value": 250000, "unit": "INR",
        }],
        "obligations": [], "deadlines": [], "documents": [], "benefits": [], "exceptions": [], "authorities": [], "open_questions": [],
    }
    monkeypatch.setattr(llm, "_json_completion", lambda *a, **k: response)
    result = _extract_policy_batch(passages, "en")
    assert result["eligibility_conditions"][0]["operator"] == "unknown"
    assert result["eligibility_conditions"][0]["expected_value"] is None


def test_extraction_preserves_explicit_disability_exception_tree(monkeypatch):
    from app import llm
    quote = "Annual family income must not exceed ₹2.5 lakh. Applicants with disabilities are exempt from this income ceiling."
    passages = [{"evidence_id": "doc::p1-c0", "text": quote, "document_id": "doc", "title": "Test", "page": 1}]
    response = {
        "document_summary": "The guideline contains an income ceiling and a disability exception.",
        "document_summary_evidence": [{"evidence_id": "doc::p1-c0", "exact_quote": quote}],
        "rights": [], "eligibility_conditions": [{
            "text": "Income ceiling, with an exemption for applicants with disabilities.",
            "evidence_id": "doc::p1-c0", "exact_quote": quote,
            "profile_field": "annual_family_income", "operator": "lte", "expected_value": 250000, "unit": "INR",
            "exception_if": {"logic": "any", "conditions": [
                {"profile_field": "disability", "operator": "eq", "expected_value": "yes", "unit": "", "text": "Applicant has a disability"}
            ]},
        }],
        "obligations": [], "deadlines": [], "documents": [], "benefits": [], "exceptions": [], "authorities": [], "open_questions": [],
    }
    monkeypatch.setattr(llm, "_json_completion", lambda *a, **k: response)
    result = _extract_policy_batch(passages, "en")
    condition = result["eligibility_conditions"][0]
    assert condition["operator"] == "lte"
    assert condition["exception_if"]["conditions"][0]["operator"] == "eq"


def test_numeric_validator_does_not_infer_rupees_from_unrelated_raw_number():
    from app.llm import _numeric_value_is_supported
    assert not _numeric_value_is_supported(250000, "INR", "The applicant must be 250000 years old.")
    assert _numeric_value_is_supported(250000, "INR", "Annual family income must be 250000.")


def test_document_version_history_records_revert_a_to_b_to_a():
    def save(text: str):
        return store.upsert_document({
            "document_id": "versioned-source", "title": "Versioned test source",
            "source_url": "https://synthetic.test/versioned.pdf", "canonical_url": "https://synthetic.test/versioned.pdf",
            "jurisdiction": "Test only", "issuing_authority": "synthetic.test",
            "authority_status": "OFFICIAL_DOMAIN_NOT_DOCUMENT_AUTHENTICATED",
            "provenance": "TEST_FIXTURE", "freshness": "CACHED", "retrieved_at": store.utcnow(),
            "document_date": None, "content_type": "application/pdf", "raw_text": text,
            "page_count": 1, "evidence": _split_page_text(text, 1),
        })

    first = "Section 1. Scholarship. Annual family income must not exceed Rs. 2,50,000."
    second = "Section 1. Scholarship. Annual family income must not exceed Rs. 4,50,000."
    assert save(first)["version_number"] == 1
    assert save(second)["version_number"] == 2
    reverted = save(first)
    assert reverted["version_number"] == 3
    versions = store.get_document_versions("versioned-source", 10)
    assert [x["version_number"] for x in versions] == [3, 2, 1]
    assert len({x["version_id"] for x in versions}) == 3


def test_unchanged_refetch_does_not_create_duplicate_version():
    text = "Section 1. Applicants must submit an income certificate."
    payload = {
        "document_id": "stable-source", "title": "Stable", "source_url": "https://synthetic.test/stable.pdf",
        "jurisdiction": "Test", "issuing_authority": "synthetic.test", "authority_status": "UNVERIFIED",
        "provenance": "TEST_FIXTURE", "freshness": "CACHED", "retrieved_at": store.utcnow(),
        "raw_text": text, "page_count": 1, "evidence": _split_page_text(text, 1),
    }
    store.upsert_document(payload)
    store.upsert_document({**payload, "retrieved_at": store.utcnow()})
    assert [x["version_number"] for x in store.get_document_versions("stable-source")] == [1]


def test_rule_evaluator_marks_truncated_conditions_incomplete():
    conditions = [
        {"text": f"State must be Bihar {i}", "profile_field": "state", "operator": "eq", "expected_value": "Bihar", "unit": ""}
        for i in range(31)
    ]
    result = evaluate_conditions(conditions, {"state": "Bihar"})
    assert result["conditions_evaluated"] == 30
    assert result["conditions_provided"] == 31
    assert result["analysis_incomplete"] is True
    assert result["overall_status"] == "INCOMPLETE_CONDITIONS_REVIEW_REQUIRED"


def test_rule_evaluator_bounds_expression_depth_and_node_count():
    from app.rules import _evaluate_expression
    expression = {"logic": "all", "conditions": [{"profile_field": "age", "operator": "gte", "expected_value": 18, "unit": "years"}]}
    for _ in range(12):
        expression = {"logic": "not", "condition": expression}
    result = _evaluate_expression(expression, {"age": 20})
    assert result["status"] == "UNKNOWN"
    assert "too deep" in result["reason"]


def test_llm_condition_extraction_cannot_map_age_from_income_quote():
    from app.llm import _validate_condition_expression
    result = _validate_condition_expression(
        {"logic": "leaf", "profile_field": "age", "operator": "lte", "expected_value": 250000, "unit": "INR"},
        "Annual family income must not exceed Rs. 2,50,000 per annum.",
        {"age", "annual_family_income"}, {"lte", "unknown"},
    )
    assert result["logic"] == "unknown"


def test_llm_condition_extraction_requires_field_and_comparator_evidence():
    from app.llm import _validate_condition_expression
    result = _validate_condition_expression(
        {"logic": "leaf", "profile_field": "annual_family_income", "operator": "lte", "expected_value": 250000, "unit": "INR"},
        "The annual income of parents or guardian shall not exceed Rs. 2,50,000 per annum.",
        {"annual_family_income"}, {"lte", "unknown"},
    )
    assert result["profile_field"] == "annual_family_income"
    assert result["operator"] == "lte"


def test_cross_source_conflicts_compare_typed_facts_and_support_hindi():
    from app.policy import _potential_conflicts
    evidence = [
        {"evidence_id": "a::1", "document_id": "a", "title": "Scheme A", "text": "छात्रवृत्ति के लिए परिवार की वार्षिक आय 2,50,000 रुपये से अधिक नहीं होनी चाहिए."},
        {"evidence_id": "b::1", "document_id": "b", "title": "Scheme B", "text": "छात्रवृत्ति के लिए परिवार की वार्षिक आय 4,50,000 रुपये से अधिक नहीं होनी चाहिए."},
    ]
    conflicts = _potential_conflicts(evidence)
    assert conflicts and conflicts[0]["type"] == "POTENTIAL_NUMERIC_DIFFERENCE"
    assert ("INR", "250000") in {tuple(x) for x in conflicts[0]["left_numeric_facts"]}
    # Differing units alone must not be presented as a comparable policy discrepancy.
    unrelated = [
        {"evidence_id": "c::1", "document_id": "c", "text": "A student must be at least 18 years old."},
        {"evidence_id": "d::1", "document_id": "d", "text": "A student grant is INR 18,000."},
    ]
    assert _potential_conflicts(unrelated) == []


def test_retrieval_match_label_does_not_call_every_admitted_result_strong():
    from app.policy import _retrieval_strength
    assert _retrieval_strength([{"score": 0.51}]) == "moderate"
    assert _retrieval_strength([{"score": 0.79}]) == "strong"


def test_grounding_validator_rejects_universal_claim_not_supported_by_source():
    source = [{"evidence_id": "doc::p1-c0", "text": "Students must be domiciled in Bihar to apply for this scholarship."}]
    payload = {
        "simple_answer": "All students in India are eligible for this scholarship.",
        "summary_evidence": [{"evidence_id": "doc::p1-c0", "quote": source[0]["text"]}],
        "claims": [{"text": "All students in India are eligible for this scholarship.", "evidence": [{"evidence_id": "doc::p1-c0", "quote": source[0]["text"]}]}],
    }
    with pytest.raises(GroundingError):
        validate_grounded_payload(payload, source)


def test_grounding_validator_accepts_full_clause_paraphrase_with_lakh_units():
    source_text = "The annual income of parents or guardian from all sources shall not exceed Rs. 2,50,000 per annum."
    source = [{"evidence_id": "doc::p1-c0", "text": source_text}]
    payload = {
        "simple_answer": "Your parents' or guardian's yearly income must be at most 2.5 lakh rupees.",
        "summary_evidence": [{"evidence_id": "doc::p1-c0", "quote": source_text}],
        "claims": [{"text": "Your parents' or guardian's yearly income must be at most 2.5 lakh rupees.", "evidence": [{"evidence_id": "doc::p1-c0", "quote": source_text}]}],
    }
    result = validate_grounded_payload(payload, source)
    assert result["claims"]


def test_legacy_v07_version_table_migrates_without_losing_history(tmp_path, monkeypatch):
    import sqlite3
    legacy_db = tmp_path / "legacy.sqlite3"
    with sqlite3.connect(legacy_db) as conn:
        conn.execute("""CREATE TABLE document_versions (
            version_id TEXT PRIMARY KEY, document_id TEXT NOT NULL, version_number INTEGER NOT NULL,
            raw_hash TEXT NOT NULL, normalized_hash TEXT NOT NULL, change_kind TEXT NOT NULL,
            change_summary TEXT NOT NULL, retrieved_at TEXT NOT NULL, source_url TEXT NOT NULL,
            UNIQUE(document_id, normalized_hash)
        )""")
        conn.execute("CREATE INDEX idx_versions_doc ON document_versions(document_id, version_number DESC)")
        conn.execute("""INSERT INTO document_versions VALUES
            ('v1','legacy',1,'r1','h1','BASELINE','baseline','2026-01-01','https://synthetic.test/a'),
            ('v2','legacy',2,'r2','h2','SECTION_TEXT_CHANGED_REVIEW_REQUIRED','changed','2026-01-02','https://synthetic.test/a')""")
    monkeypatch.setattr(store, "DB_FILE", legacy_db)
    store.init_db()
    versions = store.get_document_versions("legacy", 10)
    assert [x["version_number"] for x in versions] == [2, 1]
    with store.connect() as conn:
        indexes = conn.execute("PRAGMA index_list(document_versions)").fetchall()
        unique_indexes = [x for x in indexes if x["unique"]]
        unique_columns = [[c["name"] for c in conn.execute(f'PRAGMA index_info("{x["name"]}")').fetchall()] for x in unique_indexes]
        assert ["document_id", "normalized_hash"] not in unique_columns
        assert any(x["name"] == "idx_versions_doc" for x in indexes)


def test_ambiguous_exception_never_automatically_approves_applicant():
    conditions = [{
        "text": "Income cap has an exception for PwD.",
        "expression": {"logic": "leaf", "profile_field": "annual_family_income", "operator": "lte", "expected_value": 250000, "unit": "INR"},
        "exception_if": {"logic": "any", "conditions": [{"profile_field": "disability", "operator": "eq", "expected_value": "yes"}]},
        "exception_effect": "unknown",
    }]
    result = evaluate_conditions(conditions, {"annual_family_income": 900000, "disability": "yes"})
    assert result["conditions"][0]["status"] == "UNKNOWN"


def test_explicit_exclusion_exception_marks_condition_not_met():
    conditions = [{
        "text": "Applicants are eligible except those who are disqualified.",
        "profile_field": "registration_status", "operator": "eq", "expected_value": "registered", "unit": "",
        "exception_if": {"logic": "any", "conditions": [{"profile_field": "registration_status", "operator": "eq", "expected_value": "disqualified"}]},
        "exception_effect": "excludes_applicant",
    }]
    result = evaluate_conditions(conditions, {"registration_status": "disqualified"})
    assert result["conditions"][0]["status"] == "NOT_MET"


def test_extraction_does_not_flatten_or_alternative_into_single_leaf(monkeypatch):
    from app import llm
    quote = "Applicants must be either below 25 years of age or belong to the SC category."
    evidence = [{"evidence_id": "doc::p1-c0", "text": quote}]
    raw = {
        "document_summary": "The passage describes an eligibility condition.",
        "document_summary_evidence": [{"evidence_id": "doc::p1-c0", "exact_quote": quote}],
        "eligibility_conditions": [{
            "text": "Applicants must be below 25 years of age.",
            "evidence_id": "doc::p1-c0", "exact_quote": quote,
            "profile_field": "age", "operator": "lt", "expected_value": 25, "unit": "years",
            "expression": {"logic": "leaf", "profile_field": "age", "operator": "lt", "expected_value": 25, "unit": "years"},
        }],
    }
    monkeypatch.setattr(llm, "_json_completion", lambda *args: raw)
    result = llm._extract_policy_batch(evidence, "en")
    assert result["eligibility_conditions"][0]["operator"] == "unknown"
    assert result["eligibility_conditions"][0]["expression"]["logic"] == "unknown"


def test_extraction_requires_exception_effect_and_retains_ambiguous_as_unknown(monkeypatch):
    from app import llm
    quote = ("Annual family income must not exceed Rs. 2,50,000 per annum, except for applicants with disabilities; "
             "the income limit shall not apply to those applicants.")
    evidence = [{"evidence_id": "doc::p1-c0", "text": quote}]
    raw = {
        "document_summary": "The passage sets an income limit and mentions a disability exception.",
        "document_summary_evidence": [{"evidence_id": "doc::p1-c0", "exact_quote": quote}],
        "eligibility_conditions": [{
            "text": "Annual family income must not exceed Rs. 2,50,000.",
            "evidence_id": "doc::p1-c0", "exact_quote": quote,
            "profile_field": "annual_family_income", "operator": "lte", "expected_value": 250000, "unit": "INR",
            "expression": {"logic": "leaf", "profile_field": "annual_family_income", "operator": "lte", "expected_value": 250000, "unit": "INR"},
            "exception_if": {"logic": "any", "conditions": [{"profile_field": "disability", "operator": "eq", "expected_value": "yes"}]},
            "exception_effect": "ambiguous_guess",
        }],
    }
    monkeypatch.setattr(llm, "_json_completion", lambda *args: raw)
    result = llm._extract_policy_batch(evidence, "en")
    assert result["eligibility_conditions"][0]["exception_effect"] == "unknown"


def test_policy_query_phrase_family_income_matches_parental_income_wording():
    add_doc(
        "parent-income", "Scholarship guideline",
        "A student applying for the Post-Matric Stipend must be domiciled in the State. "
        "The annual income of parents or guardian from all sources shall not exceed Rs. 2,50,000 per annum.",
    )
    results = retrieve("What is the family income limit for the stipend?", query_variants=build_query_variants("What is the family income limit for the stipend?"))
    assert results and results[0]["document_id"] == "parent-income"


def test_explicit_waiver_requires_clear_source_effect_wording():
    from app.llm import _exception_effect_supported
    assert _exception_effect_supported(
        "waives_requirement",
        "Income must not exceed Rs. 2,50,000, except applicants with disabilities.",
    ) is False
    assert _exception_effect_supported(
        "waives_requirement",
        "Income must not exceed Rs. 2,50,000, except applicants with disabilities; the income limit shall not apply to those applicants.",
    ) is True


def test_extracted_and_conditions_are_not_flattened_to_one_leaf(monkeypatch):
    from app import llm
    quote = "Applicants must be domiciled in Bihar and belong to the Scheduled Caste category."
    evidence = [{"evidence_id": "doc::p1-c0", "text": quote}]
    raw = {
        "document_summary": "The passage gives domicile and category conditions.",
        "document_summary_evidence": [{"evidence_id": "doc::p1-c0", "exact_quote": quote}],
        "eligibility_conditions": [{
            "text": "Applicants must be domiciled in Bihar.",
            "evidence_id": "doc::p1-c0", "exact_quote": quote,
            "profile_field": "state", "operator": "eq", "expected_value": "Bihar", "unit": "",
            "expression": {"logic": "leaf", "profile_field": "state", "operator": "eq", "expected_value": "Bihar", "unit": ""},
        }],
    }
    monkeypatch.setattr(llm, "_json_completion", lambda *args: raw)
    result = llm._extract_policy_batch(evidence, "en")
    condition = result["eligibility_conditions"][0]
    assert condition["operator"] == "unknown"
    assert condition["expression"]["logic"] == "unknown"


def test_extracted_all_expression_is_preserved_when_all_fields_are_supported(monkeypatch):
    from app import llm
    quote = "Applicants must be domiciled in Bihar and belong to the Scheduled Caste category."
    evidence = [{"evidence_id": "doc::p1-c0", "text": quote}]
    raw = {
        "document_summary": "The passage gives domicile and category conditions.",
        "document_summary_evidence": [{"evidence_id": "doc::p1-c0", "exact_quote": quote}],
        "eligibility_conditions": [{
            "text": "Applicants must be domiciled in Bihar and belong to the Scheduled Caste category.",
            "evidence_id": "doc::p1-c0", "exact_quote": quote,
            "profile_field": "state", "operator": "eq", "expected_value": "Bihar", "unit": "",
            "expression": {"logic": "all", "conditions": [
                {"logic": "leaf", "profile_field": "state", "operator": "eq", "expected_value": "Bihar", "unit": ""},
                {"logic": "leaf", "profile_field": "category", "operator": "eq", "expected_value": "SC", "unit": ""},
            ]},
        }],
    }
    monkeypatch.setattr(llm, "_json_completion", lambda *args: raw)
    result = llm._extract_policy_batch(evidence, "en")
    condition = result["eligibility_conditions"][0]
    assert condition["expression"]["logic"] == "all"
    evaluated = evaluate_conditions([condition], {"state": "Bihar", "category": "SC"})
    assert evaluated["conditions"][0]["status"] == "MET"


def test_grounding_requires_comparison_direction_when_repeating_threshold():
    evidence = [{
        "evidence_id": "doc::p1-c0",
        "text": "Annual family income must not exceed Rs. 2,50,000 per annum.",
    }]
    payload = {
        "simple_answer": "The family income limit is Rs. 2.5 lakh per year.",
        "summary_evidence": [{"evidence_id": "doc::p1-c0", "quote": "Annual family income must not exceed Rs. 2,50,000 per annum."}],
        "claims": [{
            "text": "The family income limit is Rs. 2.5 lakh per year.",
            "evidence": [{"evidence_id": "doc::p1-c0", "quote": "Annual family income must not exceed Rs. 2,50,000 per annum."}],
        }],
        "unknowns": [], "next_steps": [],
    }
    with pytest.raises(GroundingError, match="omits the source comparison direction"):
        validate_grounded_payload(payload, evidence)


def test_short_english_anchors_use_word_boundaries_not_substrings():
    from app.llm import _field_supported_in_quote, _expected_value_supported_in_quote
    assert _field_supported_in_quote("category", "The scholarship application is open to students.") is False
    assert _field_supported_in_quote("age", "This document contains four pages of information.") is False
    assert _field_supported_in_quote("category", "Applicants must belong to the SC category.") is True
    assert _expected_value_supported_in_quote("category", "SC", "The scholarship application is open to students.") is False
    assert _expected_value_supported_in_quote("category", "SC", "Applicants must belong to the SC category.") is True


def test_explicit_source_supported_waiver_survives_extraction_and_evaluation(monkeypatch):
    from app import llm
    quote = (
        "Annual family income must not exceed Rs. 2,50,000, except applicants with disabilities; "
        "the income limit shall not apply to those applicants."
    )
    evidence = [{"evidence_id": "doc::p1-c0", "text": quote}]
    raw = {
        "document_summary": "The passage sets an income cap and an explicit disability waiver.",
        "document_summary_evidence": [{"evidence_id": "doc::p1-c0", "exact_quote": quote}],
        "eligibility_conditions": [{
            "text": "The income cap applies except where the explicit disability waiver applies.",
            "evidence_id": "doc::p1-c0", "exact_quote": quote,
            "profile_field": "annual_family_income", "operator": "lte", "expected_value": 250000, "unit": "INR",
            "expression": {"logic": "leaf", "profile_field": "annual_family_income", "operator": "lte", "expected_value": 250000, "unit": "INR"},
            "exception_if": {"logic": "any", "conditions": [
                {"logic": "leaf", "profile_field": "disability", "operator": "eq", "expected_value": "yes", "unit": ""}
            ]},
            "exception_effect": "waives_requirement",
        }],
    }
    monkeypatch.setattr(llm, "_json_completion", lambda *args: raw)
    extracted = llm._extract_policy_batch(evidence, "en")
    condition = extracted["eligibility_conditions"][0]
    assert condition["exception_effect"] == "waives_requirement"
    result = evaluate_conditions([condition], {"annual_family_income": 900000, "disability": "yes"})
    assert result["conditions"][0]["status"] == "MET"
