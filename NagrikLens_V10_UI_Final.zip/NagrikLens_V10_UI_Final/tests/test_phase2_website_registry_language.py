from __future__ import annotations

import io
import json
import subprocess
from pathlib import Path
from urllib.parse import urlparse

import fitz
import pytest
import requests
from fastapi.testclient import TestClient

from app import ingestion, main, store
from app.ingestion import IngestionError
from app.policy import build_response


@pytest.fixture(autouse=True)
def isolated_db(tmp_path, monkeypatch):
    monkeypatch.setattr(store, "DB_FILE", tmp_path / "phase2.sqlite3")
    store.init_db()
    yield


def make_pdf(page_count: int = 10) -> bytes:
    doc = fitz.open()
    for n in range(1, page_count + 1):
        page = doc.new_page()
        text = (
            f"Section {n}. Page {n} Government Scheme Guideline. "
            f"This page explains eligibility condition {n}, annual income threshold {n * 100000}, "
            f"required supporting certificate {n}, and the application process for citizens. "
            "Applicants must follow the official instructions described on this page."
        )
        page.insert_text((55, 70), text)
    data = doc.tobytes()
    doc.close()
    return data


def add_doc(doc_id: str, title: str, text: str, page: int = 1):
    evidence = [{"evidence_id": f"p{page}-c0", "chunk_index": 0, "section": "Eligibility", "page": page, "text": text}]
    store.upsert_document({
        "document_id": doc_id, "title": title, "source_url": f"https://www.pib.gov.in/{doc_id}.pdf",
        "canonical_url": f"https://www.pib.gov.in/{doc_id}.pdf", "jurisdiction": "India",
        "issuing_authority": "www.pib.gov.in", "authority_status": "OFFICIAL_DOMAIN_NOT_DOCUMENT_AUTHENTICATED",
        "provenance": "HTTP_FETCH", "freshness": "LIVE", "retrieved_at": store.utcnow(),
        "document_date": None, "content_type": "application/pdf", "raw_text": text,
        "page_count": page, "evidence": evidence,
    })


class FakeResponse:
    def __init__(self, status_code=200, headers=None, url="https://www.pib.gov.in/page", body=b""):
        self.status_code = status_code
        self.headers = headers or {}
        self.url = url
        self.body = body
        self.closed = False

    def close(self):
        self.closed = True

    def iter_content(self, chunk_size=0):
        for i in range(0, len(self.body), max(chunk_size, 1)):
            yield self.body[i:i + chunk_size]

    def raise_for_status(self):
        if self.status_code >= 400:
            raise requests.HTTPError(f"HTTP {self.status_code}")


def test_pdf_page_mode_max_defaults_to_first_ten_and_reports_not_processed():
    result = ingestion.ingest_pdf_upload(make_pdf(100), "large.pdf", page_mode="max_page", max_page_number=10)
    report = result["processing_report"]
    assert report["total_pages"] == 100
    assert report["selected_pages"] == list(range(1, 11))
    assert report["extracted_pages"] == list(range(1, 11))
    assert report["not_processed_pages"] == list(range(11, 101))
    assert report["processing_status"] == "PARTIAL"  # document has unprocessed pages
    assert report["selected_scope_complete"] is True
    assert report["overall_completeness"] is False
    assert result["selected_pages"] == list(range(1, 11))
    assert all(row["page"] <= 10 for row in store.get_all_evidence(document_id=result["document_id"]))


def test_pdf_specific_nonconsecutive_pages_keep_original_numbers():
    result = ingestion.ingest_pdf_upload(make_pdf(12), "selected.pdf", page_mode="specific", selected_pages="2,8,10,7")
    assert result["selected_pages"] == [2, 7, 8, 10]
    report = result["processing_report"]
    assert report["selected_pages"] == [2, 7, 8, 10]
    assert report["not_processed_pages"] == [1, 3, 4, 5, 6, 9, 11, 12]
    pages = sorted(set(x["page"] for x in store.get_all_evidence(document_id=result["document_id"])))
    assert pages == [2, 7, 8, 10]


def test_pdf_all_pages_mode_processes_full_100_page_document():
    result = ingestion.ingest_pdf_upload(make_pdf(100), "all.pdf", page_mode="all")
    report = result["processing_report"]
    assert report["selected_pages"] == list(range(1, 101))
    assert report["extracted_pages"] == list(range(1, 101))
    assert report["not_processed_pages"] == []
    assert report["overall_completeness"] is True


def test_pdf_page_selection_rejects_invalid_and_empty_specific_pages():
    with pytest.raises(IngestionError, match="outside the PDF page range"):
        ingestion.ingest_pdf_upload(make_pdf(5), "bad.pdf", page_mode="specific", selected_pages="2,7")
    with pytest.raises(IngestionError, match="at least one page"):
        ingestion.ingest_pdf_upload(make_pdf(5), "empty.pdf", page_mode="specific", selected_pages=[])


def test_upload_api_defaults_to_ten_pages_but_clamps_to_short_pdf():
    client = TestClient(main.app)
    upload = client.post("/api/documents/upload", files={"file": ("short.pdf", make_pdf(1), "application/pdf")})
    assert upload.status_code == 200, upload.text
    assert upload.json()["selected_pages"] == [1]
    assert upload.json()["processing_report"]["total_pages"] == 1


def test_upload_api_specific_page_selection():
    client = TestClient(main.app)
    upload = client.post(
        "/api/documents/upload",
        files={"file": ("pages.pdf", make_pdf(10), "application/pdf")},
        data={"page_mode": "specific", "selected_pages": "2,8,10,7"},
    )
    assert upload.status_code == 200, upload.text
    assert upload.json()["selected_pages"] == [2, 7, 8, 10]


def test_processing_report_api_returns_scope_and_completeness():
    client = TestClient(main.app)
    upload = client.post(
        "/api/documents/upload", files={"file": ("report.pdf", make_pdf(12), "application/pdf")},
        data={"page_mode": "max_page", "max_page_number": "10"},
    )
    doc_id = upload.json()["document_id"]
    response = client.get(f"/api/documents/{doc_id}/processing-report")
    assert response.status_code == 200
    report = response.json()["processing_report"]
    assert report["total_pages"] == 12
    assert report["not_processed_pages"] == [11, 12]
    assert response.json()["selected_pages"] == list(range(1, 11))


def test_html_extraction_preserves_title_headings_lists_and_table_rows():
    html = b"""<html><head><title>Scheme Notice</title></head><body><nav>Navigation</nav><main>
    <h1>PM Scheme</h1><p>Applicants can receive assistance under the published scheme.</p>
    <h2>Eligibility</h2><ul><li>Applicant must be a resident.</li><li>Income must not exceed Rs 2 lakh.</li></ul>
    <h2>Benefits</h2><table><tr><th>Tranche</th><th>Amount</th></tr><tr><td>First</td><td>Rs 15000</td></tr></table>
    </main></body></html>"""
    title, text, sections, links = ingestion._html_document_detail(html)
    assert title == "Scheme Notice"
    assert "SECTION: Eligibility" in text
    assert "Applicant must be a resident" in text
    assert "Tranche | Amount" in text
    assert "First | Rs 15000" in text
    assert sections and not links


def test_approved_html_url_ingestion_stores_page_title_sections_and_provenance(monkeypatch):
    html = b"<html><head><title>Test Circular</title></head><body><main><h1>Eligibility</h1><p>Applicants must be residents of Bihar. The annual family income must not exceed Rs 250000. This is the complete eligibility rule for this synthetic source.</p><h2>Documents</h2><ul><li>Income certificate</li><li>Bank passbook</li></ul></main></body></html>"
    monkeypatch.setattr(ingestion, "validate_source_url", lambda u: u)
    monkeypatch.setattr(ingestion, "_bounded_get", lambda u: (html, FakeResponse(headers={"Content-Type": "text/html"}, url=u, body=html)))
    result = ingestion.ingest_url("https://www.pib.gov.in/circular")
    assert result["title"] == "Test Circular"
    assert result["provenance"] == "HTTP_FETCH"
    assert result["processing_report"]["processing_status"] == "COMPLETE"
    evidence = store.get_all_evidence(document_id=result["document_id"])
    joined = " ".join(row["text"] for row in evidence)
    assert "SECTION: Eligibility" in joined
    assert "Income certificate" in joined


def test_direct_pdf_url_is_ingested_with_page_selection(monkeypatch):
    pdf = make_pdf(12)
    url = "https://www.pib.gov.in/guideline.pdf"
    monkeypatch.setattr(ingestion, "validate_source_url", lambda u: u)
    monkeypatch.setattr(ingestion, "_bounded_get", lambda u: (pdf, FakeResponse(headers={"Content-Type": "application/pdf"}, url=u, body=pdf)))
    result = ingestion.ingest_url(url, page_mode="specific", selected_pages=[2, 8, 10, 7])
    assert result["ingestion_kind"] == "DIRECT_PDF_URL"
    assert result["selected_pages"] == [2, 7, 8, 10]
    assert result["provenance"] == "HTTP_FETCH"


def test_linked_pdf_is_not_fetched_without_explicit_request(monkeypatch):
    html = b'<html><head><title>Notice</title></head><body><main><h1>Notice</h1><p>This page describes a government notice and its broad purpose for citizens.</p><a href="/attachment.pdf">Download PDF</a></main></body></html>'
    calls = []
    def fake_get(url):
        calls.append(url)
        return html, FakeResponse(headers={"Content-Type": "text/html"}, url=url, body=html)
    monkeypatch.setattr(ingestion, "validate_source_url", lambda u: u)
    monkeypatch.setattr(ingestion, "_bounded_get", fake_get)
    ingestion.ingest_url("https://www.pib.gov.in/notice")
    assert calls == ["https://www.pib.gov.in/notice"]


def test_linked_pdf_is_fetched_only_when_requested_and_within_bound(monkeypatch):
    html = b'<html><head><title>Notice</title></head><body><main><h1>Notice</h1><p>This page describes a government notice and its broad purpose for citizens.</p><a href="/attachment.pdf">Download PDF</a></main></body></html>'
    pdf = make_pdf(2)
    calls = []
    def fake_get(url):
        calls.append(url)
        if url.endswith("attachment.pdf"):
            return pdf, FakeResponse(headers={"Content-Type": "application/pdf"}, url=url, body=pdf)
        return html, FakeResponse(headers={"Content-Type": "text/html"}, url=url, body=html)
    monkeypatch.setattr(ingestion, "validate_source_url", lambda u: u)
    monkeypatch.setattr(ingestion, "_bounded_get", fake_get)
    result = ingestion.ingest_url("https://www.pib.gov.in/notice", include_linked_pdfs=True, max_linked_pdfs=3)
    assert calls == ["https://www.pib.gov.in/notice", "https://www.pib.gov.in/attachment.pdf"]
    assert len(result["linked_pdfs"]) == 1
    assert result["linked_pdfs"][0]["content_type"] == "application/pdf"


def test_linked_pdf_on_different_host_is_skipped(monkeypatch):
    html = b'<html><head><title>Notice</title></head><body><main><h1>Notice</h1><p>This page describes a government notice and its broad purpose for citizens.</p><a href="https://evil.example/file.pdf">External PDF</a></main></body></html>'
    monkeypatch.setattr(ingestion, "validate_source_url", lambda u: u)
    monkeypatch.setattr(ingestion, "_bounded_get", lambda u: (html, FakeResponse(headers={"Content-Type": "text/html"}, url=u, body=html)))
    result = ingestion.ingest_url("https://www.pib.gov.in/notice", include_linked_pdfs=True)
    assert result["linked_pdfs"][0]["status"] == "SKIPPED_DIFFERENT_HOST"


def test_same_domain_redirect_is_followed_after_each_validation(monkeypatch):
    calls = []
    allowed = {"www.pib.gov.in", "pib.gov.in"}
    def validate(url):
        parsed = urlparse(url)
        if parsed.scheme != "https" or parsed.hostname not in allowed:
            raise IngestionError("redirect hostname not allowlisted")
        return url
    responses = [
        FakeResponse(302, {"Location": "/final"}, "https://www.pib.gov.in/first"),
        FakeResponse(200, {"Content-Length": "4"}, "https://www.pib.gov.in/final", b"data"),
    ]
    def fake_get(url, **kwargs):
        calls.append(url)
        return responses.pop(0)
    monkeypatch.setattr(ingestion, "validate_source_url", validate)
    monkeypatch.setattr(ingestion.requests, "get", fake_get)
    data, response = ingestion._bounded_get("https://www.pib.gov.in/first")
    assert data == b"data"
    assert calls == ["https://www.pib.gov.in/first", "https://www.pib.gov.in/final"]


def test_redirect_to_approved_host_is_allowed_after_validation(monkeypatch):
    calls = []
    allowed = {"www.pib.gov.in", "scholarships.gov.in"}
    def validate(url):
        parsed = urlparse(url)
        if parsed.scheme != "https" or parsed.hostname not in allowed:
            raise IngestionError(f"Source host '{parsed.hostname}' is not allowlisted")
        return url
    responses = [
        FakeResponse(302, {"Location": "https://scholarships.gov.in/file.pdf"}, "https://www.pib.gov.in/go"),
        FakeResponse(200, {"Content-Length": "4"}, "https://scholarships.gov.in/file.pdf", b"data"),
    ]
    def fake_get(url, **kwargs):
        calls.append(url)
        return responses.pop(0)
    monkeypatch.setattr(ingestion, "validate_source_url", validate)
    monkeypatch.setattr(ingestion.requests, "get", fake_get)
    data, _ = ingestion._bounded_get("https://www.pib.gov.in/go")
    assert data == b"data"
    assert len(calls) == 2


def test_redirect_to_unapproved_host_is_blocked_before_second_request(monkeypatch):
    calls = []
    def validate(url):
        host = urlparse(url).hostname
        if host != "www.pib.gov.in":
            raise IngestionError(f"Source host '{host}' is not allowlisted")
        return url
    response = FakeResponse(302, {"Location": "https://evil.example/file.pdf"}, "https://www.pib.gov.in/go")
    monkeypatch.setattr(ingestion, "validate_source_url", validate)
    monkeypatch.setattr(ingestion.requests, "get", lambda url, **kwargs: calls.append(url) or response)
    with pytest.raises(IngestionError, match="evil.example"):
        ingestion._bounded_get("https://www.pib.gov.in/go")
    assert len(calls) == 1


def test_private_ip_dns_is_blocked(monkeypatch):
    monkeypatch.setattr(ingestion.socket, "getaddrinfo", lambda *a, **k: [(None, None, None, None, ("10.0.0.5", 443))])
    with pytest.raises(IngestionError, match="non-public"):
        ingestion._validate_public_dns("www.pib.gov.in")


def test_unapproved_host_error_names_hostname_and_records_pending(monkeypatch):
    monkeypatch.setattr(ingestion, "_validate_public_dns", lambda host: None)
    with pytest.raises(IngestionError, match="unknown.example"):
        ingestion.validate_source_url("https://unknown.example/policy.pdf")
    rows = store.get_source_registry()
    pending = next(x for x in rows if x["hostname"] == "unknown.example")
    assert pending["approval_status"] == "PENDING"
    assert pending["host_fetch_status"] == "BLOCKED"


def test_source_registry_is_dynamic_and_includes_ingested_document(monkeypatch):
    add_doc("registry-doc", "Registry test", "A policy passage about financial assistance for residents.")
    client = TestClient(main.app)
    result = client.get("/api/sources/registry")
    assert result.status_code == 200
    data = result.json()
    assert any(x["hostname"] == "pib.gov.in" for x in data["sources"])
    assert any(x["document_id"] == "registry-doc" and x["document_ingested"] for x in data["ingested_documents"])


def test_admin_source_approval_and_rejection_require_separate_admin_key(monkeypatch):
    monkeypatch.setattr(main, "ADMIN_API_KEY", "phase2-test-admin-secret")
    client = TestClient(main.app)
    denied = client.post("/api/admin/sources/approve", json={"hostname": "new.example"})
    assert denied.status_code == 401
    approved = client.post("/api/admin/sources/approve", json={"hostname": "new.example", "authority": "Test Department"}, headers={"X-Nagriklens-Admin-Key": "phase2-test-admin-secret"})
    assert approved.status_code == 200, approved.text
    assert approved.json()["source"]["approval_status"] == "APPROVED"
    assert "document_authentication" in approved.json()["source"]
    monkeypatch.setattr(ingestion, "_validate_public_dns", lambda host: None)
    assert ingestion.validate_source_url("https://new.example/test") == "https://new.example/test"
    rejected = client.post("/api/admin/sources/reject", json={"hostname": "new.example", "reason": "not an official source"}, headers={"X-Nagriklens-Admin-Key": "phase2-test-admin-secret"})
    assert rejected.status_code == 200
    with pytest.raises(IngestionError, match="new.example"):
        ingestion.validate_source_url("https://new.example/test")


def test_admin_host_approval_rejects_wildcards_ports_and_ip_literals():
    with pytest.raises(ValueError):
        store.approve_source_host("*.example.com")
    with pytest.raises(ValueError):
        store.approve_source_host("example.com:443")
    with pytest.raises(ValueError):
        store.approve_source_host("127.0.0.1")


def test_selected_document_query_does_not_retrieve_other_documents():
    add_doc("doc-a", "Scholarship", "Scholarship annual family income must not exceed 250000 rupees per year.")
    add_doc("doc-b", "Housing", "Housing annual family income must not exceed 900000 rupees per year.")
    result = build_response("What is the annual family income limit?", "en", use_llm=False,
                            document_id="doc-a", document_ids=["doc-a"])
    assert result["evidence"]
    assert {x["document_id"] for x in result["evidence"]} == {"doc-a"}


def test_explicit_multi_document_selection_can_compare_both_documents():
    add_doc("doc-a", "Scholarship", "Scholarship annual family income must not exceed 250000 rupees per year.")
    add_doc("doc-b", "Housing", "Housing annual family income must not exceed 900000 rupees per year.")
    result = build_response("Compare the annual family income limits", "en", use_llm=False,
                            document_ids=["doc-a", "doc-b"])
    assert {x["document_id"] for x in result["evidence"]} == {"doc-a", "doc-b"}


def test_query_api_requires_selected_document_and_respects_answer_language():
    add_doc("doc-hi", "Hindi Scholarship", "Annual family income must not exceed 250000 rupees per year for scholarship applicants.")
    client = TestClient(main.app)
    missing = client.post("/api/query", json={"question": "What is the income limit?", "use_llm": False})
    assert missing.status_code == 422
    response = client.post("/api/query", json={
        "question": "What is the annual family income limit?", "answer_language": "hi",
        "document_id": "doc-hi", "use_llm": False,
    })
    assert response.status_code == 200, response.text
    assert response.json()["language"] == "hi"
    assert response.json()["answer_language"] == "hi"
    assert response.json()["selected_document_ids"] == ["doc-hi"]


def test_query_session_retains_selected_document_for_followups_and_can_switch():
    add_doc("doc-a", "Scholarship", "Scholarship annual family income must not exceed 250000 rupees per year.")
    add_doc("doc-b", "Housing", "Housing annual family income must not exceed 900000 rupees per year.")
    client = TestClient(main.app)
    session_id = client.get("/api/sessions/new").json()["session_id"]
    first = client.post("/api/query", json={"question": "What is the annual family income limit?", "document_id": "doc-a", "session_id": session_id, "use_llm": False})
    assert first.status_code == 200
    followup = client.post("/api/query", json={"question": "What does the document say about income?", "session_id": session_id, "use_llm": False})
    assert followup.status_code == 200
    assert {x["document_id"] for x in followup.json()["evidence"]} == {"doc-a"}
    switched = client.post("/api/query", json={"question": "What is the annual family income limit?", "document_id": "doc-b", "session_id": session_id, "use_llm": False})
    assert switched.status_code == 200
    again = client.post("/api/query", json={"question": "What does this source say about income?", "session_id": session_id, "use_llm": False})
    assert again.status_code == 200
    assert {x["document_id"] for x in again.json()["evidence"]} == {"doc-b"}


def test_deleting_document_removes_it_from_store_and_query_sessions():
    add_doc("delete-me", "Temporary", "A sufficiently long document about a particular grant and its income requirements.")
    store.set_query_session("session-delete-123456", ["delete-me"])
    client = TestClient(main.app)
    response = client.delete("/api/documents/delete-me")
    assert response.status_code == 200
    assert store.get_document("delete-me") is None
    assert store.get_query_session("session-delete-123456") == []


def test_eligibility_api_returns_documented_counts_missing_info_and_citations(monkeypatch):
    add_doc("eligibility-doc", "Scholarship", "Annual family income must not exceed 250000 rupees per year.")
    def fake_extract(evidence, language="en"):
        return {"eligibility_conditions": [{
            "text": "Annual family income must not exceed 250000 rupees per year.",
            "profile_field": "annual_family_income", "operator": "lte", "expected_value": 250000,
            "unit": "INR", "exact_quote": "Annual family income must not exceed 250000 rupees per year.",
            "evidence_id": evidence[0]["evidence_id"], "question_to_ask": "What is your annual family income?",
        }], "analysis_coverage": {"complete": True}}
    monkeypatch.setattr(main, "extract_policy_structure", fake_extract)
    client = TestClient(main.app)
    result = client.post("/api/documents/eligibility-doc/eligibility", json={"profile": {"annual_family_income": 200000}, "answer_language": "en"})
    assert result.status_code == 200, result.text
    payload = result.json()
    assert payload["conditions_found"] == 1
    assert payload["conditions_met"] == 1
    assert payload["conditions_not_met"] == 0
    assert payload["conditions_unknown"] == 0
    assert payload["citations"]
    assert payload["citations"][0]["page"] == 1
    assert "not an official eligibility" in payload["extraction_note"]


def test_refresh_html_source_creates_version_history(monkeypatch):
    url = "https://www.pib.gov.in/versioned-notice"
    bodies = [
        b"<html><head><title>Versioned Notice</title></head><body><main><h1>Section 1</h1><p>Annual family income must not exceed Rs 250000 per year. This is a long enough synthetic policy passage for retrieval.</p></main></body></html>",
        b"<html><head><title>Versioned Notice</title></head><body><main><h1>Section 1</h1><p>Annual family income must not exceed Rs 450000 per year. This is a long enough synthetic policy passage for retrieval.</p></main></body></html>",
    ]
    monkeypatch.setattr(ingestion, "validate_source_url", lambda u: u)
    def fake_get(u):
        body = bodies.pop(0)
        return body, FakeResponse(headers={"Content-Type": "text/html"}, url=u, body=body)
    monkeypatch.setattr(ingestion, "_bounded_get", fake_get)
    first = ingestion.ingest_url(url)
    second = ingestion.ingest_url(url)
    assert first["document_id"] == second["document_id"]
    versions = store.get_document_versions(first["document_id"])
    assert len(versions) == 2
    assert versions[0]["change_kind"] == "SECTION_TEXT_CHANGED_REVIEW_REQUIRED"


def test_timeout_and_oversized_source_are_reported_safely(monkeypatch):
    monkeypatch.setattr(ingestion, "validate_source_url", lambda u: u)
    monkeypatch.setattr(ingestion.requests, "get", lambda *a, **k: (_ for _ in ()).throw(requests.Timeout()))
    with pytest.raises(IngestionError, match="timed out"):
        ingestion._bounded_get("https://www.pib.gov.in/slow")

    monkeypatch.setattr(ingestion, "MAX_SOURCE_BYTES", 10)
    monkeypatch.setattr(ingestion.requests, "get", lambda *a, **k: FakeResponse(headers={"Content-Length": "100"}, body=b"x" * 100))
    with pytest.raises(IngestionError, match="exceeds"):
        ingestion._bounded_get("https://www.pib.gov.in/large")


def test_empty_html_page_is_rejected():
    with pytest.raises(IngestionError, match="too little readable text"):
        ingestion._html_document(b"<html><head><title>Empty</title></head><body><main><p>hi</p></main></body></html>")


def test_user_uploaded_pdf_provenance_is_not_authenticated_official_source():
    result = ingestion.ingest_pdf_upload(make_pdf(1), "citizen-copy.pdf", page_mode="all")
    assert result["provenance"] == "USER_UPLOAD"
    assert result["authority_status"] == "USER_UPLOADED_PUBLISHER_UNVERIFIED"
    registry = TestClient(main.app).get("/api/sources/registry").json()
    uploaded = next(x for x in registry["ingested_documents"] if x["document_id"] == result["document_id"])
    assert uploaded["host_fetch_status"] == "NOT_APPLICABLE_USER_UPLOAD"


def test_eligibility_unknown_conditions_are_counted_and_questioned(monkeypatch):
    add_doc("eligibility-unknown", "Scholarship", "Applicant must be resident of Bihar for this scholarship.")
    def fake_extract(evidence, language="en"):
        return {"eligibility_conditions": [{
            "text": "Applicant must be resident of Bihar", "profile_field": "state", "operator": "eq",
            "expected_value": "Bihar", "unit": "", "exact_quote": "Applicant must be resident of Bihar.",
            "evidence_id": evidence[0]["evidence_id"], "question_to_ask": "Which state do you reside in?",
        }], "analysis_coverage": {"complete": True}}
    monkeypatch.setattr(main, "extract_policy_structure", fake_extract)
    result = TestClient(main.app).post("/api/documents/eligibility-unknown/eligibility", json={"profile": {}})
    assert result.status_code == 200
    payload = result.json()
    assert payload["conditions_unknown"] == 1
    assert payload["missing_user_information"][0]["question_to_ask"] == "Which state do you reside in?"

@pytest.mark.parametrize(
    ("question", "answer_language", "expected"),
    [
        ("What is the income limit?", "en", "en"),
        ("What is the income limit?", "hi", "hi"),
        ("आय सीमा क्या है?", "en", "en"),
        ("आय सीमा क्या है?", "hi", "hi"),
        ("Mujhe scholarship kaise milegi?", "hi", "hi"),
        ("Mujhe scholarship kaise milegi?", "en", "en"),
    ],
)
def test_answer_language_is_independent_for_english_hindi_and_hinglish(question, answer_language, expected):
    from app.policy import detect_language
    assert detect_language(question, answer_language) == expected


def test_same_as_question_detects_english_hindi_and_hinglish():
    from app.policy import detect_language
    assert detect_language("What is the income limit?", "auto") == "en"
    assert detect_language("आय सीमा क्या है?", "auto") == "hi"
    assert detect_language("Mujhe scholarship kaise milegi?", "auto") == "hi"


def test_compound_question_retrieves_evidence_from_multiple_pages_of_one_selected_pdf():
    evidence = [
        {"evidence_id": "p2-c0", "chunk_index": 0, "section": "Eligibility", "page": 2,
         "text": "Eligibility conditions: Applicants must be residents of Bihar and must have completed graduation before applying."},
        {"evidence_id": "p8-c0", "chunk_index": 0, "section": "Income Limit", "page": 8,
         "text": "Annual family income must not exceed Rs 250000 per year for eligible scholarship applicants."},
        {"evidence_id": "p10-c0", "chunk_index": 0, "section": "Required Documents", "page": 10,
         "text": "Required documents include an income certificate, caste certificate and bank passbook."},
    ]
    store.upsert_document({
        "document_id": "multi-page-doc", "title": "Multi-page Scholarship Guideline",
        "source_url": "upload://multi-page-doc", "canonical_url": "", "jurisdiction": "India",
        "issuing_authority": "Not verified", "authority_status": "USER_UPLOADED_PUBLISHER_UNVERIFIED",
        "provenance": "USER_UPLOAD", "freshness": "USER_UPLOADED", "retrieved_at": store.utcnow(),
        "document_date": None, "content_type": "application/pdf", "raw_text": "\n".join(x["text"] for x in evidence),
        "page_count": 10, "selected_pages": [2, 8, 10],
        "processing_report": {"total_pages": 10, "selected_pages": [2, 8, 10], "not_processed_pages": [1, 3, 4, 5, 6, 7, 9], "overall_completeness": False},
        "evidence": evidence,
    })
    result = build_response(
        "Explain the eligibility conditions, income limit and required documents.",
        "en", use_llm=False, document_id="multi-page-doc", document_ids=["multi-page-doc"],
    )
    assert {row["page"] for row in result["evidence"]} == {2, 8, 10}
    assert {cite["page"] for cite in result["citations"]} == {2, 8, 10}
    assert all(cite.get("quote") for cite in result["citations"])
    assert all(cite.get("provenance") == "USER_UPLOAD" for cite in result["citations"])


def test_partial_page_selection_is_document_partial_but_selected_scope_can_be_complete():
    result = ingestion.ingest_pdf_upload(make_pdf(100), "partial-scope.pdf", page_mode="max_page", max_page_number=10)
    report = result["processing_report"]
    assert report["selected_scope_complete"] is True
    assert report["overall_completeness"] is False
    assert report["processing_status"] == "PARTIAL"
    assert report["not_processed_pages"] == list(range(11, 101))


def test_html_text_cap_is_enforced(monkeypatch):
    monkeypatch.setattr(ingestion, "MAX_HTML_CHARS", 100)
    html = ("<html><head><title>Large</title></head><body><main><h1>Policy</h1><p>" +
            ("citizen scheme policy information " * 15) + "</p></main></body></html>").encode()
    monkeypatch.setattr(ingestion, "validate_source_url", lambda u: u)
    monkeypatch.setattr(ingestion, "_bounded_get", lambda u: (html, FakeResponse(headers={"Content-Type": "text/html"}, url=u, body=html)))
    with pytest.raises(IngestionError, match="character safety limit"):
        ingestion.ingest_url("https://www.pib.gov.in/large-html")


def test_query_response_exposes_grounding_and_provenance_fields():
    add_doc("query-schema", "Query schema", "The annual family income must not exceed Rs 250000 per year.")
    response = TestClient(main.app).post("/api/query", json={
        "question": "What is the annual family income limit?", "document_id": "query-schema", "use_llm": False,
    })
    assert response.status_code == 200, response.text
    body = response.json()
    assert "grounding_warnings" in body
    assert "prompt_injection_evidence_ids" in body
    assert "redacted_identifier_types" in body
    assert "authority_statuses" in body
    assert "freshness_statuses" in body
    assert body["citations"][0]["quote"]


def test_document_processing_report_marks_failed_selected_page_as_partial(monkeypatch):
    original = ingestion.fitz.open
    pdf_bytes = make_pdf(3)
    real_pdf = original(stream=pdf_bytes, filetype="pdf")
    # Replace one selected page's text extraction with an exception.
    class PageProxy:
        def __init__(self, page, fail=False):
            self._page = page
            self._fail = fail
        def get_text(self, *args, **kwargs):
            if self._fail:
                raise RuntimeError("simulated extraction failure")
            return self._page.get_text(*args, **kwargs)
        def get_textpage_ocr(self, *args, **kwargs):
            return self._page.get_textpage_ocr(*args, **kwargs)
    class PDFProxy:
        is_encrypted = False
        def __len__(self):
            return len(real_pdf)
        def __getitem__(self, index):
            return PageProxy(real_pdf[index], fail=(index == 1))
        def close(self):
            real_pdf.close()
    monkeypatch.setattr(ingestion.fitz, "open", lambda **kwargs: PDFProxy())
    result = ingestion.ingest_pdf_upload(pdf_bytes, "failed-page.pdf", page_mode="all")
    report = result["processing_report"]
    assert report["processing_status"] == "PARTIAL"
    assert report["overall_completeness"] is False
    assert report["failed_pages"][0]["page"] == 2


def test_crop_loan_question_does_not_retrieve_unrelated_education_loan_document():
    add_doc("education-loan", "Education loan notice", "Education loans are available to students at participating banks. Interest terms depend on the lender and institution.")
    result = build_response("What is the interest rate on crop loans?", "en", use_llm=False,
                            document_id="education-loan", document_ids=["education-loan"])
    assert result["evidence"] == []
    assert result["retrieval_strength"] == "insufficient"


def test_source_registry_has_explicit_authority_and_verification_fields():
    response = TestClient(main.app).get("/api/sources/registry")
    assert response.status_code == 200
    for source in response.json()["sources"]:
        assert "hostname" in source
        assert "authority" in source
        assert "approval_status" in source
        assert "verification_status" in source
        assert "host_fetch_status" in source


def test_direct_pdf_url_api_endpoint_ingests_pages_and_exposes_processing_report(monkeypatch):
    pdf = make_pdf(12)
    url = "https://www.pib.gov.in/guideline-api.pdf"
    monkeypatch.setattr(ingestion, "validate_source_url", lambda value: value)
    monkeypatch.setattr(ingestion, "_bounded_get", lambda value: (pdf, FakeResponse(
        headers={"Content-Type": "application/pdf"}, url=value, body=pdf)))
    response = TestClient(main.app).post("/api/documents/ingest-url", json={
        "url": url, "page_mode": "specific", "selected_pages": [2, 8, 10, 7],
    })
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["content_type"] == "application/pdf"
    assert body["selected_pages"] == [2, 7, 8, 10]
    assert body["processing_report"]["not_processed_pages"] == [1, 3, 4, 5, 6, 9, 11, 12]
    assert body["provenance"] == "HTTP_FETCH"


def test_ingest_url_api_names_unapproved_host_and_requires_admin_approval(monkeypatch):
    monkeypatch.setattr(ingestion, "_validate_public_dns", lambda host: None)
    response = TestClient(main.app).post("/api/documents/ingest-url", json={
        "url": "https://new-host.example/policy.html",
    })
    assert response.status_code == 422
    assert "new-host.example" in response.json()["detail"]
    assert "administrator approval" in response.json()["detail"]


def test_pdf_ocr_fallback_runs_when_tesseract_is_available(monkeypatch):
    import shutil
    if not shutil.which("tesseract"):
        pytest.skip("Tesseract is not installed in this test environment.")
    from PIL import Image, ImageDraw, ImageFont
    import tempfile
    image = Image.new("RGB", (1600, 700), "white")
    draw = ImageDraw.Draw(image)
    font_path = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
    font = ImageFont.truetype(font_path, 54)
    draw.text((70, 120), "Government Policy Income Limit", fill="black", font=font)
    draw.text((70, 230), "Annual household income must not exceed", fill="black", font=font)
    draw.text((70, 340), "Rupees 250000 per year", fill="black", font=font)
    img_io = io.BytesIO()
    image.save(img_io, format="PNG")
    pdf = fitz.open()
    page = pdf.new_page(width=800, height=350)
    page.insert_image(fitz.Rect(0, 0, 800, 350), stream=img_io.getvalue())
    pdf_bytes = pdf.tobytes()
    pdf.close()
    monkeypatch.setattr(ingestion, "OCR_ENABLED", True)
    monkeypatch.setattr(ingestion, "OCR_LANGUAGES", "eng")
    result = ingestion.ingest_pdf_upload(pdf_bytes, "scanned.pdf", page_mode="all")
    report = result["processing_report"]
    assert report["ocr_pages"] == [1]
    assert report["extracted_pages"] == [1]
    assert "250000" in " ".join(x["text"] for x in store.get_all_evidence(document_id=result["document_id"]))


def test_uploaded_documents_do_not_create_fake_host_registry_entries():
    result = ingestion.ingest_pdf_upload(make_pdf(1), "user-upload.pdf", page_mode="all")
    registry = TestClient(main.app).get("/api/sources/registry").json()
    uploaded = next(x for x in registry["ingested_documents"] if x["document_id"] == result["document_id"])
    assert uploaded["hostname"] is None
    assert uploaded["host_fetch_status"] == "NOT_APPLICABLE_USER_UPLOAD"
    assert not any(x["hostname"].startswith("upload-") for x in registry["sources"])


def test_deleting_document_also_deletes_its_version_history():
    add_doc("delete-versioned", "Versioned source", "Annual family income must not exceed 250000 rupees.")
    store.upsert_document({
        "document_id": "delete-versioned", "title": "Versioned source", "source_url": "https://www.pib.gov.in/delete-versioned.pdf",
        "canonical_url": "https://www.pib.gov.in/delete-versioned.pdf", "jurisdiction": "India",
        "issuing_authority": "www.pib.gov.in", "authority_status": "OFFICIAL_DOMAIN_NOT_DOCUMENT_AUTHENTICATED",
        "provenance": "HTTP_FETCH", "freshness": "LIVE", "retrieved_at": store.utcnow(), "document_date": None,
        "content_type": "application/pdf", "raw_text": "Annual family income must not exceed 450000 rupees.",
        "page_count": 1, "evidence": [{"evidence_id": "p1-c0", "chunk_index": 0, "section": "Income", "page": 1, "text": "Annual family income must not exceed 450000 rupees."}],
    })
    assert len(store.get_document_versions("delete-versioned")) == 2
    assert store.delete_document("delete-versioned") is True
    assert store.get_document_versions("delete-versioned") == []


def test_hindi_scanned_pdf_uses_hindi_ocr_when_tesseract_language_pack_available(monkeypatch):
    import shutil
    if not shutil.which("tesseract"):
        pytest.skip("Tesseract is not installed.")
    completed = subprocess.run(["tesseract", "--list-langs"], capture_output=True, text=True, timeout=10)
    if "hin" not in completed.stdout:
        pytest.skip("Tesseract Hindi language data is not installed.")
    from PIL import Image, ImageDraw, ImageFont
    image = Image.new("RGB", (1800, 600), "white")
    draw = ImageDraw.Draw(image)
    font = ImageFont.truetype("/usr/share/fonts/truetype/noto/NotoSansDevanagari-Regular.ttf", 70)
    draw.text((80, 120), "वार्षिक पारिवारिक आय २५०००० रुपये से अधिक नहीं होनी चाहिए", font=font, fill="black")
    draw.text((80, 260), "आवेदक को आय प्रमाण पत्र जमा करना होगा", font=font, fill="black")
    image_bytes = io.BytesIO()
    image.save(image_bytes, format="PNG")
    pdf = fitz.open()
    page = pdf.new_page(width=900, height=300)
    page.insert_image(fitz.Rect(0, 0, 900, 300), stream=image_bytes.getvalue())
    data = pdf.tobytes()
    pdf.close()
    monkeypatch.setattr(ingestion, "OCR_ENABLED", True)
    monkeypatch.setattr(ingestion, "OCR_LANGUAGES", "hin")
    result = ingestion.ingest_pdf_upload(data, "hindi-scan.pdf", page_mode="all")
    text = " ".join(row["text"] for row in store.get_all_evidence(document_id=result["document_id"]))
    assert result["processing_report"]["ocr_pages"] == [1]
    assert "आय" in text and "प्रमाण पत्र" in text


def test_ocr_page_timeout_is_recorded_as_partial_extraction(monkeypatch):
    pdf = fitz.open()
    p1 = pdf.new_page()
    p1.insert_text((50, 70), "This is a readable first page with enough text to pass extraction threshold.")
    p2 = pdf.new_page()
    p2.insert_text((50, 70), "")
    data = pdf.tobytes()
    pdf.close()
    monkeypatch.setattr(ingestion, "OCR_ENABLED", True)
    monkeypatch.setattr(ingestion, "MAX_OCR_PAGES", 10)
    def timeout(_page):
        raise IngestionError("OCR exceeded the 1-second page timeout.")
    monkeypatch.setattr(ingestion, "_ocr_page_with_timeout", timeout)
    result = ingestion.ingest_pdf_upload(data, "ocr-timeout.pdf", page_mode="all")
    report = result["processing_report"]
    assert report["processing_status"] == "PARTIAL"
    assert report["overall_completeness"] is False
    assert report["failed_pages"][0]["page"] == 2


def test_upload_api_defaults_to_first_ten_pages_for_long_pdf():
    response = TestClient(main.app).post("/api/documents/upload", files={
        "file": ("hundred-pages.pdf", make_pdf(100), "application/pdf"),
    })
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["selected_pages"] == list(range(1, 11))
    assert body["processing_report"]["selected_scope_complete"] is True
    assert body["processing_report"]["overall_completeness"] is False
    assert body["processing_report"]["not_processed_pages"] == list(range(11, 101))


def test_specific_page_selection_deduplicates_and_sorts_pages():
    result = ingestion.ingest_pdf_upload(make_pdf(10), "duplicates.pdf", page_mode="specific", selected_pages="10,2,8,2,7,8")
    assert result["selected_pages"] == [2, 7, 8, 10]


@pytest.mark.parametrize(
    ("question", "answer_language", "expected"),
    [
        ("What is the annual family income limit?", "en", "en"),
        ("What is the annual family income limit?", "hi", "hi"),
        ("आय सीमा क्या है?", "en", "en"),
        ("आय सीमा क्या है?", "hi", "hi"),
        ("Mujhe scholarship kaise milegi?", "hi", "hi"),
        ("Mujhe scholarship kaise milegi?", "en", "en"),
    ],
)
def test_query_api_answer_language_preference_matrix(question, answer_language, expected):
    add_doc("language-matrix", "Language test", "Annual family income must not exceed 250000 rupees per year. Scholarship applicants must submit an income certificate.")
    response = TestClient(main.app).post("/api/query", json={
        "question": question, "answer_language": answer_language,
        "document_id": "language-matrix", "use_llm": False,
    })
    assert response.status_code == 200, response.text
    assert response.json()["language"] == expected
    assert response.json()["answer_language"] == expected


def test_additive_migration_adds_phase2_columns_and_registry_tables_to_v9_database(tmp_path, monkeypatch):
    import sqlite3
    old_db = tmp_path / "v9-existing.sqlite3"
    with sqlite3.connect(old_db) as conn:
        conn.execute("""CREATE TABLE documents (
            document_id TEXT PRIMARY KEY, title TEXT NOT NULL, source_url TEXT NOT NULL,
            canonical_url TEXT, jurisdiction TEXT, issuing_authority TEXT,
            authority_status TEXT NOT NULL, provenance TEXT NOT NULL, freshness TEXT NOT NULL,
            retrieved_at TEXT NOT NULL, document_date TEXT, content_type TEXT,
            raw_hash TEXT NOT NULL, normalized_hash TEXT NOT NULL, raw_text TEXT NOT NULL,
            page_count INTEGER NOT NULL DEFAULT 0, extraction_note TEXT
        )""")
    monkeypatch.setattr(store, "DB_FILE", old_db)
    store.init_db()
    with sqlite3.connect(old_db) as conn:
        columns = {row[1] for row in conn.execute("PRAGMA table_info(documents)")}
        tables = {row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    assert {"processing_report_json", "selected_pages_json"} <= columns
    assert {"source_registry", "query_sessions"} <= tables


def test_admin_approved_non_government_host_does_not_get_government_authority_label(monkeypatch):
    pdf = make_pdf(1)
    url = "https://research.example/policy.pdf"
    monkeypatch.setattr(ingestion, "validate_source_url", lambda value: value)
    monkeypatch.setattr(ingestion, "_bounded_get", lambda value: (pdf, FakeResponse(
        headers={"Content-Type": "application/pdf"}, url=value, body=pdf)))
    result = ingestion.ingest_url(url, page_mode="all")
    assert result["authority_status"] == "ALLOWLISTED_HOST_NOT_GOVERNMENT_VERIFIED"
    assert result["provenance"] == "HTTP_FETCH"
