"""V10 UI final-pass regression tests.

Covers the collapsible allowed-source disclosure, the ingest -> active document -> ask
workflow, page selection, answer language, example questions, safe citation rendering,
responsive overflow, and a real-backend browser journey (live Uvicorn, real PDFs, BM25,
no external LLM).
"""
from __future__ import annotations

import socket
import threading
import time

import fitz
import pytest

from app import llm, main
from tests.test_phase3_frontend import _mock_api, browser_page, isolated_database  # noqa: F401  (pytest fixtures)


def _wait_ready(page):
    page.wait_for_function('!!document.querySelector("#selectedDoc option[value=doc-a]")')
    page.wait_for_function("document.querySelector('#sourceList').textContent.includes('dynamic-only')")


# 1. Source registry collapsed by default -------------------------------------------------
def test_source_registry_is_collapsed_by_default(browser_page):
    page = browser_page
    _mock_api(page)
    _wait_ready(page)
    assert page.locator("#registryToggle").get_attribute("aria-expanded") == "false"
    assert page.locator("#registryPanel").get_attribute("id") == page.locator("#registryToggle").get_attribute("aria-controls")
    assert not page.locator("#sourceList").is_visible()
    assert not page.locator("#adminHost").is_visible()
    # Collapsed row is compact.
    assert page.locator("#registryCard").bounding_box()["height"] < 90
    # Data was still loaded from the (mocked) backend API, not hardcoded.
    assert any(c["path"] == "/api/sources/registry" for c in page.evaluate("window.__apiCalls"))
    assert "1 host" in page.locator("#registryCount").inner_text()


# 2. Opens on click ------------------------------------------------------------------------
def test_source_registry_opens_on_click_and_shows_backend_data(browser_page):
    page = browser_page
    _mock_api(page)
    _wait_ready(page)
    page.locator("#registryToggle").click()
    assert page.locator("#registryToggle").get_attribute("aria-expanded") == "true"
    page.wait_for_selector("#sourceList", state="visible")
    text = page.locator("#sourceList").inner_text()
    assert "dynamic-only.example.gov.in" in text and "Dynamic Mock Authority" in text
    assert "pib.gov.in" not in text
    assert page.locator("#reloadRegistryBtn").is_visible()


# 3. Closes on second click (and works from the keyboard) ----------------------------------
def test_source_registry_closes_on_second_click_and_keyboard_toggle(browser_page):
    page = browser_page
    _mock_api(page)
    _wait_ready(page)
    page.locator("#registryToggle").click()
    page.wait_for_selector("#sourceList", state="visible")
    page.locator("#registryToggle").click()
    assert page.locator("#registryToggle").get_attribute("aria-expanded") == "false"
    page.wait_for_selector("#sourceList", state="hidden")
    page.locator("#registryToggle").focus()
    page.keyboard.press("Enter")
    assert page.locator("#registryToggle").get_attribute("aria-expanded") == "true"
    page.keyboard.press("Space")
    assert page.locator("#registryToggle").get_attribute("aria-expanded") == "false"


def test_typing_or_rejected_url_does_not_auto_expand_registry(browser_page):
    page = browser_page
    _mock_api(page, reject_url=True)
    _wait_ready(page)
    page.locator("#sourceUrl").fill("https://unknown.example.gov.in/policy")
    assert page.locator("#registryToggle").get_attribute("aria-expanded") == "false"
    page.locator("#ingestUrlBtn").click()
    page.wait_for_function("document.querySelector('#urlMessage').textContent.includes('unknown.example.gov.in')")
    msg = page.locator("#urlMessage").inner_text()
    assert "Administrator approval is required" in msg
    assert "never approves a host automatically" in msg
    assert page.locator("#registryToggle").get_attribute("aria-expanded") == "false"
    assert page.locator("#selectedDoc").input_value() == ""
    assert not any(c["path"].startswith("/api/admin/") for c in page.evaluate("window.__apiCalls"))


# 4 + 6. Question panel available after ingestion; new source becomes active ---------------
def test_question_panel_unlocks_and_new_upload_becomes_active(browser_page):
    page = browser_page
    _mock_api(page)
    _wait_ready(page)
    page.locator("#selectedDoc").select_option("doc-b")
    page.set_input_files("#pdfFile", {"name": "hundred-pages.pdf", "mimeType": "application/pdf", "buffer": b"%PDF-1.7 mock"})
    page.wait_for_selector("#pdfPreview:not(.hidden)")
    page.locator("#uploadBtn").click()
    page.wait_for_function("document.querySelector('#selectedDoc').value === 'doc-a'")
    assert "success" in page.locator("#pdfMessage").get_attribute("class")
    assert page.locator("#askCard.ready").count() == 1
    assert page.locator("#question").is_enabled() and page.locator("#askBtn").is_enabled()
    assert page.locator("#question").is_visible()
    assert page.locator("#activeDocTitle").inner_text() == "Guideline A"
    assert not page.locator("#askLock").is_visible()
    # Workspace sits directly below ingestion + registry disclosure, above the secondary tools.
    order = page.evaluate("""['pdfCard','registryCard','askCard','reportCard','libraryCard','analysisCard','eligibilityCard','versionsCard']
        .map(id => document.getElementById(id).getBoundingClientRect().top + window.scrollY)""")
    assert order[0] < order[1] < order[2] < min(order[3:])


def test_website_ingestion_becomes_active_document(browser_page):
    page = browser_page
    _mock_api(page)
    _wait_ready(page)
    page.locator("#sourceUrl").fill("https://dynamic-only.example.gov.in/guide.pdf")
    page.locator("#ingestUrlBtn").click()
    page.wait_for_function("document.querySelector('#selectedDoc').value === 'doc-url'")
    assert page.locator("#activeDocTitle").inner_text() == "Direct PDF URL"
    assert page.locator("#question").is_enabled()
    assert "now the active document" in page.locator("#urlMessage").inner_text()


# 5. Unavailable without an active document ----------------------------------------------
def test_question_panel_unavailable_without_active_document(browser_page):
    page = browser_page
    _mock_api(page)
    _wait_ready(page)
    assert page.locator("#selectedDoc").input_value() == ""
    assert page.locator("#question").is_disabled()
    assert page.locator("#askBtn").is_disabled()
    assert page.locator("#askLock").is_visible()
    assert page.locator("#askCard.ready").count() == 0
    assert page.locator("#activeKicker").text_content() == "No document selected"
    page.locator("#selectedDoc").select_option("doc-a")
    assert page.locator("#question").is_enabled()
    page.locator("#selectedDoc").select_option("")
    assert page.locator("#question").is_disabled() and page.locator("#askBtn").is_disabled()


def test_failed_upload_does_not_present_document_as_active(browser_page):
    page = browser_page
    _mock_api(page)
    _wait_ready(page)
    page.evaluate("""(() => { const f = window.fetch; window.fetch = async (input, init = {}) => {
        const p = new URL(typeof input === 'string' ? input : input.url, document.baseURI).pathname;
        if (p === '/api/documents/upload') return new Response(JSON.stringify({detail:'PDF could not be processed.'}), {status:422, headers:{'Content-Type':'application/json'}});
        return f(input, init); }; })()""")
    page.set_input_files("#pdfFile", {"name": "hundred-pages.pdf", "mimeType": "application/pdf", "buffer": b"%PDF-1.7 mock"})
    page.wait_for_selector("#pdfPreview:not(.hidden)")
    page.locator("#uploadBtn").click()
    page.wait_for_function("document.querySelector('#pdfMessage').classList.contains('error')")
    assert page.locator("#selectedDoc").input_value() == ""
    assert page.locator("#question").is_disabled()


# 7. Page-selection inputs remain functional ---------------------------------------------
def test_page_selection_inputs_remain_functional(browser_page):
    page = browser_page
    _mock_api(page)
    _wait_ready(page)
    assert page.locator("#uploadBtn").is_disabled()  # disabled until the PDF is inspected
    page.set_input_files("#pdfFile", {"name": "hundred-pages.pdf", "mimeType": "application/pdf", "buffer": b"%PDF-1.7 mock"})
    page.wait_for_selector("#pdfPreview:not(.hidden)")
    assert "100 pages detected" in page.locator("#pdfPreview").inner_text()
    assert page.locator("#maxPageNumber").input_value() == "10"
    assert page.locator("#maxPageNumber").get_attribute("max") == "100"
    page.locator('input[name="pageMode"][value="specific"]').check()
    assert page.locator("#specificPages").is_visible() and not page.locator("#maxPageNumber").is_visible()
    page.locator('input[name="pageMode"][value="all"]').check()
    assert page.locator("#allPagesNote").is_visible() and not page.locator("#specificPages").is_visible()
    page.locator("#uploadBtn").click()
    page.wait_for_function("window.__apiCalls.some(x => x.path === '/api/documents/upload')")
    upload = next(x for x in page.evaluate("window.__apiCalls") if x["path"] == "/api/documents/upload")
    assert upload["body"]["page_mode"] == "all"
    # Out-of-range max page is still rejected client-side.
    page.locator('input[name="pageMode"][value="max_page"]').check()
    page.locator("#maxPageNumber").fill("101")
    page.locator("#uploadBtn").click()
    page.wait_for_function("document.querySelector('#pdfMessage').textContent.includes('exceeds the PDF page count')")


# 8. Answer language selection + document switching --------------------------------------
def test_answer_language_and_document_switching_send_correct_request(browser_page):
    page = browser_page
    _mock_api(page)
    _wait_ready(page)
    page.locator("#selectedDoc").select_option("doc-a")
    page.locator("#question").fill("आय सीमा क्या है?")
    page.locator("#answerLanguage").select_option("en")
    page.locator("#askBtn").click()
    page.wait_for_selector("#answerPanel:not(.hidden)")
    page.locator("#selectedDoc").select_option("doc-b")
    assert page.locator("#answerPanel").is_hidden()  # stale answer from doc A is cleared
    assert page.locator("#activeDocTitle").inner_text() == "Guideline B"
    page.locator("#question").fill("What is the income limit?")
    page.locator("#answerLanguage").select_option("hi")
    page.locator("#askBtn").click()
    page.wait_for_function("window.__apiCalls.filter(x => x.path === '/api/query').length === 2")
    q1, q2 = [x for x in page.evaluate("window.__apiCalls") if x["path"] == "/api/query"]
    assert (q1["body"]["document_id"], q1["body"]["answer_language"]) == ("doc-a", "en")
    assert (q2["body"]["document_id"], q2["body"]["answer_language"]) == ("doc-b", "hi")


# 9. Example questions populate the input -------------------------------------------------
def test_example_questions_populate_input_across_categories(browser_page):
    page = browser_page
    _mock_api(page)
    _wait_ready(page)
    page.locator("#selectedDoc").select_option("doc-a")
    page.locator('#suggestCats [role="tab"]', has_text="Eligibility").click()
    page.locator('[data-suggestion="What is the income limit?"]').click()
    assert page.locator("#question").input_value() == "What is the income limit?"
    page.locator('#suggestCats [role="tab"]', has_text="Documents").click()
    assert not page.locator('[data-suggestion="What is the income limit?"]').is_visible()
    page.locator('[data-suggestion="Which documents must I submit?"]').click()
    assert page.locator("#question").input_value() == "Which documents must I submit?"
    assert page.locator("[data-suggestion]").count() == 20  # every original example is preserved


# 10. Evidence citations render safely as plain text --------------------------------------
def test_evidence_citations_render_as_plain_text(browser_page):
    page = browser_page
    _mock_api(page, malicious_quote=True)
    _wait_ready(page)
    page.locator("#selectedDoc").select_option("doc-a")
    page.locator("#question").fill("What is the income limit?")
    page.locator("#askBtn").click()
    page.wait_for_selector("#answerPanel:not(.hidden)")
    assert page.locator("#citations img").count() == 0
    assert page.evaluate("window.__xssExecuted || false") is False
    text = page.locator("#citations").inner_text()
    assert '<img id="xss-probe"' in text
    assert "Original PDF page 8" in text
    assert "1 supporting passage" in page.locator("#evidenceStatus").inner_text()


def test_layout_has_no_horizontal_overflow_at_common_widths(browser_page):
    page = browser_page
    _mock_api(page)
    _wait_ready(page)
    for width in (1440, 1024, 820, 390):
        page.set_viewport_size({"width": width, "height": 900})
        page.wait_for_timeout(100)
        assert page.evaluate("document.documentElement.scrollWidth") <= width, width
    # Ingestion cards sit side-by-side on desktop and stack on mobile.
    page.set_viewport_size({"width": 1440, "height": 900})
    a, b = page.locator("#pdfCard").bounding_box(), page.locator("#websiteCard").bounding_box()
    assert abs(a["y"] - b["y"]) < 2 and abs(a["height"] - b["height"]) < 2
    page.set_viewport_size({"width": 390, "height": 900})
    a, b = page.locator("#pdfCard").bounding_box(), page.locator("#websiteCard").bounding_box()
    assert b["y"] > a["y"] + a["height"] - 1


def test_reduced_motion_is_respected(browser_page):
    page = browser_page
    page.emulate_media(reduced_motion="reduce")
    _mock_api(page)
    _wait_ready(page)
    duration = page.evaluate("getComputedStyle(document.querySelector('#registryPanel')).transitionDuration")
    assert all(float(d.strip().rstrip("s") or 0) < 0.01 for d in duration.split(","))


# Real backend end-to-end (Scenarios 1, 5 and 6 without an external LLM) -------------------
def _pdf(pages: int, label: str, income_unit: int) -> bytes:
    doc = fitz.open()
    for n in range(1, pages + 1):
        page = doc.new_page()
        page.insert_text((55, 70), f"{label} Section {n}. Annual family income must not exceed Rs {n * income_unit}. "
                                   f"Applicants under {label} must submit an income certificate.", fontsize=9)
    data = doc.tobytes()
    doc.close()
    return data


@pytest.fixture
def live_server(monkeypatch):
    import uvicorn
    monkeypatch.setattr(llm, "LLM_API_KEY", "")
    monkeypatch.setattr(main, "LLM_API_KEY", "", raising=False)
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        port = s.getsockname()[1]
    server = uvicorn.Server(uvicorn.Config(main.app, host="127.0.0.1", port=port, log_level="warning"))
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()
    deadline = time.time() + 10
    while not server.started and time.time() < deadline:
        time.sleep(0.05)
    if not server.started:
        pytest.skip("Could not start a local Uvicorn server for the end-to-end browser test.")
    yield f"http://127.0.0.1:{port}"
    server.should_exit = True
    thread.join(timeout=5)


def test_real_backend_upload_activate_ask_and_switch(browser_page, live_server, tmp_path):
    page = browser_page
    a, b = tmp_path / "SchemeAlpha.pdf", tmp_path / "SchemeBeta.pdf"
    a.write_bytes(_pdf(100, "Alpha", 50000))
    b.write_bytes(_pdf(12, "Beta", 7000))
    page.goto(live_server + "/")
    page.wait_for_function("document.querySelector('#serverBadge').textContent.includes('Server ok')")
    assert page.locator("#registryToggle").get_attribute("aria-expanded") == "false"
    assert page.locator("#question").is_disabled()

    # Scenario 1: 100-page PDF, default 10, adjust, process, auto-activate, ask, page citations.
    page.set_input_files("#pdfFile", str(a))
    page.wait_for_selector("#pdfPreview:not(.hidden)")
    assert "100 pages detected" in page.locator("#pdfPreview").inner_text()
    assert page.locator("#maxPageNumber").input_value() == "10"
    page.locator("#maxPageNumber").fill("12")
    page.locator("#uploadBtn").click()
    page.wait_for_function("document.querySelector('#activeDocTitle').textContent === 'SchemeAlpha.pdf'", timeout=30000)
    assert page.locator("#question").is_enabled()
    alpha_id = page.locator("#selectedDoc").input_value()
    assert alpha_id
    page.locator("#question").fill("What is the annual family income limit?")
    page.locator("#answerLanguage").select_option("en")
    with page.expect_response(lambda r: r.url.endswith("/api/query")) as resp:
        page.locator("#askBtn").click()
    data = resp.value.json()
    assert data["answer_language"] == "en"
    assert data["selected_document_ids"] == [alpha_id]
    page.wait_for_selector("#answerPanel:not(.hidden)")
    cites = page.locator("#citations").inner_text()
    assert "Original PDF page" in cites and "SchemeAlpha.pdf" in cites and "SchemeBeta" not in cites

    # Scenario 6: second PDF becomes active; switching changes the queried document.
    page.set_input_files("#pdfFile", str(b))
    page.wait_for_selector("#pdfPreview:not(.hidden)")
    page.wait_for_function("document.querySelector('#pdfPreview').textContent.includes('12 pages detected')")
    page.locator("#uploadBtn").click()
    page.wait_for_function("document.querySelector('#activeDocTitle').textContent === 'SchemeBeta.pdf'", timeout=30000)
    beta_id = page.locator("#selectedDoc").input_value()
    assert beta_id and beta_id != alpha_id

    page.locator("#selectedDoc").select_option(alpha_id)
    page.locator("#question").fill("What is the income limit?")
    with page.expect_response(lambda r: r.url.endswith("/api/query")) as resp_a:
        page.locator("#askBtn").click()
    assert resp_a.value.json()["selected_document_ids"] == [alpha_id]
    page.wait_for_selector("#answerPanel:not(.hidden)")
    assert "SchemeBeta" not in page.locator("#citations").inner_text()

    page.locator("#selectedDoc").select_option(beta_id)
    # Scenario 5 (frontend + extractive backend path): Hindi question, English answer language requested.
    page.locator("#question").fill("आय सीमा क्या है? income limit")
    page.locator("#answerLanguage").select_option("en")
    with page.expect_response(lambda r: r.url.endswith("/api/query")) as resp_b:
        page.locator("#askBtn").click()
    body_b = resp_b.value.json()
    assert body_b["selected_document_ids"] == [beta_id]
    assert body_b["answer_language"] == "en"
    page.wait_for_selector("#answerPanel:not(.hidden)")
    cites_b = page.locator("#citations").inner_text()
    assert "SchemeBeta.pdf" in cites_b and "SchemeAlpha" not in cites_b
