from __future__ import annotations

import io
import json
import socket

import fitz
import pytest
from fastapi.testclient import TestClient

from app import store
from app.ingestion import IngestionError, ingest_pdf_upload, ingest_url, validate_source_url
from app.llm import GroundingError, validate_grounded_payload
from app.policy import build_response
from app.rules import evaluate_conditions


@pytest.fixture(autouse=True)
def isolated_db(tmp_path, monkeypatch):
    monkeypatch.setattr(store, "DB_FILE", tmp_path / "test.sqlite3")
    store.init_db()
    yield


def make_pdf(text: str = "Section 4. Eligibility. Applicant must be a resident of Bihar. Annual family income must not exceed 250000. Submit the application before 31 December 2026.") -> bytes:
    doc = fitz.open()
    page = doc.new_page()
    page.insert_text((72, 72), text)
    data = doc.tobytes()
    doc.close()
    return data


def save_test_doc(doc_id="doc-test", text="A student must be a resident of Bihar. Annual family income must not exceed 250000.", freshness="LIVE"):
    from app.ingestion import _split_page_text
    store.upsert_document({
        "document_id": doc_id, "title": "Test official source", "source_url": "https://test.gov.in/policy.pdf",
        "canonical_url": "https://test.gov.in/policy.pdf", "jurisdiction": "Bihar",
        "issuing_authority": "test.gov.in", "authority_status": "OFFICIAL_DOMAIN_NOT_DOCUMENT_AUTHENTICATED",
        "provenance": "HTTP_FETCH", "freshness": freshness, "retrieved_at": store.utcnow(),
        "document_date": None, "content_type": "application/pdf", "raw_text": text,
        "page_count": 1, "evidence": _split_page_text(text, 1),
    })


def test_database_starts_empty_and_does_not_load_static_snapshots():
    store.mark_previous_live_as_cached()
    assert store.get_documents() == []
    assert store.get_all_evidence() == []


def test_pdf_upload_creates_page_cited_evidence_and_unverified_provenance():
    result = ingest_pdf_upload(make_pdf(), "test-guideline.pdf", "Bihar")
    assert result["freshness"] == "USER_UPLOADED"
    assert result["authority_status"] == "USER_UPLOADED_PUBLISHER_UNVERIFIED"
    rows = store.get_all_evidence(document_id=result["document_id"])
    assert rows and rows[0]["page"] == 1
    assert "Bihar" in rows[0]["text"]


def test_pdf_upload_rejects_non_pdf_bytes():
    with pytest.raises(IngestionError, match="signature"):
        ingest_pdf_upload(b"not a pdf", "fake.pdf")


def test_pdf_upload_rejects_oversized_upload(monkeypatch):
    from app import ingestion
    monkeypatch.setattr(ingestion, "MAX_UPLOAD_BYTES", 100)
    with pytest.raises(IngestionError, match="limit"):
        ingest_pdf_upload(b"%PDF-" + b"x" * 150, "large.pdf")


def test_scanned_or_empty_pdf_is_not_silently_treated_as_parsed():
    doc = fitz.open()
    doc.new_page()
    data = doc.tobytes()
    doc.close()
    with pytest.raises(IngestionError, match="No extractable text"):
        ingest_pdf_upload(data, "blank.pdf")


def test_url_validation_requires_https_and_exact_allowlisted_host(monkeypatch):
    monkeypatch.setattr("app.ingestion.socket.getaddrinfo", lambda *a, **k: [(None, None, None, None, ("8.8.8.8", 443))])
    assert validate_source_url("https://www.pib.gov.in/example") == "https://www.pib.gov.in/example"
    with pytest.raises(IngestionError, match="Only HTTPS"):
        validate_source_url("http://www.pib.gov.in/example")
    with pytest.raises(IngestionError, match="not allowlisted"):
        validate_source_url("https://evil.example/file.pdf")


def test_url_validation_blocks_private_ip_dns(monkeypatch):
    monkeypatch.setattr("app.ingestion.socket.getaddrinfo", lambda *a, **k: [(None, None, None, None, ("127.0.0.1", 443))])
    with pytest.raises(IngestionError, match="non-public"):
        validate_source_url("https://www.pib.gov.in/example")


def test_url_fetch_follows_only_revalidated_allowlisted_redirects(monkeypatch):
    from urllib.parse import urlparse
    from app import ingestion

    class Response:
        def __init__(self, status_code, headers=None, url="https://www.pib.gov.in/file.pdf"):
            self.status_code = status_code
            self.headers = headers or {}
            self.url = url
        def close(self): pass
        def iter_content(self, chunk_size=0): yield b"safe-content"
        def raise_for_status(self): pass

    calls = []
    def validate(url):
        parsed = urlparse(url)
        if parsed.scheme != "https" or parsed.hostname != "www.pib.gov.in":
            raise IngestionError("redirect destination not allowlisted")
        return url
    responses = [
        Response(302, {"Location": "/official.pdf"}),
        Response(200, {"Content-Length": "12"}, "https://www.pib.gov.in/official.pdf"),
    ]
    def get(url, **kwargs):
        calls.append((url, kwargs.get("allow_redirects")))
        return responses.pop(0)
    monkeypatch.setattr(ingestion, "validate_source_url", validate)
    monkeypatch.setattr(ingestion.requests, "get", get)
    data, response = ingestion._bounded_get("https://www.pib.gov.in/file.pdf")
    assert data == b"safe-content"
    assert len(calls) == 2 and all(x[1] is False for x in calls)


def test_url_fetch_blocks_redirect_to_non_allowlisted_host(monkeypatch):
    from urllib.parse import urlparse
    from app import ingestion

    class Response:
        status_code = 302
        headers = {"Location": "https://evil.example/admin"}
        def close(self): pass

    def validate(url):
        parsed = urlparse(url)
        if parsed.scheme != "https" or parsed.hostname != "www.pib.gov.in":
            raise IngestionError("redirect destination not allowlisted")
        return url
    calls = []
    monkeypatch.setattr(ingestion, "validate_source_url", validate)
    monkeypatch.setattr(ingestion.requests, "get", lambda *a, **k: (calls.append(a[0]) or Response()))
    with pytest.raises(IngestionError, match="not allowlisted"):
        ingestion._bounded_get("https://www.pib.gov.in/file.pdf")
    assert len(calls) == 1


def test_live_url_ingestion_stores_true_live_provenance(monkeypatch):
    from app import ingestion

    class Response:
        status_code = 200
        url = "https://www.pib.gov.in/policy.pdf"
        headers = {"Content-Type": "application/pdf", "Content-Length": str(len(make_pdf()))}
        def iter_content(self, chunk_size=0): yield make_pdf()
        def close(self): pass
        def raise_for_status(self): pass

    monkeypatch.setattr(ingestion, "validate_source_url", lambda u: u)
    monkeypatch.setattr(ingestion.requests, "get", lambda *a, **k: Response())
    result = ingest_url("https://www.pib.gov.in/policy.pdf")
    assert result["freshness"] == "LIVE"
    assert result["provenance"] == "HTTP_FETCH"
    assert store.get_documents()[0]["freshness"] == "LIVE"


def test_evidence_ids_are_namespaced_and_do_not_collide():
    from app.ingestion import _split_page_text
    for doc_id in ("doc-a", "doc-b"):
        store.upsert_document({
            "document_id": doc_id, "title": doc_id, "source_url": "upload://" + doc_id,
            "authority_status": "USER_UPLOADED_PUBLISHER_UNVERIFIED", "provenance": "USER_UPLOAD",
            "freshness": "USER_UPLOADED", "raw_text": "Same text for both documents, long enough to be indexed and retrieved.",
            "evidence": _split_page_text("Same text for both documents, long enough to be indexed and retrieved.", 1),
        })
    rows = store.get_all_evidence()
    assert len(rows) == 2
    assert len({x["evidence_id"] for x in rows}) == 2


def test_whitespace_only_change_does_not_create_new_version():
    base = {
        "document_id": "doc-v", "title": "Version test", "source_url": "https://www.pib.gov.in/x",
        "authority_status": "OFFICIAL_DOMAIN_NOT_DOCUMENT_AUTHENTICATED", "provenance": "HTTP_FETCH",
        "freshness": "LIVE", "evidence": [],
    }
    store.upsert_document({**base, "raw_text": "Section 1\n\nA rule applies."})
    store.upsert_document({**base, "raw_text": "Section 1   A rule applies."})
    versions = store.get_document_versions("doc-v")
    assert len(versions) == 1
    assert versions[0]["change_kind"] == "BASELINE"


def test_substantive_text_change_creates_review_flag_not_legal_amendment():
    base = {
        "document_id": "doc-v", "title": "Version test", "source_url": "https://www.pib.gov.in/x",
        "authority_status": "OFFICIAL_DOMAIN_NOT_DOCUMENT_AUTHENTICATED", "provenance": "HTTP_FETCH",
        "freshness": "LIVE", "evidence": [],
    }
    store.upsert_document({**base, "raw_text": "Section 1. Applicants must be under 25 years of age."})
    store.upsert_document({**base, "raw_text": "Section 1. Applicants must be under 30 years of age."})
    versions = store.get_document_versions("doc-v")
    assert len(versions) == 2
    assert versions[0]["change_kind"] == "SECTION_TEXT_CHANGED_REVIEW_REQUIRED"
    assert "CHANGED Section 1" in versions[0]["change_summary"]
    assert "not automatically a legal amendment" in versions[0]["change_summary"]


def test_bm25_retrieval_changes_with_query_and_cites_source():
    save_test_doc("doc-scholarship", "Scholarship eligibility requires a Bihar resident. Annual family income must not exceed 250000.")
    save_test_doc("doc-farmer", "Crop insurance is available under notified crop and season conditions for eligible cultivators.")
    from app.retrieval import retrieve
    scholarship = retrieve("scholarship income limit Bihar", k=5)
    farmer = retrieve("crop insurance cultivator", k=5)
    assert scholarship and farmer
    assert scholarship[0]["document_id"] == "doc-scholarship"
    assert farmer[0]["document_id"] == "doc-farmer"
    assert scholarship[0]["retrieval_method"] == "cached_bm25_informative_coverage"


def test_query_fallback_is_extract_only_and_not_a_hardcoded_scheme_answer():
    save_test_doc()
    result = build_response("What does this policy say about family income?", "en", use_llm=False)
    assert result["evidence"]
    assert "250000" in result["answer"]
    assert result["llm_used"] is False
    assert result["citations"]
    assert result["workflow"][-1]["step"] == "render_answer"


def test_query_does_not_answer_from_user_upload_in_live_required_mode():
    ingest_pdf_upload(make_pdf(), "user.pdf")
    result = build_response("What does the document say about income?", "en", use_llm=False, require_live_sources=True)
    assert result["retrieval_strength"] == "insufficient"
    assert not result["evidence"]


def test_query_returns_insufficient_for_unrelated_question():
    save_test_doc()
    result = build_response("What is the weather forecast in Tokyo?", "en", use_llm=False)
    assert result["retrieval_strength"] == "insufficient"
    assert not result["citations"]


def test_grounding_validator_accepts_exact_quote_and_matching_numbers():
    ev = [{"evidence_id": "doc-a::p1-c0", "text": "Annual family income must not exceed ₹2,50,000 per year."}]
    payload = {
        "simple_answer": "The source says annual family income must not exceed ₹2,50,000.",
        "summary_evidence": [{"evidence_id": "doc-a::p1-c0", "quote": "Annual family income must not exceed ₹2,50,000 per year."}],
        "claims": [{"text": "Annual family income must not exceed ₹2,50,000 per year.", "evidence": [{"evidence_id": "doc-a::p1-c0", "quote": "Annual family income must not exceed ₹2,50,000 per year."}]}],
        "unknowns": [], "next_steps": [],
    }
    checked = validate_grounded_payload(payload, ev)
    assert checked["claims"][0]["evidence_ids"] == ["doc-a::p1-c0"]


def test_grounding_validator_rejects_fake_citation():
    ev = [{"evidence_id": "doc-a::p1-c0", "text": "Annual family income must not exceed 250000."}]
    payload = {
        "simple_answer": "The limit is 250000.",
        "summary_evidence": [{"evidence_id": "doc-a::p1-c0", "quote": "The limit is 250000."}],
        "claims": [{"text": "Limit is 250000.", "evidence": [{"evidence_id": "FAKE", "quote": "Limit is 250000."}]}],
    }
    with pytest.raises(GroundingError):
        validate_grounded_payload(payload, ev)


def test_grounding_validator_rejects_quote_not_in_source():
    ev = [{"evidence_id": "doc-a::p1-c0", "text": "Annual family income must not exceed 250000."}]
    payload = {
        "simple_answer": "The scholarship pays 50000.",
        "summary_evidence": [{"evidence_id": "doc-a::p1-c0", "quote": "The scholarship pays 50000."}],
        "claims": [{"text": "The scholarship pays 50000.", "evidence": [{"evidence_id": "doc-a::p1-c0", "quote": "The scholarship pays 50000."}]}],
    }
    with pytest.raises(GroundingError):
        validate_grounded_payload(payload, ev)


def test_grounding_validator_rejects_numeric_hallucination():
    ev = [{"evidence_id": "doc-a::p1-c0", "text": "The amount is 15000."}]
    payload = {
        "simple_answer": "The amount is 25000.",
        "summary_evidence": [{"evidence_id": "doc-a::p1-c0", "quote": "The amount is 15000."}],
        "claims": [{"text": "The amount is 25000.", "evidence": [{"evidence_id": "doc-a::p1-c0", "quote": "The amount is 15000."}]}],
    }
    with pytest.raises(GroundingError, match="numeric"):
        validate_grounded_payload(payload, ev)


def test_rules_engine_returns_met_not_met_and_unknown():
    conditions = [
        {"text": "Income <= 250000", "profile_field": "annual_family_income", "operator": "lte", "expected_value": 250000, "evidence_id": "E1", "exact_quote": "income <= 250000"},
        {"text": "State = Bihar", "profile_field": "state", "operator": "eq", "expected_value": "Bihar", "evidence_id": "E2", "exact_quote": "resident of Bihar"},
        {"text": "Age <= 25", "profile_field": "age", "operator": "lte", "expected_value": 25, "evidence_id": "E3", "exact_quote": "age must not exceed 25"},
    ]
    result = evaluate_conditions(conditions, {"annual_family_income": 300000, "state": "Bihar"})
    assert result["conditions"][0]["status"] == "NOT_MET"
    assert result["conditions"][1]["status"] == "MET"
    assert result["conditions"][2]["status"] == "UNKNOWN"
    assert result["overall_status"] == "ONE_OR_MORE_EXTRACTED_CONDITIONS_NOT_MET"


def test_rules_engine_never_calls_conditions_official_eligibility():
    conditions = [{"text": "State = Bihar", "profile_field": "state", "operator": "eq", "expected_value": "Bihar", "evidence_id": "E1"}]
    result = evaluate_conditions(conditions, {"state": "Bihar"})
    assert result["overall_status"] == "ALL_EXTRACTED_CONDITIONS_MET_NOT_OFFICIAL_ELIGIBILITY"
    assert "not an official eligibility decision" in result["important_limit"]


def test_language_detection_handles_hindi_and_hinglish():
    from app.policy import detect_language
    assert detect_language("क्या मैं आवेदन कर सकता हूँ?", "auto") == "hi"
    assert detect_language("Mujhe scholarship kaise milegi?", "auto") == "hi"
    assert detect_language("How do I apply for a scholarship?", "auto") == "en"


def test_api_upload_query_and_metrics(monkeypatch, tmp_path):
    from app import main
    from fastapi.testclient import TestClient
    # main imports store functions; patch the DB path used by their module.
    client = TestClient(main.app)
    response = client.post("/api/documents/upload", files={"file": ("policy.pdf", make_pdf(), "application/pdf")})
    assert response.status_code == 200, response.text
    doc_id = response.json()["document_id"]
    q = client.post("/api/query", json={"question": "What does this document say about family income?", "language": "en", "use_llm": False, "document_id": doc_id})
    assert q.status_code == 200, q.text
    assert q.json()["evidence"]
    metrics = client.get("/api/metrics")
    assert metrics.status_code == 200
    assert metrics.json()["user_uploaded_documents"] == 1


def test_api_rejects_too_long_or_malformed_profile():
    from fastapi.testclient import TestClient
    from app.main import app
    client = TestClient(app)
    response = client.post("/api/query", json={"question": "Tell me about this policy", "profile": {"x" * 90: "bad"}})
    assert response.status_code == 422


def test_error_responses_do_not_leak_exception_details():
    # Invalid URL validation uses a controlled, user-safe error response.
    from fastapi.testclient import TestClient
    from app.main import app
    client = TestClient(app)
    response = client.post("/api/documents/ingest-url", json={"url": "http://127.0.0.1/file.pdf"})
    assert response.status_code == 422
    assert "Only HTTPS" in response.text
    assert "Traceback" not in response.text


def test_static_snapshot_files_are_not_loaded_by_startup():
    # Startup initializes the SQLite schema only; no bundled scheme snapshot is loaded.
    import app.store as s
    assert not hasattr(s, "parse_snapshot")



def test_retrieval_strength_is_not_misrepresented_as_answer_confidence():
    from app.policy import _retrieval_strength
    evidence = [{"score": 0.9, "authority_status": "OFFICIAL_DOMAIN_NOT_DOCUMENT_AUTHENTICATED", "freshness": "LIVE"}]
    assert _retrieval_strength(evidence) == "strong"


def test_profile_rejects_nested_objects_and_non_finite_numbers():
    from app.models import QueryRequest
    from pydantic import ValidationError
    with pytest.raises(ValidationError):
        QueryRequest(question="Explain this rule", profile={"person": {"income": 100}})
    with pytest.raises(ValidationError):
        QueryRequest(question="Explain this rule", profile={"income": float("nan")})


def test_section_diff_reports_only_changed_section_content():
    from app.store import _section_diff
    old = "\n".join([
        "Section 1. Applicants",
        "Applicants must be below 25 years.",
        "Section 2. Documents",
        "Submit an income certificate.",
    ])
    new = "\n".join([
        "Section 1. Applicants",
        "Applicants must be below 30 years.",
        "Section 2. Documents",
        "Submit an income certificate.",
    ])
    kind, summary = _section_diff(old, new)
    assert kind == "SECTION_TEXT_CHANGED_REVIEW_REQUIRED"
    assert "CHANGED Section 1" in summary
    assert "25 years" in summary and "30 years" in summary
    assert "Section 2" not in summary

def test_local_env_loader_reads_project_env_file_before_settings(monkeypatch, tmp_path):
    import os
    from app import config
    envfile = tmp_path / ".env"
    envfile.write_text("NAGRI_TEST_ENV_VALUE=loaded-before-settings\n", encoding="utf-8")
    monkeypatch.setattr(config, "ROOT", tmp_path)
    monkeypatch.delenv("NAGRI_TEST_ENV_VALUE", raising=False)
    assert config.load_local_env() is True
    assert os.getenv("NAGRI_TEST_ENV_VALUE") == "loaded-before-settings"


def test_income_parser_handles_indian_lakh_units():
    conditions = [{
        "text": "Annual income must not exceed 250000 INR",
        "profile_field": "annual_family_income",
        "operator": "lte",
        "expected_value": 250000,
        "unit": "INR",
        "evidence_id": "E1",
        "exact_quote": "Annual income must not exceed ₹2.5 lakh per year.",
    }]
    result = evaluate_conditions(conditions, {"annual_family_income": "₹2.5 lakh"})
    assert result["conditions"][0]["status"] == "MET"


def test_llm_json_completion_uses_configured_openai_compatible_endpoint(monkeypatch):
    from app import llm

    class FakeResponse:
        status_code = 200
        def raise_for_status(self): pass
        def json(self):
            return {"choices": [{"message": {"content": '{"ok":true}'}}]}

    seen = {}
    def fake_post(url, headers, json, timeout):
        seen.update({"url": url, "headers": headers, "body": json, "timeout": timeout})
        return FakeResponse()

    monkeypatch.setattr(llm, "LLM_API_KEY", "test-key")
    monkeypatch.setattr(llm, "LLM_BASE_URL", "https://api.example.test/v1")
    monkeypatch.setattr(llm.requests, "post", fake_post)
    assert llm._json_completion("system", "user") == {"ok": True}
    assert seen["url"] == "https://api.example.test/v1/chat/completions"
    assert seen["headers"]["Authorization"] == "Bearer test-key"
    assert seen["body"]["response_format"] == {"type": "json_object"}


def test_grounded_synthesis_uses_only_validated_claims(monkeypatch):
    from app import llm
    evidence = [{
        "evidence_id": "doc-a::p1-c0", "document_id": "doc-a", "title": "Official notice",
        "section": "Section 1", "page": 1, "text": "Applicants must submit an income certificate by 31 December 2026.",
        "source_url": "https://www.pib.gov.in/example.pdf", "authority_status": "OFFICIAL_DOMAIN_NOT_DOCUMENT_AUTHENTICATED",
        "freshness": "LIVE", "document_date": None,
    }]
    payload = {
        "simple_answer": "Submit an income certificate by 31 December 2026.",
        "summary_evidence": [{"evidence_id": "doc-a::p1-c0", "quote": "Applicants must submit an income certificate by 31 December 2026."}],
        "claims": [{"text": "The document says to submit an income certificate by 31 December 2026.", "evidence": [{"evidence_id": "doc-a::p1-c0", "quote": "Applicants must submit an income certificate by 31 December 2026."}]}],
        "unknowns": [], "next_steps": [],
    }
    monkeypatch.setattr(llm, "_json_completion", lambda *args: payload)
    result = llm.synthesize_grounded("What is required?", "en", evidence)
    assert result["validation_attempts"] == 1
    assert result["summary_evidence_ids"] == ["doc-a::p1-c0"]


def test_grounded_synthesis_performs_only_one_repair_after_validation_failure(monkeypatch):
    from app import llm
    evidence = [{"evidence_id": "doc-a::p1-c0", "text": "The fee is 100 rupees."}]
    bad = {
        "simple_answer": "The fee is 200 rupees.",
        "summary_evidence": [{"evidence_id": "doc-a::p1-c0", "quote": "The fee is 100 rupees."}],
        "claims": [{"text": "The fee is 200 rupees.", "evidence": [{"evidence_id": "doc-a::p1-c0", "quote": "The fee is 100 rupees."}]}],
    }
    good = {
        "simple_answer": "The fee is 100 rupees.",
        "summary_evidence": [{"evidence_id": "doc-a::p1-c0", "quote": "The fee is 100 rupees."}],
        "claims": [{"text": "The fee is 100 rupees.", "evidence": [{"evidence_id": "doc-a::p1-c0", "quote": "The fee is 100 rupees."}]}],
    }
    calls = iter([bad, good])
    monkeypatch.setattr(llm, "_json_completion", lambda *args: next(calls))
    result = llm.synthesize_grounded("What is the fee?", "en", evidence)
    assert result["validation_attempts"] == 2


def test_grounded_synthesis_fails_closed_after_second_invalid_response(monkeypatch):
    from app import llm
    evidence = [{"evidence_id": "doc-a::p1-c0", "text": "The fee is 100 rupees."}]
    bad = {
        "simple_answer": "The fee is 200 rupees.",
        "summary_evidence": [{"evidence_id": "doc-a::p1-c0", "quote": "The fee is 100 rupees."}],
        "claims": [{"text": "The fee is 200 rupees.", "evidence": [{"evidence_id": "doc-a::p1-c0", "quote": "The fee is 100 rupees."}]}],
    }
    monkeypatch.setattr(llm, "_json_completion", lambda *args: bad)
    with pytest.raises(GroundingError):
        llm.synthesize_grounded("What is the fee?", "en", evidence)


def test_policy_extraction_batches_all_passages_and_reports_complete_coverage(monkeypatch):
    from app import llm
    passages = []
    for index in range(11):
        passages.append({
            "evidence_id": f"doc-batch::p{index + 1}-c0", "document_id": "doc-batch", "title": "Long policy",
            "section": f"Section {index + 1}", "page": index + 1,
            "text": f"Section {index + 1}. Applicants must submit document {index + 1}.",
            "source_url": "https://www.pib.gov.in/policy.pdf", "authority_status": "OFFICIAL_DOMAIN_NOT_DOCUMENT_AUTHENTICATED",
            "freshness": "LIVE", "document_date": None,
        })
    calls = []
    def fake_completion(system, user):
        sources = json.loads(user)["sources"]
        calls.append(sources[0]["evidence_id"])
        return {
            "document_summary": f"This batch contains {sources[0]['title']} material.",
            "document_summary_evidence": [{"evidence_id": source["evidence_id"], "exact_quote": source["text"]} for source in sources],
            "rights": [{"text": "The source lists a document requirement.", "evidence_id": source["evidence_id"], "exact_quote": source["text"]} for source in sources],
        }
    monkeypatch.setattr(llm, "_json_completion", fake_completion)
    result = llm.extract_policy_structure(passages, "en")
    assert len(calls) == 2
    assert result["analysis_coverage"] == {
        "total_evidence_chunks": 11, "analysed_evidence_chunks": 11, "complete": True, "sampled_across_document": False
    }
    assert len(result["rights"]) == 11


def test_policy_extraction_caps_large_documents_and_discloses_incomplete_coverage(monkeypatch):
    from app import llm
    passages = []
    for index in range(61):
        passages.append({
            "evidence_id": f"doc-long::p{index + 1}-c0", "document_id": "doc-long", "title": "Long policy",
            "section": f"Section {index + 1}", "page": index + 1,
            "text": f"Section {index + 1}. Applicants must submit document {index + 1}.",
            "source_url": "https://www.pib.gov.in/policy.pdf", "authority_status": "OFFICIAL_DOMAIN_NOT_DOCUMENT_AUTHENTICATED",
            "freshness": "LIVE", "document_date": None,
        })
    calls = []
    def fake_completion(system, user):
        sources = json.loads(user)["sources"]
        calls.append(len(sources))
        first = sources[0]
        return {
            "document_summary": "Only the quoted passages in this batch were reviewed.",
            "document_summary_evidence": [{"evidence_id": first["evidence_id"], "exact_quote": first["text"]}],
        }
    monkeypatch.setattr(llm, "_json_completion", fake_completion)
    result = llm.extract_policy_structure(passages, "en", max_chunks=10)
    assert result["analysis_coverage"]["complete"] is False
    assert result["analysis_coverage"]["total_evidence_chunks"] == 61
    assert result["analysis_coverage"]["analysed_evidence_chunks"] == 10
    assert "incomplete" in result["limitations"][-1].lower()
    assert len(calls) == 1


def test_mixed_text_and_scanned_pdf_pages_are_flagged_as_incomplete_source_text():
    from app.ingestion import ingest_pdf_upload
    doc = fitz.open()
    page = doc.new_page()
    page.insert_text((72, 72), "This page contains a sufficiently long extractable policy statement for checking.")
    doc.new_page()  # Simulates a scanned page without a text layer.
    data = doc.tobytes()
    doc.close()
    result = ingest_pdf_upload(data, "mixed-text-scan.pdf")
    assert "contain little extractable text" in (result["extraction_note"] or "")
    stored = store.get_all_evidence(document_id=result["document_id"])
    assert stored and "little extractable text" in stored[0]["extraction_note"]


def test_next_steps_must_have_citations_and_numeric_unknowns_are_not_returned():
    evidence = [{"evidence_id": "doc-a::p1-c0", "text": "Submit the form to the district office."}]
    payload = {
        "simple_answer": "The source says to submit the form.",
        "summary_evidence": [{"evidence_id": "doc-a::p1-c0", "quote": "Submit the form to the district office."}],
        "claims": [{"text": "Submit the form.", "evidence": [{"evidence_id": "doc-a::p1-c0", "quote": "Submit the form to the district office."}]}],
        "unknowns": ["Current deadline", "Deadline is 31 December 2026"],
        "next_steps": [{"text": "Submit the form to the district office.", "evidence": [{"evidence_id": "doc-a::p1-c0", "quote": "Submit the form to the district office."}]}],
    }
    checked = validate_grounded_payload(payload, evidence)
    assert checked["unknowns"] == ["Current deadline"]
    assert checked["next_steps"][0]["evidence_ids"] == ["doc-a::p1-c0"]
    bad = dict(payload)
    bad["next_steps"] = [{"text": "Pay ₹5,000 to the officer.", "evidence": []}]
    with pytest.raises(GroundingError):
        validate_grounded_payload(bad, evidence)


def test_hindi_queries_expand_to_retrieve_english_policy_passages():
    save_test_doc(
        "doc-hi-en",
        "Scholarship eligibility requires a Bihar resident. Annual family income must not exceed 250000 INR.",
    )
    from app.policy import expand_bilingual_query
    from app.retrieval import retrieve
    query = expand_bilingual_query("छात्रवृत्ति की पात्रता और परिवार की आय सीमा क्या है")
    results = retrieve(query, k=5)
    assert results and results[0]["document_id"] == "doc-hi-en"


def test_hinglish_crop_insurance_query_expands_to_english():
    save_test_doc("doc-hinglish-farm", "Crop insurance is available under notified crop and season conditions.")
    from app.policy import expand_bilingual_query
    from app.retrieval import retrieve
    results = retrieve(expand_bilingual_query("fasal bima yojana ke documents kya hain"), k=5)
    assert results and results[0]["document_id"] == "doc-hinglish-farm"


def test_policy_extraction_rejects_numeric_claim_not_present_in_quote(monkeypatch):
    from app import llm
    evidence = [{"evidence_id": "doc::p1-c0", "text": "Annual family income must not exceed ₹2.5 lakh per year."}]
    fake = {
        "document_summary": "The income limit is ₹5 lakh.",
        "document_summary_evidence": [{"evidence_id": "doc::p1-c0", "exact_quote": "Annual family income must not exceed ₹2.5 lakh per year."}],
        "rights": [], "eligibility_conditions": [], "obligations": [], "deadlines": [],
        "documents": [], "benefits": [], "exceptions": [], "authorities": [], "open_questions": [],
    }
    monkeypatch.setattr(llm, "_json_completion", lambda *a, **k: fake)
    with pytest.raises(GroundingError, match="numeric values"):
        llm._extract_policy_batch(evidence, "en")


def test_policy_extraction_downgrades_unsupported_numeric_condition_to_unknown(monkeypatch):
    from app import llm
    evidence = [{"evidence_id": "doc::p1-c0", "text": "Annual family income must not exceed ₹2.5 lakh per year."}]
    fake = {
        "document_summary": "The source describes an annual family income limit.",
        "document_summary_evidence": [{"evidence_id": "doc::p1-c0", "exact_quote": "Annual family income must not exceed ₹2.5 lakh per year."}],
        "rights": [],
        "eligibility_conditions": [{
            "text": "Annual family income must not exceed ₹2.5 lakh.",
            "evidence_id": "doc::p1-c0",
            "exact_quote": "Annual family income must not exceed ₹2.5 lakh per year.",
            "profile_field": "annual_family_income", "operator": "lte", "expected_value": 500000, "unit": "INR",
        }],
        "obligations": [], "deadlines": [], "documents": [], "benefits": [], "exceptions": [], "authorities": [], "open_questions": [],
    }
    monkeypatch.setattr(llm, "_json_completion", lambda *a, **k: fake)
    result = llm._extract_policy_batch(evidence, "en")
    assert result["eligibility_conditions"][0]["operator"] == "unknown"
    assert result["eligibility_conditions"][0]["expected_value"] is None


def test_income_rule_rejects_incompatible_units_in_profile():
    conditions = [{
        "text": "Annual family income must not exceed 250000 INR",
        "profile_field": "annual_family_income", "operator": "lte",
        "expected_value": 250000, "unit": "INR", "evidence_id": "E1",
    }]
    result = evaluate_conditions(conditions, {"annual_family_income": "50kg"})
    assert result["conditions"][0]["status"] == "UNKNOWN"


def test_numeric_rule_accepts_bare_amount_and_rejects_wrong_unit():
    from app.rules import _number
    assert _number("₹2.5 lakh", "INR") == 250000
    assert _number("250000", "INR") == 250000
    assert _number("2 hectares", "acres") is None


def test_rules_engine_parses_hindi_lakh_profile_value():
    conditions = [{
        "text": "Annual family income must not exceed ₹2.5 lakh",
        "profile_field": "annual_family_income", "operator": "lte",
        "expected_value": 250000, "unit": "INR", "evidence_id": "E1",
    }]
    result = evaluate_conditions(conditions, {"annual_family_income": "₹2.5 लाख"})
    assert result["conditions"][0]["status"] == "MET"


def test_verified_student_and_farmer_official_hosts_are_allowlisted():
    from app.config import ALLOWED_SOURCE_HOSTS
    expected = {
        "indiacode.gov.in", "education.gov.in", "socialjustice.gov.in",
        "tribal.gov.in", "depwd.gov.in", "agriinfra.dac.gov.in",
        "scholarships.gov.in", "pmkisan.gov.in", "pmfby.gov.in",
    }
    assert expected.issubset(ALLOWED_SOURCE_HOSTS)


def test_retrieval_evaluation_scoring_metrics():
    from scripts.evaluate_retrieval import score_case
    answerable = score_case({"gold-2"}, ["other", "gold-2"], False, False, 5)
    assert answerable["hit_at_1"] is False
    assert answerable["hit_at_3"] is True
    assert answerable["reciprocal_rank"] == 0.5
    abstention = score_case(set(), [], True, True, 5)
    assert abstention["abstention_correct"] is True


def test_retrieval_evaluation_file_runs_on_empty_database_and_counts_abstention(tmp_path):
    from scripts.evaluate_retrieval import evaluate_file
    path = tmp_path / "labels.jsonl"
    path.write_text('{"question":"What is the current rule?","gold_evidence_ids":[],"should_abstain":true}\n', encoding="utf-8")
    result = evaluate_file(path)
    assert result["questions"] == 1
    assert result["abstention_accuracy"] == 1.0


def test_numeric_verification_and_rules_support_hindi_unit_and_digits():
    from app.llm import _numeric_facts, _numeric_value_is_supported
    from app.rules import _number
    quote = "परिवार की वार्षिक आय ₹२.५ लाख से अधिक नहीं होनी चाहिए।"
    assert _numeric_value_is_supported(250000, "INR", quote)
    assert _number("₹२.५ लाख", "INR") == 250000
    assert ("INR", "250000") in _numeric_facts(quote)


def test_api_rejects_oversized_json_request_body():
    from fastapi.testclient import TestClient
    from app.main import app
    client = TestClient(app)
    response = client.post(
        "/api/query",
        content=b" " * (64 * 1024 + 1),
        headers={"Content-Type": "application/json"},
    )
    assert response.status_code == 413
    assert "size limit" in response.text
